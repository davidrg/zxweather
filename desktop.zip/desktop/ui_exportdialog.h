/********************************************************************************
** Form generated from reading UI file 'exportdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EXPORTDIALOG_H
#define UI_EXPORTDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QVBoxLayout>
#include "timespanwidget.h"

QT_BEGIN_NAMESPACE

class Ui_ExportDialog
{
public:
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox;
    QGridLayout *gridLayout;
    QRadioButton *rbCommaDelimited;
    QLabel *label_2;
    QLineEdit *leCustomDelimiter;
    QRadioButton *rbOtherDelimiter;
    QRadioButton *rbTabDelimited;
    QCheckBox *cbIncludeHeadings;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_2;
    QCheckBox *cbHighUVIndex;
    QCheckBox *cbSolarRadiation;
    QCheckBox *cbUVIndex;
    QCheckBox *cbGustWindDirection;
    QCheckBox *cbTimestamp;
    QCheckBox *cbTemperature;
    QCheckBox *cbRainfall;
    QCheckBox *cbHumidity;
    QCheckBox *cbIndoorHumidity;
    QCheckBox *cbPressure;
    QCheckBox *cbDewPoint;
    QCheckBox *cbApparentTemperature;
    QCheckBox *cbWindChill;
    QCheckBox *cbAverageWindSpeed;
    QCheckBox *cbIndoorTemperature;
    QCheckBox *cbGustWindSpeed;
    QCheckBox *cbWindDirection;
    QCheckBox *cbLowTemperature;
    QCheckBox *cbHighRainRate;
    QCheckBox *cbHighTemperature;
    QCheckBox *cbHighSolarRadiation;
    QCheckBox *cbEvapotranspiration;
    QCheckBox *cbWirelessReception;
    QCheckBox *cbForecastRuleID;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout_3;
    TimespanWidget *timespan;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *ExportDialog)
    {
        if (ExportDialog->objectName().isEmpty())
            ExportDialog->setObjectName(QStringLiteral("ExportDialog"));
        ExportDialog->resize(437, 389);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/export-data"), QSize(), QIcon::Normal, QIcon::Off);
        ExportDialog->setWindowIcon(icon);
        verticalLayout = new QVBoxLayout(ExportDialog);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetFixedSize);
        groupBox = new QGroupBox(ExportDialog);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout = new QGridLayout(groupBox);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        rbCommaDelimited = new QRadioButton(groupBox);
        rbCommaDelimited->setObjectName(QStringLiteral("rbCommaDelimited"));

        gridLayout->addWidget(rbCommaDelimited, 0, 2, 1, 1);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 0, 0, 1, 1);

        leCustomDelimiter = new QLineEdit(groupBox);
        leCustomDelimiter->setObjectName(QStringLiteral("leCustomDelimiter"));
        leCustomDelimiter->setEnabled(false);
        leCustomDelimiter->setMaximumSize(QSize(50, 16777215));

        gridLayout->addWidget(leCustomDelimiter, 0, 4, 1, 1);

        rbOtherDelimiter = new QRadioButton(groupBox);
        rbOtherDelimiter->setObjectName(QStringLiteral("rbOtherDelimiter"));

        gridLayout->addWidget(rbOtherDelimiter, 0, 3, 1, 1);

        rbTabDelimited = new QRadioButton(groupBox);
        rbTabDelimited->setObjectName(QStringLiteral("rbTabDelimited"));
        rbTabDelimited->setChecked(true);

        gridLayout->addWidget(rbTabDelimited, 0, 1, 1, 1);

        cbIncludeHeadings = new QCheckBox(groupBox);
        cbIncludeHeadings->setObjectName(QStringLiteral("cbIncludeHeadings"));
        cbIncludeHeadings->setChecked(true);

        gridLayout->addWidget(cbIncludeHeadings, 1, 0, 1, 1);


        verticalLayout->addWidget(groupBox);

        groupBox_2 = new QGroupBox(ExportDialog);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        gridLayout_2 = new QGridLayout(groupBox_2);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        cbHighUVIndex = new QCheckBox(groupBox_2);
        cbHighUVIndex->setObjectName(QStringLiteral("cbHighUVIndex"));
        cbHighUVIndex->setChecked(true);

        gridLayout_2->addWidget(cbHighUVIndex, 6, 2, 1, 1);

        cbSolarRadiation = new QCheckBox(groupBox_2);
        cbSolarRadiation->setObjectName(QStringLiteral("cbSolarRadiation"));
        cbSolarRadiation->setChecked(true);

        gridLayout_2->addWidget(cbSolarRadiation, 5, 2, 1, 1);

        cbUVIndex = new QCheckBox(groupBox_2);
        cbUVIndex->setObjectName(QStringLiteral("cbUVIndex"));
        cbUVIndex->setChecked(true);

        gridLayout_2->addWidget(cbUVIndex, 4, 2, 1, 1);

        cbGustWindDirection = new QCheckBox(groupBox_2);
        cbGustWindDirection->setObjectName(QStringLiteral("cbGustWindDirection"));
        cbGustWindDirection->setChecked(true);

        gridLayout_2->addWidget(cbGustWindDirection, 3, 2, 1, 1);

        cbTimestamp = new QCheckBox(groupBox_2);
        cbTimestamp->setObjectName(QStringLiteral("cbTimestamp"));
        cbTimestamp->setChecked(true);

        gridLayout_2->addWidget(cbTimestamp, 0, 0, 1, 1);

        cbTemperature = new QCheckBox(groupBox_2);
        cbTemperature->setObjectName(QStringLiteral("cbTemperature"));
        cbTemperature->setChecked(true);

        gridLayout_2->addWidget(cbTemperature, 1, 0, 1, 1);

        cbRainfall = new QCheckBox(groupBox_2);
        cbRainfall->setObjectName(QStringLiteral("cbRainfall"));
        cbRainfall->setEnabled(true);
        cbRainfall->setChecked(true);

        gridLayout_2->addWidget(cbRainfall, 4, 1, 1, 1);

        cbHumidity = new QCheckBox(groupBox_2);
        cbHumidity->setObjectName(QStringLiteral("cbHumidity"));
        cbHumidity->setEnabled(true);
        cbHumidity->setChecked(true);

        gridLayout_2->addWidget(cbHumidity, 1, 1, 1, 1);

        cbIndoorHumidity = new QCheckBox(groupBox_2);
        cbIndoorHumidity->setObjectName(QStringLiteral("cbIndoorHumidity"));
        cbIndoorHumidity->setEnabled(true);
        cbIndoorHumidity->setChecked(true);

        gridLayout_2->addWidget(cbIndoorHumidity, 2, 1, 1, 1);

        cbPressure = new QCheckBox(groupBox_2);
        cbPressure->setObjectName(QStringLiteral("cbPressure"));
        cbPressure->setEnabled(true);
        cbPressure->setChecked(true);

        gridLayout_2->addWidget(cbPressure, 3, 1, 1, 1);

        cbDewPoint = new QCheckBox(groupBox_2);
        cbDewPoint->setObjectName(QStringLiteral("cbDewPoint"));
        cbDewPoint->setChecked(true);

        gridLayout_2->addWidget(cbDewPoint, 0, 1, 1, 1);

        cbApparentTemperature = new QCheckBox(groupBox_2);
        cbApparentTemperature->setObjectName(QStringLiteral("cbApparentTemperature"));
        cbApparentTemperature->setChecked(true);

        gridLayout_2->addWidget(cbApparentTemperature, 3, 0, 1, 1);

        cbWindChill = new QCheckBox(groupBox_2);
        cbWindChill->setObjectName(QStringLiteral("cbWindChill"));
        cbWindChill->setChecked(true);

        gridLayout_2->addWidget(cbWindChill, 4, 0, 1, 1);

        cbAverageWindSpeed = new QCheckBox(groupBox_2);
        cbAverageWindSpeed->setObjectName(QStringLiteral("cbAverageWindSpeed"));
        cbAverageWindSpeed->setChecked(true);

        gridLayout_2->addWidget(cbAverageWindSpeed, 0, 2, 1, 1);

        cbIndoorTemperature = new QCheckBox(groupBox_2);
        cbIndoorTemperature->setObjectName(QStringLiteral("cbIndoorTemperature"));
        cbIndoorTemperature->setChecked(true);

        gridLayout_2->addWidget(cbIndoorTemperature, 2, 0, 1, 1);

        cbGustWindSpeed = new QCheckBox(groupBox_2);
        cbGustWindSpeed->setObjectName(QStringLiteral("cbGustWindSpeed"));
        cbGustWindSpeed->setChecked(true);

        gridLayout_2->addWidget(cbGustWindSpeed, 1, 2, 1, 1);

        cbWindDirection = new QCheckBox(groupBox_2);
        cbWindDirection->setObjectName(QStringLiteral("cbWindDirection"));
        cbWindDirection->setChecked(true);

        gridLayout_2->addWidget(cbWindDirection, 2, 2, 1, 1);

        cbLowTemperature = new QCheckBox(groupBox_2);
        cbLowTemperature->setObjectName(QStringLiteral("cbLowTemperature"));
        cbLowTemperature->setChecked(true);

        gridLayout_2->addWidget(cbLowTemperature, 6, 0, 1, 1);

        cbHighRainRate = new QCheckBox(groupBox_2);
        cbHighRainRate->setObjectName(QStringLiteral("cbHighRainRate"));
        cbHighRainRate->setChecked(true);

        gridLayout_2->addWidget(cbHighRainRate, 5, 1, 1, 1);

        cbHighTemperature = new QCheckBox(groupBox_2);
        cbHighTemperature->setObjectName(QStringLiteral("cbHighTemperature"));
        cbHighTemperature->setChecked(true);

        gridLayout_2->addWidget(cbHighTemperature, 5, 0, 1, 1);

        cbHighSolarRadiation = new QCheckBox(groupBox_2);
        cbHighSolarRadiation->setObjectName(QStringLiteral("cbHighSolarRadiation"));
        cbHighSolarRadiation->setChecked(true);

        gridLayout_2->addWidget(cbHighSolarRadiation, 7, 2, 1, 1);

        cbEvapotranspiration = new QCheckBox(groupBox_2);
        cbEvapotranspiration->setObjectName(QStringLiteral("cbEvapotranspiration"));
        cbEvapotranspiration->setChecked(true);

        gridLayout_2->addWidget(cbEvapotranspiration, 7, 1, 1, 1);

        cbWirelessReception = new QCheckBox(groupBox_2);
        cbWirelessReception->setObjectName(QStringLiteral("cbWirelessReception"));
        cbWirelessReception->setChecked(true);

        gridLayout_2->addWidget(cbWirelessReception, 7, 0, 1, 1);

        cbForecastRuleID = new QCheckBox(groupBox_2);
        cbForecastRuleID->setObjectName(QStringLiteral("cbForecastRuleID"));
        cbForecastRuleID->setChecked(true);

        gridLayout_2->addWidget(cbForecastRuleID, 6, 1, 1, 1);


        verticalLayout->addWidget(groupBox_2);

        groupBox_3 = new QGroupBox(ExportDialog);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        gridLayout_3 = new QGridLayout(groupBox_3);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        timespan = new TimespanWidget(groupBox_3);
        timespan->setObjectName(QStringLiteral("timespan"));

        gridLayout_3->addWidget(timespan, 0, 0, 1, 1);


        verticalLayout->addWidget(groupBox_3);

        buttonBox = new QDialogButtonBox(ExportDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);

        QWidget::setTabOrder(rbTabDelimited, rbCommaDelimited);
        QWidget::setTabOrder(rbCommaDelimited, rbOtherDelimiter);
        QWidget::setTabOrder(rbOtherDelimiter, leCustomDelimiter);
        QWidget::setTabOrder(leCustomDelimiter, cbIncludeHeadings);
        QWidget::setTabOrder(cbIncludeHeadings, cbTimestamp);
        QWidget::setTabOrder(cbTimestamp, cbTemperature);
        QWidget::setTabOrder(cbTemperature, cbIndoorTemperature);
        QWidget::setTabOrder(cbIndoorTemperature, cbApparentTemperature);
        QWidget::setTabOrder(cbApparentTemperature, cbWindChill);
        QWidget::setTabOrder(cbWindChill, cbHighTemperature);
        QWidget::setTabOrder(cbHighTemperature, cbLowTemperature);
        QWidget::setTabOrder(cbLowTemperature, cbWirelessReception);
        QWidget::setTabOrder(cbWirelessReception, cbDewPoint);
        QWidget::setTabOrder(cbDewPoint, cbHumidity);
        QWidget::setTabOrder(cbHumidity, cbIndoorHumidity);
        QWidget::setTabOrder(cbIndoorHumidity, cbPressure);
        QWidget::setTabOrder(cbPressure, cbRainfall);
        QWidget::setTabOrder(cbRainfall, cbHighRainRate);
        QWidget::setTabOrder(cbHighRainRate, cbForecastRuleID);
        QWidget::setTabOrder(cbForecastRuleID, cbEvapotranspiration);
        QWidget::setTabOrder(cbEvapotranspiration, cbAverageWindSpeed);
        QWidget::setTabOrder(cbAverageWindSpeed, cbGustWindSpeed);
        QWidget::setTabOrder(cbGustWindSpeed, cbWindDirection);
        QWidget::setTabOrder(cbWindDirection, cbGustWindDirection);
        QWidget::setTabOrder(cbGustWindDirection, cbUVIndex);
        QWidget::setTabOrder(cbUVIndex, cbSolarRadiation);
        QWidget::setTabOrder(cbSolarRadiation, cbHighUVIndex);
        QWidget::setTabOrder(cbHighUVIndex, cbHighSolarRadiation);

        retranslateUi(ExportDialog);
        QObject::connect(buttonBox, SIGNAL(rejected()), ExportDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(ExportDialog);
    } // setupUi

    void retranslateUi(QDialog *ExportDialog)
    {
        ExportDialog->setWindowTitle(QApplication::translate("ExportDialog", "Export data", 0));
        groupBox->setTitle(QApplication::translate("ExportDialog", "Format", 0));
        rbCommaDelimited->setText(QApplication::translate("ExportDialog", "Comma", 0));
        label_2->setText(QApplication::translate("ExportDialog", "Column Delimiter:", 0));
        rbOtherDelimiter->setText(QApplication::translate("ExportDialog", "Other:", 0));
        rbTabDelimited->setText(QApplication::translate("ExportDialog", "Tab", 0));
        cbIncludeHeadings->setText(QApplication::translate("ExportDialog", "Include headings", 0));
        groupBox_2->setTitle(QApplication::translate("ExportDialog", "Columns", 0));
        cbHighUVIndex->setText(QApplication::translate("ExportDialog", "High UV Index", 0));
        cbSolarRadiation->setText(QApplication::translate("ExportDialog", "Solar Radiation", 0));
        cbUVIndex->setText(QApplication::translate("ExportDialog", "UV Index", 0));
        cbGustWindDirection->setText(QApplication::translate("ExportDialog", "Gust Wind Direction", 0));
        cbTimestamp->setText(QApplication::translate("ExportDialog", "Timestamp", 0));
        cbTemperature->setText(QApplication::translate("ExportDialog", "Temperature", 0));
        cbRainfall->setText(QApplication::translate("ExportDialog", "Rainfall", 0));
        cbHumidity->setText(QApplication::translate("ExportDialog", "Humidity", 0));
        cbIndoorHumidity->setText(QApplication::translate("ExportDialog", "Humidity (inside)", 0));
        cbPressure->setText(QApplication::translate("ExportDialog", "Pressure", 0));
        cbDewPoint->setText(QApplication::translate("ExportDialog", "Dew Point", 0));
        cbApparentTemperature->setText(QApplication::translate("ExportDialog", "Apparent Temperature", 0));
        cbWindChill->setText(QApplication::translate("ExportDialog", "Wind Chill", 0));
        cbAverageWindSpeed->setText(QApplication::translate("ExportDialog", "Average Wind Speed", 0));
        cbIndoorTemperature->setText(QApplication::translate("ExportDialog", "Temperature (inside)", 0));
        cbGustWindSpeed->setText(QApplication::translate("ExportDialog", "Gust Wind Speed", 0));
        cbWindDirection->setText(QApplication::translate("ExportDialog", "Wind Direction", 0));
        cbLowTemperature->setText(QApplication::translate("ExportDialog", "Low Temperature", 0));
        cbHighRainRate->setText(QApplication::translate("ExportDialog", "High Rain Rate", 0));
        cbHighTemperature->setText(QApplication::translate("ExportDialog", "High Temperature", 0));
        cbHighSolarRadiation->setText(QApplication::translate("ExportDialog", "High Solar Radiation", 0));
        cbEvapotranspiration->setText(QApplication::translate("ExportDialog", "Evapotranspiration", 0));
        cbWirelessReception->setText(QApplication::translate("ExportDialog", "Wireless Reception", 0));
        cbForecastRuleID->setText(QApplication::translate("ExportDialog", "Forecast Rule ID", 0));
        groupBox_3->setTitle(QApplication::translate("ExportDialog", "Period", 0));
    } // retranslateUi

};

namespace Ui {
    class ExportDialog: public Ui_ExportDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EXPORTDIALOG_H
