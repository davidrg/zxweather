/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>
#include "dash_widgets/forecastwidget.h"
#include "dash_widgets/imagestabwidget.h"
#include "dash_widgets/livedatawidget.h"
#include "dash_widgets/rainfallwidget.h"
#include "dash_widgets/statuswidget.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionSettings;
    QAction *actionAbout;
    QAction *actionCharts;
    QAction *actionExport_Data;
    QAction *actionView_Data;
    QAction *actionImages;
    QAction *actionLive_Chart;
    QWidget *centralWidget;
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    StatusWidget *status;
    LiveDataWidget *liveData;
    RainfallWidget *rainfall;
    ForecastWidget *forecast;
    QSpacerItem *verticalSpacer_2;
    QSpacerItem *verticalSpacer;
    ImagesTabWidget *latestImages;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(712, 183);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(712, 0));
        MainWindow->setMaximumSize(QSize(712, 16777215));
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/systray_icon"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setDocumentMode(false);
        actionSettings = new QAction(MainWindow);
        actionSettings->setObjectName(QStringLiteral("actionSettings"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/settings"), QSize(), QIcon::Normal, QIcon::Off);
        actionSettings->setIcon(icon1);
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QStringLiteral("actionAbout"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/icons/about"), QSize(), QIcon::Normal, QIcon::Off);
        actionAbout->setIcon(icon2);
        actionCharts = new QAction(MainWindow);
        actionCharts->setObjectName(QStringLiteral("actionCharts"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/icons/chart"), QSize(), QIcon::Normal, QIcon::Off);
        actionCharts->setIcon(icon3);
        actionExport_Data = new QAction(MainWindow);
        actionExport_Data->setObjectName(QStringLiteral("actionExport_Data"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/icons/export-data"), QSize(), QIcon::Normal, QIcon::Off);
        actionExport_Data->setIcon(icon4);
        actionView_Data = new QAction(MainWindow);
        actionView_Data->setObjectName(QStringLiteral("actionView_Data"));
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/icons/table"), QSize(), QIcon::Normal, QIcon::Off);
        actionView_Data->setIcon(icon5);
        actionImages = new QAction(MainWindow);
        actionImages->setObjectName(QStringLiteral("actionImages"));
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/icons/image"), QSize(), QIcon::Normal, QIcon::Off);
        actionImages->setIcon(icon6);
        actionLive_Chart = new QAction(MainWindow);
        actionLive_Chart->setObjectName(QStringLiteral("actionLive_Chart"));
        actionLive_Chart->setIcon(icon3);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout_2 = new QGridLayout(centralWidget);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        status = new StatusWidget(centralWidget);
        status->setObjectName(QStringLiteral("status"));

        gridLayout->addWidget(status, 1, 1, 2, 1);

        liveData = new LiveDataWidget(centralWidget);
        liveData->setObjectName(QStringLiteral("liveData"));
        liveData->setMinimumSize(QSize(343, 0));
        liveData->setMaximumSize(QSize(343, 16777215));

        gridLayout->addWidget(liveData, 0, 0, 1, 1);

        rainfall = new RainfallWidget(centralWidget);
        rainfall->setObjectName(QStringLiteral("rainfall"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(rainfall->sizePolicy().hasHeightForWidth());
        rainfall->setSizePolicy(sizePolicy1);
        rainfall->setMinimumSize(QSize(343, 0));
        rainfall->setMaximumSize(QSize(0, 16777215));

        gridLayout->addWidget(rainfall, 0, 1, 1, 1);

        forecast = new ForecastWidget(centralWidget);
        forecast->setObjectName(QStringLiteral("forecast"));

        gridLayout->addWidget(forecast, 1, 0, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 0, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 3, 1, 1, 1);

        verticalSpacer = new QSpacerItem(20, 0, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 2, 0, 2, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);

        latestImages = new ImagesTabWidget(centralWidget);
        latestImages->setObjectName(QStringLiteral("latestImages"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(latestImages->sizePolicy().hasHeightForWidth());
        latestImages->setSizePolicy(sizePolicy2);

        gridLayout_2->addWidget(latestImages, 1, 0, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 712, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        mainToolBar->setIconSize(QSize(16, 16));
        mainToolBar->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);

        mainToolBar->addAction(actionCharts);
        mainToolBar->addAction(actionLive_Chart);
        mainToolBar->addAction(actionExport_Data);
        mainToolBar->addAction(actionView_Data);
        mainToolBar->addAction(actionImages);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionSettings);
        mainToolBar->addAction(actionAbout);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "zxweather", 0));
        actionSettings->setText(QApplication::translate("MainWindow", "Settings", 0));
        actionAbout->setText(QApplication::translate("MainWindow", "About", 0));
        actionCharts->setText(QApplication::translate("MainWindow", "Create Chart...", 0));
        actionCharts->setIconText(QApplication::translate("MainWindow", "Create Chart...", 0));
#ifndef QT_NO_TOOLTIP
        actionCharts->setToolTip(QApplication::translate("MainWindow", "Plot custom charts...", 0));
#endif // QT_NO_TOOLTIP
        actionExport_Data->setText(QApplication::translate("MainWindow", "Export...", 0));
        actionExport_Data->setIconText(QApplication::translate("MainWindow", "Export...", 0));
#ifndef QT_NO_TOOLTIP
        actionExport_Data->setToolTip(QApplication::translate("MainWindow", "Save data as a csv file...", 0));
#endif // QT_NO_TOOLTIP
        actionView_Data->setText(QApplication::translate("MainWindow", "View Data...", 0));
        actionView_Data->setIconText(QApplication::translate("MainWindow", "View Data...", 0));
#ifndef QT_NO_TOOLTIP
        actionView_Data->setToolTip(QApplication::translate("MainWindow", "View Data in a table", 0));
#endif // QT_NO_TOOLTIP
        actionImages->setText(QApplication::translate("MainWindow", "Images...", 0));
        actionImages->setIconText(QApplication::translate("MainWindow", "Images...", 0));
        actionImages->setShortcut(QApplication::translate("MainWindow", "Ctrl+I", 0));
        actionLive_Chart->setText(QApplication::translate("MainWindow", "Live Chart...", 0));
        actionLive_Chart->setIconText(QApplication::translate("MainWindow", "Live Chart...", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
