/********************************************************************************
** Form generated from reading UI file 'livechartoptionsdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LIVECHARTOPTIONSDIALOG_H
#define UI_LIVECHARTOPTIONSDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_LiveChartOptionsDialog
{
public:
    QVBoxLayout *verticalLayout;
    QCheckBox *cbStormRain;
    QLabel *label_2;
    QSpinBox *sbTimespan;
    QGroupBox *cbAverageUpdates;
    QFormLayout *formLayout;
    QLabel *label;
    QCheckBox *cbMaxRainRate;
    QSpinBox *sbPeriod;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_3;
    QCheckBox *cbAxisTags;
    QCheckBox *cbMultiAxisRect;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *LiveChartOptionsDialog)
    {
        if (LiveChartOptionsDialog->objectName().isEmpty())
            LiveChartOptionsDialog->setObjectName(QStringLiteral("LiveChartOptionsDialog"));
        LiveChartOptionsDialog->resize(410, 289);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/options"), QSize(), QIcon::Normal, QIcon::Off);
        LiveChartOptionsDialog->setWindowIcon(icon);
        verticalLayout = new QVBoxLayout(LiveChartOptionsDialog);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetFixedSize);
        cbStormRain = new QCheckBox(LiveChartOptionsDialog);
        cbStormRain->setObjectName(QStringLiteral("cbStormRain"));
        cbStormRain->setChecked(true);

        verticalLayout->addWidget(cbStormRain);

        label_2 = new QLabel(LiveChartOptionsDialog);
        label_2->setObjectName(QStringLiteral("label_2"));

        verticalLayout->addWidget(label_2);

        sbTimespan = new QSpinBox(LiveChartOptionsDialog);
        sbTimespan->setObjectName(QStringLiteral("sbTimespan"));
        sbTimespan->setValue(2);

        verticalLayout->addWidget(sbTimespan);

        cbAverageUpdates = new QGroupBox(LiveChartOptionsDialog);
        cbAverageUpdates->setObjectName(QStringLiteral("cbAverageUpdates"));
        cbAverageUpdates->setCheckable(true);
        cbAverageUpdates->setChecked(false);
        formLayout = new QFormLayout(cbAverageUpdates);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label = new QLabel(cbAverageUpdates);
        label->setObjectName(QStringLiteral("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        cbMaxRainRate = new QCheckBox(cbAverageUpdates);
        cbMaxRainRate->setObjectName(QStringLiteral("cbMaxRainRate"));

        formLayout->setWidget(1, QFormLayout::FieldRole, cbMaxRainRate);

        sbPeriod = new QSpinBox(cbAverageUpdates);
        sbPeriod->setObjectName(QStringLiteral("sbPeriod"));
        sbPeriod->setMinimum(2);
        sbPeriod->setMaximum(300);
        sbPeriod->setSingleStep(2);

        formLayout->setWidget(0, QFormLayout::FieldRole, sbPeriod);


        verticalLayout->addWidget(cbAverageUpdates);

        groupBox = new QGroupBox(LiveChartOptionsDialog);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        verticalLayout_2 = new QVBoxLayout(groupBox);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout_2->addWidget(label_3);

        cbAxisTags = new QCheckBox(groupBox);
        cbAxisTags->setObjectName(QStringLiteral("cbAxisTags"));

        verticalLayout_2->addWidget(cbAxisTags);

        cbMultiAxisRect = new QCheckBox(groupBox);
        cbMultiAxisRect->setObjectName(QStringLiteral("cbMultiAxisRect"));

        verticalLayout_2->addWidget(cbMultiAxisRect);


        verticalLayout->addWidget(groupBox);

        buttonBox = new QDialogButtonBox(LiveChartOptionsDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);

        QWidget::setTabOrder(sbPeriod, cbMaxRainRate);

        retranslateUi(LiveChartOptionsDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), LiveChartOptionsDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), LiveChartOptionsDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(LiveChartOptionsDialog);
    } // setupUi

    void retranslateUi(QDialog *LiveChartOptionsDialog)
    {
        LiveChartOptionsDialog->setWindowTitle(QApplication::translate("LiveChartOptionsDialog", "Live Chart Options", 0));
        cbStormRain->setText(QApplication::translate("LiveChartOptionsDialog", "Show rainfall as storm rain (running total until 24 hours without rainfall)", 0));
        label_2->setText(QApplication::translate("LiveChartOptionsDialog", "Timespan:", 0));
        sbTimespan->setSuffix(QApplication::translate("LiveChartOptionsDialog", " minutes", 0));
        cbAverageUpdates->setTitle(QApplication::translate("LiveChartOptionsDialog", "Average Updates", 0));
        label->setText(QApplication::translate("LiveChartOptionsDialog", "Period", 0));
        cbMaxRainRate->setText(QApplication::translate("LiveChartOptionsDialog", "Show maximum rain rate over period", 0));
        sbPeriod->setSuffix(QApplication::translate("LiveChartOptionsDialog", " seconds", 0));
        groupBox->setTitle(QApplication::translate("LiveChartOptionsDialog", "Layout", 0));
        label_3->setText(QApplication::translate("LiveChartOptionsDialog", "Changing the charts layout will cause it to be reset", 0));
        cbAxisTags->setText(QApplication::translate("LiveChartOptionsDialog", "Show axis tags (shifts all value axis to the right)", 0));
        cbMultiAxisRect->setText(QApplication::translate("LiveChartOptionsDialog", "Plot each graph separately", 0));
    } // retranslateUi

};

namespace Ui {
    class LiveChartOptionsDialog: public Ui_LiveChartOptionsDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LIVECHARTOPTIONSDIALOG_H
