/********************************************************************************
** Form generated from reading UI file 'viewdatasetwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIEWDATASETWINDOW_H
#define UI_VIEWDATASETWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ViewDataSetWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QTableView *tableView;

    void setupUi(QMainWindow *ViewDataSetWindow)
    {
        if (ViewDataSetWindow->objectName().isEmpty())
            ViewDataSetWindow->setObjectName(QStringLiteral("ViewDataSetWindow"));
        ViewDataSetWindow->resize(834, 622);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/table"), QSize(), QIcon::Normal, QIcon::Off);
        ViewDataSetWindow->setWindowIcon(icon);
        centralwidget = new QWidget(ViewDataSetWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        tableView = new QTableView(centralwidget);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setSortingEnabled(true);
        tableView->horizontalHeader()->setCascadingSectionResizes(false);
        tableView->horizontalHeader()->setProperty("showSortIndicator", QVariant(true));
        tableView->horizontalHeader()->setStretchLastSection(false);
        tableView->verticalHeader()->setDefaultSectionSize(23);

        gridLayout->addWidget(tableView, 0, 0, 1, 1);

        ViewDataSetWindow->setCentralWidget(centralwidget);

        retranslateUi(ViewDataSetWindow);

        QMetaObject::connectSlotsByName(ViewDataSetWindow);
    } // setupUi

    void retranslateUi(QMainWindow *ViewDataSetWindow)
    {
        ViewDataSetWindow->setWindowTitle(QApplication::translate("ViewDataSetWindow", "View Data", 0));
    } // retranslateUi

};

namespace Ui {
    class ViewDataSetWindow: public Ui_ViewDataSetWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIEWDATASETWINDOW_H
