/********************************************************************************
** Form generated from reading UI file 'addlivegraphdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDLIVEGRAPHDIALOG_H
#define UI_ADDLIVEGRAPHDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_AddLiveGraphDialog
{
public:
    QGridLayout *gridLayout;
    QDialogButtonBox *buttonBox;
    QVBoxLayout *verticalLayout_7;
    QGroupBox *gbTemperature;
    QVBoxLayout *verticalLayout;
    QCheckBox *cbTemperature;
    QCheckBox *cbInsideTemperature;
    QCheckBox *cbApparentTemperature;
    QCheckBox *cbWindChill;
    QCheckBox *cbDewPoint;
    QGroupBox *gbRain;
    QVBoxLayout *verticalLayout_4;
    QCheckBox *cbStormRain;
    QCheckBox *cbRainRate;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout_8;
    QGroupBox *gbWind;
    QVBoxLayout *verticalLayout_3;
    QCheckBox *cbWindSpeed;
    QCheckBox *cbWindDirection;
    QGroupBox *gbHumidity;
    QVBoxLayout *verticalLayout_2;
    QCheckBox *cbHumidity;
    QCheckBox *cbInsideHumidity;
    QGroupBox *gbSolar;
    QVBoxLayout *verticalLayout_5;
    QCheckBox *cbUVIndex;
    QCheckBox *cbSolarRadiation;
    QSpacerItem *verticalSpacer_2;
    QLabel *lblMessage;
    QVBoxLayout *verticalLayout_9;
    QGroupBox *gbOther;
    QVBoxLayout *verticalLayout_6;
    QCheckBox *cbPressure;
    QCheckBox *cbConsoleBattery;
    QSpacerItem *verticalSpacer_3;

    void setupUi(QDialog *AddLiveGraphDialog)
    {
        if (AddLiveGraphDialog->objectName().isEmpty())
            AddLiveGraphDialog->setObjectName(QStringLiteral("AddLiveGraphDialog"));
        AddLiveGraphDialog->resize(464, 305);
        gridLayout = new QGridLayout(AddLiveGraphDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setSizeConstraint(QLayout::SetFixedSize);
        buttonBox = new QDialogButtonBox(AddLiveGraphDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout->addWidget(buttonBox, 6, 1, 1, 3);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        gbTemperature = new QGroupBox(AddLiveGraphDialog);
        gbTemperature->setObjectName(QStringLiteral("gbTemperature"));
        verticalLayout = new QVBoxLayout(gbTemperature);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        cbTemperature = new QCheckBox(gbTemperature);
        cbTemperature->setObjectName(QStringLiteral("cbTemperature"));

        verticalLayout->addWidget(cbTemperature);

        cbInsideTemperature = new QCheckBox(gbTemperature);
        cbInsideTemperature->setObjectName(QStringLiteral("cbInsideTemperature"));

        verticalLayout->addWidget(cbInsideTemperature);

        cbApparentTemperature = new QCheckBox(gbTemperature);
        cbApparentTemperature->setObjectName(QStringLiteral("cbApparentTemperature"));

        verticalLayout->addWidget(cbApparentTemperature);

        cbWindChill = new QCheckBox(gbTemperature);
        cbWindChill->setObjectName(QStringLiteral("cbWindChill"));

        verticalLayout->addWidget(cbWindChill);

        cbDewPoint = new QCheckBox(gbTemperature);
        cbDewPoint->setObjectName(QStringLiteral("cbDewPoint"));

        verticalLayout->addWidget(cbDewPoint);


        verticalLayout_7->addWidget(gbTemperature);

        gbRain = new QGroupBox(AddLiveGraphDialog);
        gbRain->setObjectName(QStringLiteral("gbRain"));
        verticalLayout_4 = new QVBoxLayout(gbRain);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        cbStormRain = new QCheckBox(gbRain);
        cbStormRain->setObjectName(QStringLiteral("cbStormRain"));

        verticalLayout_4->addWidget(cbStormRain);

        cbRainRate = new QCheckBox(gbRain);
        cbRainRate->setObjectName(QStringLiteral("cbRainRate"));

        verticalLayout_4->addWidget(cbRainRate);


        verticalLayout_7->addWidget(gbRain);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_7->addItem(verticalSpacer);


        gridLayout->addLayout(verticalLayout_7, 1, 0, 1, 1);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        gbWind = new QGroupBox(AddLiveGraphDialog);
        gbWind->setObjectName(QStringLiteral("gbWind"));
        verticalLayout_3 = new QVBoxLayout(gbWind);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        cbWindSpeed = new QCheckBox(gbWind);
        cbWindSpeed->setObjectName(QStringLiteral("cbWindSpeed"));

        verticalLayout_3->addWidget(cbWindSpeed);

        cbWindDirection = new QCheckBox(gbWind);
        cbWindDirection->setObjectName(QStringLiteral("cbWindDirection"));

        verticalLayout_3->addWidget(cbWindDirection);


        verticalLayout_8->addWidget(gbWind);

        gbHumidity = new QGroupBox(AddLiveGraphDialog);
        gbHumidity->setObjectName(QStringLiteral("gbHumidity"));
        verticalLayout_2 = new QVBoxLayout(gbHumidity);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        cbHumidity = new QCheckBox(gbHumidity);
        cbHumidity->setObjectName(QStringLiteral("cbHumidity"));

        verticalLayout_2->addWidget(cbHumidity);

        cbInsideHumidity = new QCheckBox(gbHumidity);
        cbInsideHumidity->setObjectName(QStringLiteral("cbInsideHumidity"));

        verticalLayout_2->addWidget(cbInsideHumidity);


        verticalLayout_8->addWidget(gbHumidity);

        gbSolar = new QGroupBox(AddLiveGraphDialog);
        gbSolar->setObjectName(QStringLiteral("gbSolar"));
        verticalLayout_5 = new QVBoxLayout(gbSolar);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        cbUVIndex = new QCheckBox(gbSolar);
        cbUVIndex->setObjectName(QStringLiteral("cbUVIndex"));

        verticalLayout_5->addWidget(cbUVIndex);

        cbSolarRadiation = new QCheckBox(gbSolar);
        cbSolarRadiation->setObjectName(QStringLiteral("cbSolarRadiation"));

        verticalLayout_5->addWidget(cbSolarRadiation);


        verticalLayout_8->addWidget(gbSolar);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_8->addItem(verticalSpacer_2);


        gridLayout->addLayout(verticalLayout_8, 1, 1, 1, 1);

        lblMessage = new QLabel(AddLiveGraphDialog);
        lblMessage->setObjectName(QStringLiteral("lblMessage"));
        lblMessage->setWordWrap(true);

        gridLayout->addWidget(lblMessage, 0, 0, 1, 4);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        gbOther = new QGroupBox(AddLiveGraphDialog);
        gbOther->setObjectName(QStringLiteral("gbOther"));
        verticalLayout_6 = new QVBoxLayout(gbOther);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        cbPressure = new QCheckBox(gbOther);
        cbPressure->setObjectName(QStringLiteral("cbPressure"));

        verticalLayout_6->addWidget(cbPressure);

        cbConsoleBattery = new QCheckBox(gbOther);
        cbConsoleBattery->setObjectName(QStringLiteral("cbConsoleBattery"));

        verticalLayout_6->addWidget(cbConsoleBattery);


        verticalLayout_9->addWidget(gbOther);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_9->addItem(verticalSpacer_3);


        gridLayout->addLayout(verticalLayout_9, 1, 2, 1, 2);

        QWidget::setTabOrder(cbTemperature, cbInsideTemperature);
        QWidget::setTabOrder(cbInsideTemperature, cbApparentTemperature);
        QWidget::setTabOrder(cbApparentTemperature, cbWindChill);
        QWidget::setTabOrder(cbWindChill, cbDewPoint);
        QWidget::setTabOrder(cbDewPoint, cbStormRain);
        QWidget::setTabOrder(cbStormRain, cbRainRate);
        QWidget::setTabOrder(cbRainRate, cbWindSpeed);
        QWidget::setTabOrder(cbWindSpeed, cbWindDirection);
        QWidget::setTabOrder(cbWindDirection, cbHumidity);
        QWidget::setTabOrder(cbHumidity, cbInsideHumidity);
        QWidget::setTabOrder(cbInsideHumidity, cbUVIndex);
        QWidget::setTabOrder(cbUVIndex, cbSolarRadiation);
        QWidget::setTabOrder(cbSolarRadiation, cbPressure);
        QWidget::setTabOrder(cbPressure, cbConsoleBattery);

        retranslateUi(AddLiveGraphDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), AddLiveGraphDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), AddLiveGraphDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(AddLiveGraphDialog);
    } // setupUi

    void retranslateUi(QDialog *AddLiveGraphDialog)
    {
        AddLiveGraphDialog->setWindowTitle(QApplication::translate("AddLiveGraphDialog", "Add Graph", 0));
        gbTemperature->setTitle(QApplication::translate("AddLiveGraphDialog", "Temperature", 0));
        cbTemperature->setText(QApplication::translate("AddLiveGraphDialog", "Temperature", 0));
        cbInsideTemperature->setText(QApplication::translate("AddLiveGraphDialog", "Inside Temperature", 0));
        cbApparentTemperature->setText(QApplication::translate("AddLiveGraphDialog", "Apparent Temperature", 0));
        cbWindChill->setText(QApplication::translate("AddLiveGraphDialog", "Wind Chill", 0));
        cbDewPoint->setText(QApplication::translate("AddLiveGraphDialog", "Dew Point", 0));
        gbRain->setTitle(QApplication::translate("AddLiveGraphDialog", "Rain", 0));
        cbStormRain->setText(QApplication::translate("AddLiveGraphDialog", "Storm Rain", 0));
        cbRainRate->setText(QApplication::translate("AddLiveGraphDialog", "Rain Rate", 0));
        gbWind->setTitle(QApplication::translate("AddLiveGraphDialog", "Wind", 0));
        cbWindSpeed->setText(QApplication::translate("AddLiveGraphDialog", "Wind Speed", 0));
        cbWindDirection->setText(QApplication::translate("AddLiveGraphDialog", "Wind Direction", 0));
        gbHumidity->setTitle(QApplication::translate("AddLiveGraphDialog", "Humidity", 0));
        cbHumidity->setText(QApplication::translate("AddLiveGraphDialog", "Humidity", 0));
        cbInsideHumidity->setText(QApplication::translate("AddLiveGraphDialog", "Inside Humidity", 0));
        gbSolar->setTitle(QApplication::translate("AddLiveGraphDialog", "Solar", 0));
        cbUVIndex->setText(QApplication::translate("AddLiveGraphDialog", "UV Index", 0));
        cbSolarRadiation->setText(QApplication::translate("AddLiveGraphDialog", "Solar Radiation", 0));
        lblMessage->setText(QApplication::translate("AddLiveGraphDialog", "Select the additional graphs you would like to add to the chart. To remove a graph select it in the chart, right click and choose the remove graph option", 0));
        gbOther->setTitle(QApplication::translate("AddLiveGraphDialog", "Other", 0));
        cbPressure->setText(QApplication::translate("AddLiveGraphDialog", "Barometric Pressure", 0));
        cbConsoleBattery->setText(QApplication::translate("AddLiveGraphDialog", "Console Battery Voltage", 0));
    } // retranslateUi

};

namespace Ui {
    class AddLiveGraphDialog: public Ui_AddLiveGraphDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDLIVEGRAPHDIALOG_H
