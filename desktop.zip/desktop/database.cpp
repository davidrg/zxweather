/* Processed by ecpg (4.2.1) */
/* These include files are added by the preprocessor */
#include <ecpglib.h>
#include <ecpgerrno.h>
#include <sqlca.h>
/* End of automatic include section */

#line 1 "database.pgc"
/*****************************************************************************
 *            Created: 23/06/2012
 *          Copyright: (C) Copyright David Goodwin, 2012
 *            License: GNU General Public License
 *****************************************************************************
 *
 *   This is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This software is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this software; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ****************************************************************************/

/*
 * QtSQL module doesn't seem to like Postgres (at least not recent versions).
 * So this is all done with ECPG instead. Yay.
 *
 * Remember: Keep it ANSI_C. Mostly. ECPG doesn't understand C++ but a little
 * bit of it (like the DBSignalAdapter stuff) shouldn't bother it too much.
 */

#include "database.h"
#include <string.h>
#include <stdlib.h>
#include <libpq-fe.h>
#include <QtDebug>

#define LIVE_DATA_UPDATE_CHANNEL "live_data_updated"
#define NEW_IMAGE_CHANNEL "new_image"
#define NEW_SAMPLE_CHANNEL "new_sample_id"

/* Globals */
static DBSignalAdapter* signalAdapter = NULL;
static int station_id = 0;
static char* station_code = 0;
static int station_code_len = 0;
static int station_hw_type = 0;
static int db_version = 1;
static bool connected = false;

/* Forward Declarations */
int wdb_get_station_id(const char*);

/* Setup error handling */
/* exec sql whenever sqlerror  call wdb_print_sqlca ( ) ; */
#line 54 "database.pgc"


/* In the event of a SQL error, print the details to stderr, roll back the
 * transaction, disconnect from the server and exit */
void wdb_print_sqlca()
{
    fprintf(stderr, "A database error has occurred.\n");
    fprintf(stderr, "==== sqlca ====\n");
    fprintf(stderr, "sqlcode: %ld\n", sqlca.sqlcode);
    fprintf(stderr, "sqlerrm.sqlerrml: %d\n", sqlca.sqlerrm.sqlerrml);
    fprintf(stderr, "sqlerrm.sqlerrmc: %s\n", sqlca.sqlerrm.sqlerrmc);
    fprintf(stderr, "sqlerrd: %ld %ld %ld %ld %ld %ld\n", sqlca.sqlerrd[0],sqlca.sqlerrd[1],sqlca.sqlerrd[2],
                                                          sqlca.sqlerrd[3],sqlca.sqlerrd[4],sqlca.sqlerrd[5]);
    fprintf(stderr, "sqlwarn: %d %d %d %d %d %d %d %d\n", sqlca.sqlwarn[0], sqlca.sqlwarn[1], sqlca.sqlwarn[2],
                                                          sqlca.sqlwarn[3], sqlca.sqlwarn[4], sqlca.sqlwarn[5],
                                                          sqlca.sqlwarn[6], sqlca.sqlwarn[7]);
    fprintf(stderr, "sqlstate: %5s\n", sqlca.sqlstate);
    fprintf(stderr, "===============\n");

    if (signalAdapter != NULL)
        signalAdapter->raiseDatabaseError(sqlca.sqlcode,
                                          sqlca.sqlerrm.sqlerrml,
                                          sqlca.sqlerrm.sqlerrmc,
                                          sqlca.sqlerrd,
                                          sqlca.sqlwarn,
                                          sqlca.sqlstate);
    else
        exit(EXIT_FAILURE);
}

void wdb_set_signal_adapter(DBSignalAdapter *adapter) {
    signalAdapter = adapter;
}

/* Checks that the main connection is still OK and if it isn't attempts to
 * reset it */
void check_data_connection() {
    PGconn* conn = ECPGget_PGconn("data_connection");
    if (conn == NULL) {
        qDebug() << "ERROR: NULL connection (primary)";
    }

    /* PQstatus doesn't seem to notice a lost database connection until we do
     * something else that interacts with the connection (like run a query).
     *
     * This may be a result of interference from ECPG as a similar check
     * on the notification connection (which doesn't use ECPG for anything
     * beyond setting up the connection) doesn't have this problem.
     *
     * Similar interference may be the reason why notifications have to be
     * processed on a separate connection too (if we listen on data_connection
     * we never receive them).
     */
    PQconsumeInput(conn);

    if (PQstatus(conn) == CONNECTION_BAD) {
        qDebug() << "Primary database connection seems to have gone bad. Attempting reset.";
        PQreset(conn);
        if (PQstatus(conn) == CONNECTION_BAD) {
            qDebug() << "ERROR: Failed to reestablish primary database connection.";
        } else {
            qDebug() << "Primary reconnect succeeded.";
        }
    }
}

/* Tries to figure out which version the database is. */
int get_db_version() {
    /* exec sql begin declare section */
     
     
    
#line 123 "database.pgc"
 bool db_info_table_exists ;
 
#line 124 "database.pgc"
 int version ;
/* exec sql end declare section */
#line 125 "database.pgc"


    check_data_connection();

    { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "select count ( * ) = 1 from information_schema . tables where table_name = 'db_info'", ECPGt_EOIT, 
	ECPGt_bool,&(db_info_table_exists),(long)1,(long)1,sizeof(bool), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EORT);
#line 130 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 130 "database.pgc"


    /* v0.1 doesn't have the db_info table. Everything else should. */
    if (!db_info_table_exists)
        version = 1;
    else {
        /* For v0.2+ we can just ask the database what version it is */
        { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "select cast ( v as integer ) from db_info where k = 'DB_VERSION'", ECPGt_EOIT, 
	ECPGt_int,&(version),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EORT);
#line 138 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 138 "database.pgc"

    }

    return version;
}

void subscribe_to_notifications(PGconn* conn) {
    PGresult *res = PQexec(conn, "LISTEN " LIVE_DATA_UPDATE_CHANNEL);
    if (PQresultStatus(res) != PGRES_COMMAND_OK) {
        qDebug() << "LISTEN failed. Live data notifications will not be processed.\n";
    }
    PQclear(res);

    // This only works on v1.x
    res = PQexec(conn, "LISTEN " NEW_IMAGE_CHANNEL);
    if (PQresultStatus(res) != PGRES_COMMAND_OK) {
        qDebug() << "LISTEN failed. New image notifications will not be processed.\n";
    }
    PQclear(res);

    // This probably only works on v1.x
    res = PQexec(conn, "LISTEN " NEW_SAMPLE_CHANNEL);
    if (PQresultStatus(res) != PGRES_COMMAND_OK) {
        qDebug() << "LISTEN failed. New sample notifications will not be processed.\n";
    }
    PQclear(res);
}

bool wdb_connect(const char *target, const char *username, const char* password,
                 const char *station) {
    /* exec sql begin declare section */
         
         
         
     
     
    
#line 169 "database.pgc"
 const char * target_l = target ;
 
#line 170 "database.pgc"
 const char * username_l = username ;
 
#line 171 "database.pgc"
 const char * password_l = password ;
 
#line 172 "database.pgc"
 int hw_type ;
 
#line 173 "database.pgc"
 int stat_id ;
/* exec sql end declare section */
#line 174 "database.pgc"



    qDebug() << "Connecting to database...";

    // This is the primary connection and is used for all queries.
    { ECPGconnect(__LINE__, 0, target_l , username_l , password_l , "data_connection", 0); 
#line 180 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 180 "database.pgc"


    if (sqlca.sqlstate[0] != '0' || sqlca.sqlstate[1] != '0')
        return false;

    db_version = get_db_version();
    qDebug() << "Database version: " << db_version;

    qDebug() << "Setting up notification connection...";
    // This connection is used to listen for notifications. This is done on a
    // seperate connection because performing selects with ECPG seems to
    // interfere with receiving notifications.
    { ECPGconnect(__LINE__, 0, target_l , username_l , password_l , "notification_connection", 0); 
#line 192 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 192 "database.pgc"


    /* Subscribe to live data notifications */
    PGconn* conn = ECPGget_PGconn("notification_connection");
    if (conn == NULL) return false;
    subscribe_to_notifications(conn);

    // Switch back to the primary connection and finish off.
    { ECPGsetconn(__LINE__, "data_connection");
#line 200 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 200 "database.pgc"

    { ECPGsetcommit(__LINE__, "off", NULL);
#line 201 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 201 "database.pgc"


    if (db_version > 1)
        station_id = wdb_get_station_id(station);

    station_code_len = strlen(station) + 1; /* +1 for null termination */
    station_code = (char*)malloc(station_code_len);
    memcpy(station_code, station, station_code_len);

    /* Figure out what sort of hardware this station has */
    stat_id = station_id;
    { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "select case when upper ( st . code ) = 'GENERIC' then 0 when upper ( st . code ) = 'FOWH1080' then 1 when upper ( st . code ) = 'DAVIS' then 2 else 0 end from station s inner join station_type st on s . station_type_id = st . station_type_id where s . station_id = $1 ", 
	ECPGt_int,&(stat_id),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, 
	ECPGt_int,&(hw_type),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EORT);
#line 221 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 221 "database.pgc"

    station_hw_type = hw_type;

    connected = true;

    return connected;
}

/* Gets the ID for the specified station code */
int wdb_get_station_id(const char* station) {
    /* exec sql begin declare section */
         
       
    
#line 232 "database.pgc"
 const char * station_code = station ;
 
#line 233 "database.pgc"
 int station_id_param = 0 ;
/* exec sql end declare section */
#line 234 "database.pgc"


    qDebug() << "Getting station id...";

    if (db_version >= 2) {
        qDebug() << "V2+ DB: station " << station;
        { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "select station_id from station where upper ( code ) = upper ( $1  )", 
	ECPGt_char,&(station_code),(long)0,(long)1,(1)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, 
	ECPGt_int,&(station_id_param),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EORT);
#line 243 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 243 "database.pgc"

    } else {
        qDebug() << "V1 DB: skip";
        station_id_param = 0;
    }

    return station_id_param;
}

void wdb_disconnect() {
    { ECPGdisconnect(__LINE__, "data_connection");
#line 253 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 253 "database.pgc"

    { ECPGdisconnect(__LINE__, "notification_connection");
#line 254 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 254 "database.pgc"

    free(station_code);
}

notifications wdb_live_data_available() {
    //qDebug() << "Checking for live data";

    notifications n;
    n.live_data = false;
    n.new_image = false;
    n.image_id = -1;
    n.new_sample = false;
    n.sample_id = -1;

    if (!connected) return n;

    PGconn* conn = ECPGget_PGconn("notification_connection");
    if (conn == NULL) {
        qDebug() << "ERROR: NULL connection (secondary)";
        return n;
    }

    if (PQstatus(conn) == CONNECTION_BAD) {
        qDebug() << "Secondary database connection seems to have gone bad. Attempting reset.";
        PQreset(conn);
        if (PQstatus(conn) == CONNECTION_BAD) {
            qDebug() << "ERROR: Failed to reestablish secondary database connection.";
        } else {
            qDebug() << "Secondary reconnect succeeded.";
            subscribe_to_notifications(conn);
        }
    }
    PGnotify* notification;
    PQconsumeInput(conn);
    while ((notification = PQnotifies(conn)) != NULL) {
/*        qDebug() << "Received notification:" << notification->relname << notification->extra;*/

        if (strcmp(notification->relname, LIVE_DATA_UPDATE_CHANNEL) == 0) {
            if (db_version <= 1) {
                /* the v1 schema doesn't use the payload to indicate station */
                n.live_data = true;
            }
            /* For v2+ schema we need to check the payload to ensure this is
             * for the station we're interested in */
            else if (strncasecmp(station_code, notification->extra, station_code_len) == 0) {
                // Live data is available for the station we are subscribed to.
                n.live_data = true;
            } else {
                /* It's a notification on a v2+ database for a station other
                 * than the one we're interested in. */
                n.live_data = false;
            }
        } else if (strcmp(notification->relname, NEW_IMAGE_CHANNEL) == 0) {
            /* A new image is available! The payload is the Image ID*/
            n.new_image = true;
            n.image_id = atoi(notification->extra);
        } else if (strcmp(notification->relname, NEW_SAMPLE_CHANNEL) == 0) {
            /* A new sample is available! The payload is station_code:sample_id */
            char* part = strtok(notification->extra, ":");
            /* First bit should be station code */
            if (part && strncasecmp(station_code, part, station_code_len)) {
                part = strtok(notification->extra, ":");
                if (part) {
                    n.sample_id = atoi(part);
                    n.new_sample = true;
                }
            }
        } else {
            qDebug() << "Ignore: Unknown channel";
        }
        PQfreemem(notification);
    }

    return n;
}

/* For zxweather v0.1 databases */
live_data_record get_live_data_v1() {
    /* exec sql begin declare section */
       
       
       
       
       
       
       
       
       
     
       
    
#line 333 "database.pgc"
 int indoor_relative_humidity = 0 ;
 
#line 334 "database.pgc"
 float indoor_temperature = 0.0 ;
 
#line 335 "database.pgc"
 int relative_humidity = 0 ;
 
#line 336 "database.pgc"
 float temperature = 0.0 ;
 
#line 337 "database.pgc"
 float dew_point = 0.0 ;
 
#line 338 "database.pgc"
 float wind_chill = 0.0 ;
 
#line 339 "database.pgc"
 float apparent_temperature = 0.0 ;
 
#line 340 "database.pgc"
 float absolute_pressure = 0.0 ;
 
#line 341 "database.pgc"
 float average_wind_speed = 0.0 ;
 
#line 342 "database.pgc"
 char wind_direction [ 4 ] ;
 
#line 343 "database.pgc"
 long download_timestamp = 0 ;
/* exec sql end declare section */
#line 344 "database.pgc"


    qDebug() << "V1 data load";

    memset(wind_direction, '\0', sizeof(char) * 4);

    check_data_connection();

    { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "select ld . indoor_temperature , ld . indoor_relative_humidity , ld . temperature , ld . relative_humidity , ld . dew_point , ld . wind_chill , ld . apparent_temperature , ld . absolute_pressure , ld . average_wind_speed , ld . wind_direction , extract ( epoch from ld . download_timestamp ) :: integer from live_data ld limit 1", ECPGt_EOIT, 
	ECPGt_float,&(indoor_temperature),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(indoor_relative_humidity),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(temperature),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(relative_humidity),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(dew_point),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(wind_chill),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(apparent_temperature),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(absolute_pressure),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(average_wind_speed),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(wind_direction),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_long,&(download_timestamp),(long)1,(long)1,sizeof(long), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EORT);
#line 375 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 375 "database.pgc"


    live_data_record rec;
    rec.indoor_temperature = indoor_temperature;
    rec.indoor_relative_humidity = indoor_relative_humidity;
    rec.temperature = temperature;
    rec.relative_humidity = relative_humidity;
    rec.dew_point = dew_point;
    rec.wind_chill = wind_chill;
    rec.apparent_temperature = apparent_temperature;
    rec.absolute_pressure = absolute_pressure;
    rec.average_wind_speed = average_wind_speed;
    rec.download_timestamp = download_timestamp;
    rec.v1 = true;
    strcpy(rec.wind_direction_str, wind_direction);

    return rec;
}

/* For v0.2+ */
live_data_record get_live_data_v2() {
    /* exec sql begin declare section */
       
       
       
       
       
       
       
       
       
     
     
       
           

    /* Extra stuff for Davis hardware: */
       
       
       
       
       
       
       
       
       
       

    
#line 397 "database.pgc"
 int indoor_relative_humidity = 0 ;
 
#line 398 "database.pgc"
 float indoor_temperature = 0.0 ;
 
#line 399 "database.pgc"
 int relative_humidity = 0 ;
 
#line 400 "database.pgc"
 float temperature = 0.0 ;
 
#line 401 "database.pgc"
 float dew_point = 0.0 ;
 
#line 402 "database.pgc"
 float wind_chill = 0.0 ;
 
#line 403 "database.pgc"
 float apparent_temperature = 0.0 ;
 
#line 404 "database.pgc"
 float absolute_pressure = 0.0 ;
 
#line 405 "database.pgc"
 float average_wind_speed = 0.0 ;
 
#line 406 "database.pgc"
 int wind_direction ;
 
#line 407 "database.pgc"
 int wind_direction_null ;
 
#line 408 "database.pgc"
 long download_timestamp = 0 ;
 
#line 409 "database.pgc"
 int station_id_param = station_id ;
 
#line 412 "database.pgc"
 float rain_rate = 0.0 ;
 
#line 413 "database.pgc"
 float storm_rain = 0.0 ;
 
#line 414 "database.pgc"
 long current_storm_date = 0 ;
 
#line 415 "database.pgc"
 int barometer_trend = 0 ;
 
#line 416 "database.pgc"
 int forecast_icon = 0 ;
 
#line 417 "database.pgc"
 int forecast_rule = 0 ;
 
#line 418 "database.pgc"
 int tx_battery_status = 0 ;
 
#line 419 "database.pgc"
 float console_battery_voltage = 0.0 ;
 
#line 420 "database.pgc"
 float uv_index = 0.0 ;
 
#line 421 "database.pgc"
 float solar_radiation = 0.0 ;
/* exec sql end declare section */
#line 423 "database.pgc"


    qDebug() << "V2 data load for station id" << station_id_param;

    check_data_connection();

    { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "select ld . indoor_temperature , ld . indoor_relative_humidity , ld . temperature , ld . relative_humidity , ld . dew_point , ld . wind_chill , ld . apparent_temperature , ld . absolute_pressure , ld . average_wind_speed , ld . wind_direction , extract ( epoch from ld . download_timestamp ) :: integer from live_data ld where ld . station_id = $1  limit 1", 
	ECPGt_int,&(station_id_param),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, 
	ECPGt_float,&(indoor_temperature),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(indoor_relative_humidity),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(temperature),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(relative_humidity),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(dew_point),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(wind_chill),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(apparent_temperature),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(absolute_pressure),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(average_wind_speed),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(wind_direction),(long)1,(long)1,sizeof(int), 
	ECPGt_int,&(wind_direction_null),(long)1,(long)1,sizeof(int), 
	ECPGt_long,&(download_timestamp),(long)1,(long)1,sizeof(long), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EORT);
#line 453 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 453 "database.pgc"


    live_data_record rec;
    rec.indoor_temperature = indoor_temperature;
    rec.indoor_relative_humidity = indoor_relative_humidity;
    rec.temperature = temperature;
    rec.relative_humidity = relative_humidity;
    rec.dew_point = dew_point;
    rec.wind_chill = wind_chill;
    rec.apparent_temperature = apparent_temperature;
    rec.absolute_pressure = absolute_pressure;
    rec.average_wind_speed = average_wind_speed;
    rec.download_timestamp = download_timestamp;
    rec.wind_direction = wind_direction;
    rec.v1 = false;
    rec.station_type = station_hw_type;

    if (station_hw_type == ST_DAVIS) {
        { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "select bar_trend , rain_rate , storm_rain , coalesce ( extract ( epoch from current_storm_start_date ) :: integer , 0 ) , transmitter_battery , console_battery_voltage , forecast_icon , forecast_rule_id , coalesce ( uv_index , 0 ) , coalesce ( solar_radiation , 0 ) from davis_live_data where station_id = $1  limit 1", 
	ECPGt_int,&(station_id_param),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, 
	ECPGt_int,&(barometer_trend),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(rain_rate),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(storm_rain),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_long,&(current_storm_date),(long)1,(long)1,sizeof(long), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(tx_battery_status),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(console_battery_voltage),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(forecast_icon),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(forecast_rule),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(uv_index),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_float,&(solar_radiation),(long)1,(long)1,sizeof(float), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EORT);
#line 493 "database.pgc"

if (sqlca.sqlcode < 0) wdb_print_sqlca ( );}
#line 493 "database.pgc"


        rec.davis_data.rain_rate = rain_rate;
        rec.davis_data.storm_rain = storm_rain;
        rec.davis_data.current_storm_start_date = current_storm_date;
        rec.davis_data.barometer_trend = barometer_trend;
        rec.davis_data.forecast_icon = forecast_icon;
        rec.davis_data.forecast_rule = forecast_rule;
        rec.davis_data.tx_battery_status = tx_battery_status;
        rec.davis_data.console_battery = console_battery_voltage;
        rec.davis_data.uv_index = uv_index;
        rec.davis_data.solar_radiation = solar_radiation;
    }

    return rec;
}

live_data_record wdb_get_live_data() {

    if (!connected) {
        live_data_record rec;

        rec.indoor_temperature = 0;
        rec.indoor_relative_humidity = 0;
        rec.temperature = 0;
        rec.relative_humidity = 0;
        rec.dew_point = 0;
        rec.wind_chill = 0;
        rec.apparent_temperature = 0;
        rec.absolute_pressure = 0;
        rec.average_wind_speed = 0;
        rec.wind_direction_str[0] = ' ';
        rec.wind_direction_str[1] = ' ';
        rec.wind_direction_str[2] = ' ';
        rec.wind_direction_str[3] = '\0';
        rec.wind_direction = 0;
        rec.download_timestamp = 0;
        rec.v1 = true;
        qDebug() << "Not connected - using empty data";
        return rec;
    }

    if (db_version == 1)
        return get_live_data_v1();
    else
        return get_live_data_v2();
}

int wdb_get_hardware_type() {
    return station_hw_type;
}
