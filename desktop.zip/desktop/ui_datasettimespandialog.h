/********************************************************************************
** Form generated from reading UI file 'datasettimespandialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DATASETTIMESPANDIALOG_H
#define UI_DATASETTIMESPANDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include "timespanwidget.h"

QT_BEGIN_NAMESPACE

class Ui_DataSetTimespanDialog
{
public:
    QGridLayout *gridLayout;
    QDialogButtonBox *buttonBox;
    TimespanWidget *timespan;

    void setupUi(QDialog *DataSetTimespanDialog)
    {
        if (DataSetTimespanDialog->objectName().isEmpty())
            DataSetTimespanDialog->setObjectName(QStringLiteral("DataSetTimespanDialog"));
        DataSetTimespanDialog->resize(403, 92);
        gridLayout = new QGridLayout(DataSetTimespanDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        buttonBox = new QDialogButtonBox(DataSetTimespanDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout->addWidget(buttonBox, 1, 0, 1, 2);

        timespan = new TimespanWidget(DataSetTimespanDialog);
        timespan->setObjectName(QStringLiteral("timespan"));

        gridLayout->addWidget(timespan, 0, 0, 1, 2);


        retranslateUi(DataSetTimespanDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), DataSetTimespanDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DataSetTimespanDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(DataSetTimespanDialog);
    } // setupUi

    void retranslateUi(QDialog *DataSetTimespanDialog)
    {
        DataSetTimespanDialog->setWindowTitle(QApplication::translate("DataSetTimespanDialog", "Data Set Timespan", 0));
    } // retranslateUi

};

namespace Ui {
    class DataSetTimespanDialog: public Ui_DataSetTimespanDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DATASETTIMESPANDIALOG_H
