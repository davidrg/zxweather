/********************************************************************************
** Form generated from reading UI file 'customisechartdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CUSTOMISECHARTDIALOG_H
#define UI_CUSTOMISECHARTDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>
#include "qtcolorbutton/qtcolorbutton.h"

QT_BEGIN_NAMESPACE

class Ui_CustomiseChartDialog
{
public:
    QGridLayout *gridLayout_5;
    QDialogButtonBox *buttonBox;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGroupBox *gbTitle;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *leTitle;
    QtColorButton *clrTitle;
    QGroupBox *gbLegend;
    QGridLayout *gridLayout_4;
    QGridLayout *gridLayout_6;
    QToolButton *tbLegendTopCenter;
    QToolButton *tbLegendTopRight;
    QToolButton *tbLegendCenterLeft;
    QToolButton *tbLegendTopLeft;
    QToolButton *tbLegendBottomLeft;
    QToolButton *tbLegendBottomCenter;
    QToolButton *tbLegendBottomRight;
    QToolButton *tbLegendCenterRight;
    QToolButton *tbLegendCenter;
    QLabel *label_6;
    QtColorButton *clrLegendBackground;
    QLabel *label_3;
    QGroupBox *groupBox;
    QGridLayout *gridLayout;
    QLabel *label_5;
    QtColorButton *clrBackground;
    QLabel *label_9;
    QLineEdit *leImageFile;
    QToolButton *tbBrowseForImage;
    QCheckBox *cbShowGrid;
    QWidget *tab_2;
    QGridLayout *gridLayout_3;
    QGridLayout *graphSettingsLayout;
    QLabel *label_2;
    QLabel *label;
    QFrame *line;
    QLabel *label_4;
    QLabel *label_7;
    QLabel *label_8;
    QFrame *line_2;
    QFrame *line_3;
    QFrame *line_4;
    QFrame *line_5;
    QWidget *tab_3;
    QGridLayout *gridLayout_2;

    void setupUi(QDialog *CustomiseChartDialog)
    {
        if (CustomiseChartDialog->objectName().isEmpty())
            CustomiseChartDialog->setObjectName(QStringLiteral("CustomiseChartDialog"));
        CustomiseChartDialog->resize(608, 386);
        gridLayout_5 = new QGridLayout(CustomiseChartDialog);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        buttonBox = new QDialogButtonBox(CustomiseChartDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout_5->addWidget(buttonBox, 2, 0, 1, 1);

        tabWidget = new QTabWidget(CustomiseChartDialog);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        gbTitle = new QGroupBox(tab);
        gbTitle->setObjectName(QStringLiteral("gbTitle"));
        gbTitle->setGeometry(QRect(10, 10, 223, 56));
        gbTitle->setCheckable(true);
        horizontalLayout_2 = new QHBoxLayout(gbTitle);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        leTitle = new QLineEdit(gbTitle);
        leTitle->setObjectName(QStringLiteral("leTitle"));

        horizontalLayout_2->addWidget(leTitle);

        clrTitle = new QtColorButton(gbTitle);
        clrTitle->setObjectName(QStringLiteral("clrTitle"));
        clrTitle->setMinimumSize(QSize(64, 23));
        clrTitle->setMaximumSize(QSize(64, 23));

        horizontalLayout_2->addWidget(clrTitle);

        gbLegend = new QGroupBox(tab);
        gbLegend->setObjectName(QStringLiteral("gbLegend"));
        gbLegend->setGeometry(QRect(10, 70, 221, 133));
        gbLegend->setCheckable(true);
        gridLayout_4 = new QGridLayout(gbLegend);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        gridLayout_6 = new QGridLayout();
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        tbLegendTopCenter = new QToolButton(gbLegend);
        tbLegendTopCenter->setObjectName(QStringLiteral("tbLegendTopCenter"));

        gridLayout_6->addWidget(tbLegendTopCenter, 0, 1, 1, 1);

        tbLegendTopRight = new QToolButton(gbLegend);
        tbLegendTopRight->setObjectName(QStringLiteral("tbLegendTopRight"));

        gridLayout_6->addWidget(tbLegendTopRight, 0, 2, 1, 1);

        tbLegendCenterLeft = new QToolButton(gbLegend);
        tbLegendCenterLeft->setObjectName(QStringLiteral("tbLegendCenterLeft"));

        gridLayout_6->addWidget(tbLegendCenterLeft, 1, 0, 1, 1);

        tbLegendTopLeft = new QToolButton(gbLegend);
        tbLegendTopLeft->setObjectName(QStringLiteral("tbLegendTopLeft"));

        gridLayout_6->addWidget(tbLegendTopLeft, 0, 0, 1, 1);

        tbLegendBottomLeft = new QToolButton(gbLegend);
        tbLegendBottomLeft->setObjectName(QStringLiteral("tbLegendBottomLeft"));

        gridLayout_6->addWidget(tbLegendBottomLeft, 2, 0, 1, 1);

        tbLegendBottomCenter = new QToolButton(gbLegend);
        tbLegendBottomCenter->setObjectName(QStringLiteral("tbLegendBottomCenter"));

        gridLayout_6->addWidget(tbLegendBottomCenter, 2, 1, 1, 1);

        tbLegendBottomRight = new QToolButton(gbLegend);
        tbLegendBottomRight->setObjectName(QStringLiteral("tbLegendBottomRight"));

        gridLayout_6->addWidget(tbLegendBottomRight, 2, 2, 1, 1);

        tbLegendCenterRight = new QToolButton(gbLegend);
        tbLegendCenterRight->setObjectName(QStringLiteral("tbLegendCenterRight"));

        gridLayout_6->addWidget(tbLegendCenterRight, 1, 2, 1, 1);

        tbLegendCenter = new QToolButton(gbLegend);
        tbLegendCenter->setObjectName(QStringLiteral("tbLegendCenter"));

        gridLayout_6->addWidget(tbLegendCenter, 1, 1, 1, 1);


        gridLayout_4->addLayout(gridLayout_6, 1, 2, 1, 1);

        label_6 = new QLabel(gbLegend);
        label_6->setObjectName(QStringLiteral("label_6"));

        gridLayout_4->addWidget(label_6, 0, 0, 1, 1);

        clrLegendBackground = new QtColorButton(gbLegend);
        clrLegendBackground->setObjectName(QStringLiteral("clrLegendBackground"));
        clrLegendBackground->setMinimumSize(QSize(64, 23));
        clrLegendBackground->setMaximumSize(QSize(64, 23));

        gridLayout_4->addWidget(clrLegendBackground, 0, 2, 1, 1);

        label_3 = new QLabel(gbLegend);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout_4->addWidget(label_3, 1, 0, 1, 1);

        groupBox = new QGroupBox(tab);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(240, 10, 331, 111));
        gridLayout = new QGridLayout(groupBox);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout->addWidget(label_5, 1, 0, 1, 1);

        clrBackground = new QtColorButton(groupBox);
        clrBackground->setObjectName(QStringLiteral("clrBackground"));
        clrBackground->setMinimumSize(QSize(64, 23));
        clrBackground->setMaximumSize(QSize(64, 23));

        gridLayout->addWidget(clrBackground, 1, 1, 1, 1);

        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QStringLiteral("label_9"));

        gridLayout->addWidget(label_9, 2, 0, 1, 1);

        leImageFile = new QLineEdit(groupBox);
        leImageFile->setObjectName(QStringLiteral("leImageFile"));

        gridLayout->addWidget(leImageFile, 2, 1, 1, 1);

        tbBrowseForImage = new QToolButton(groupBox);
        tbBrowseForImage->setObjectName(QStringLiteral("tbBrowseForImage"));

        gridLayout->addWidget(tbBrowseForImage, 2, 2, 1, 1);

        cbShowGrid = new QCheckBox(groupBox);
        cbShowGrid->setObjectName(QStringLiteral("cbShowGrid"));

        gridLayout->addWidget(cbShowGrid, 0, 1, 1, 1);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        gridLayout_3 = new QGridLayout(tab_2);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        graphSettingsLayout = new QGridLayout();
        graphSettingsLayout->setObjectName(QStringLiteral("graphSettingsLayout"));
        label_2 = new QLabel(tab_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        graphSettingsLayout->addWidget(label_2, 0, 1, 1, 1);

        label = new QLabel(tab_2);
        label->setObjectName(QStringLiteral("label"));

        graphSettingsLayout->addWidget(label, 0, 0, 1, 1);

        line = new QFrame(tab_2);
        line->setObjectName(QStringLiteral("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        graphSettingsLayout->addWidget(line, 1, 0, 1, 1);

        label_4 = new QLabel(tab_2);
        label_4->setObjectName(QStringLiteral("label_4"));

        graphSettingsLayout->addWidget(label_4, 0, 2, 1, 1);

        label_7 = new QLabel(tab_2);
        label_7->setObjectName(QStringLiteral("label_7"));

        graphSettingsLayout->addWidget(label_7, 0, 3, 1, 1);

        label_8 = new QLabel(tab_2);
        label_8->setObjectName(QStringLiteral("label_8"));

        graphSettingsLayout->addWidget(label_8, 0, 4, 1, 1);

        line_2 = new QFrame(tab_2);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        graphSettingsLayout->addWidget(line_2, 1, 1, 1, 1);

        line_3 = new QFrame(tab_2);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        graphSettingsLayout->addWidget(line_3, 1, 2, 1, 1);

        line_4 = new QFrame(tab_2);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        graphSettingsLayout->addWidget(line_4, 1, 3, 1, 1);

        line_5 = new QFrame(tab_2);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        graphSettingsLayout->addWidget(line_5, 1, 4, 1, 1);


        gridLayout_3->addLayout(graphSettingsLayout, 0, 0, 1, 1);

        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        gridLayout_2 = new QGridLayout(tab_3);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        tabWidget->addTab(tab_3, QString());

        gridLayout_5->addWidget(tabWidget, 1, 0, 1, 1);


        retranslateUi(CustomiseChartDialog);
        QObject::connect(buttonBox, SIGNAL(rejected()), CustomiseChartDialog, SLOT(reject()));

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(CustomiseChartDialog);
    } // setupUi

    void retranslateUi(QDialog *CustomiseChartDialog)
    {
        CustomiseChartDialog->setWindowTitle(QApplication::translate("CustomiseChartDialog", "Customise Chart", 0));
        gbTitle->setTitle(QApplication::translate("CustomiseChartDialog", "Title", 0));
#ifndef QT_NO_WHATSTHIS
        clrTitle->setWhatsThis(QApplication::translate("CustomiseChartDialog", "Default colour to draw outdoor temperature lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        clrTitle->setText(QString());
        gbLegend->setTitle(QApplication::translate("CustomiseChartDialog", "Legend", 0));
        tbLegendTopCenter->setText(QApplication::translate("CustomiseChartDialog", "...", 0));
        tbLegendTopRight->setText(QApplication::translate("CustomiseChartDialog", "...", 0));
        tbLegendCenterLeft->setText(QApplication::translate("CustomiseChartDialog", "...", 0));
        tbLegendTopLeft->setText(QApplication::translate("CustomiseChartDialog", "...", 0));
        tbLegendBottomLeft->setText(QApplication::translate("CustomiseChartDialog", "...", 0));
        tbLegendBottomCenter->setText(QApplication::translate("CustomiseChartDialog", "...", 0));
        tbLegendBottomRight->setText(QApplication::translate("CustomiseChartDialog", "...", 0));
        tbLegendCenterRight->setText(QApplication::translate("CustomiseChartDialog", "...", 0));
        tbLegendCenter->setText(QApplication::translate("CustomiseChartDialog", "...", 0));
        label_6->setText(QApplication::translate("CustomiseChartDialog", "Background Colour", 0));
#ifndef QT_NO_WHATSTHIS
        clrLegendBackground->setWhatsThis(QApplication::translate("CustomiseChartDialog", "Default colour to draw rainfall lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        clrLegendBackground->setText(QString());
        label_3->setText(QApplication::translate("CustomiseChartDialog", "Location", 0));
        groupBox->setTitle(QApplication::translate("CustomiseChartDialog", "Background", 0));
        label_5->setText(QApplication::translate("CustomiseChartDialog", "Background Colour", 0));
        clrBackground->setText(QString());
        label_9->setText(QApplication::translate("CustomiseChartDialog", "Background Image", 0));
        tbBrowseForImage->setText(QApplication::translate("CustomiseChartDialog", "...", 0));
        cbShowGrid->setText(QApplication::translate("CustomiseChartDialog", "Show Grid", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("CustomiseChartDialog", "General", 0));
        label_2->setText(QApplication::translate("CustomiseChartDialog", "Name:", 0));
        label->setText(QApplication::translate("CustomiseChartDialog", "Graph:", 0));
        label_4->setText(QApplication::translate("CustomiseChartDialog", "Line Style:", 0));
        label_7->setText(QApplication::translate("CustomiseChartDialog", "Point Style:", 0));
        label_8->setText(QApplication::translate("CustomiseChartDialog", "Colour:", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("CustomiseChartDialog", "Graphs", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("CustomiseChartDialog", "Axes", 0));
    } // retranslateUi

};

namespace Ui {
    class CustomiseChartDialog: public Ui_CustomiseChartDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CUSTOMISECHARTDIALOG_H
