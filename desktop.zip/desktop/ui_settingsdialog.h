/********************************************************************************
** Form generated from reading UI file 'settingsdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGSDIALOG_H
#define UI_SETTINGSDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qtcolorbutton/qtcolorbutton.h"

QT_BEGIN_NAMESPACE

class Ui_SettingsDialog
{
public:
    QGridLayout *gridLayout_4;
    QDialogButtonBox *buttonBox;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGridLayout *gridLayout_3;
    QGroupBox *groupBox_6;
    QGridLayout *gridLayout_5;
    QCheckBox *chkMinimiseToSystemTray;
    QCheckBox *chkCloseToSystemTray;
    QSpacerItem *verticalSpacer;
    QGroupBox *gbLiveDataWarning;
    QGridLayout *gridLayout_6;
    QLabel *label_15;
    QSpinBox *sbLiveDataWarningInterval;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_16;
    QGroupBox *groupBox_7;
    QGridLayout *gridLayout;
    QLabel *stationNameLabel;
    QLineEdit *stationNameLineEdit;
    QSpacerItem *horizontalSpacer;
    QLabel *label_7;
    QWidget *dbTab;
    QGridLayout *gridLayout_2;
    QGroupBox *gbDatabase;
    QFormLayout *formLayout_2;
    QLabel *databaseLabel;
    QLineEdit *databaseLineEdit;
    QLabel *hostnameLabel;
    QLineEdit *hostnameLineEdit;
    QLabel *portLabel;
    QSpinBox *portSpinBox;
    QLabel *usernameLabel;
    QLineEdit *usernameLineEdit;
    QLabel *passwordLabel;
    QLineEdit *passwordLineEdit;
    QGroupBox *gbWeb;
    QFormLayout *formLayout;
    QLabel *UrlLabel;
    QLineEdit *UrlLineEdit;
    QLabel *label_5;
    QGroupBox *gbServer;
    QFormLayout *formLayout_3;
    QLabel *label_3;
    QLineEdit *serverHostnameLineEdit;
    QLabel *label_4;
    QSpinBox *serverPortSpinBox;
    QGroupBox *groupBox_4;
    QVBoxLayout *verticalLayout_2;
    QRadioButton *rbSampleDatabase;
    QRadioButton *rbSampleWeb;
    QSpacerItem *verticalSpacer_2;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout;
    QRadioButton *rbLiveDatabase;
    QRadioButton *rbLiveWeb;
    QRadioButton *rbLiveServer;
    QLabel *label_6;
    QWidget *tab_2;
    QVBoxLayout *verticalLayout_3;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_7;
    QtColorButton *qcpGustWindSpeed;
    QLabel *label_19;
    QtColorButton *qcpIndoorTemperature;
    QtColorButton *qcpTemperature;
    QLabel *label_12;
    QLabel *label_17;
    QLabel *label_10;
    QLabel *lblSolarRadiation;
    QLabel *lblUVIndex;
    QtColorButton *qcpSolarRadiation;
    QLabel *label_11;
    QtColorButton *qcpUVIndex;
    QtColorButton *qcpAverageWindSpeed;
    QtColorButton *qcpApparentTemperature;
    QtColorButton *qcpDewPoint;
    QtColorButton *qcpWindChill;
    QLabel *label_13;
    QSpacerItem *horizontalSpacer_3;
    QtColorButton *qcpHumidity;
    QtColorButton *qcpRainfall;
    QtColorButton *qcpIndoorHumidity;
    QLabel *label_9;
    QtColorButton *qcpPressure;
    QLabel *label_14;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_8;
    QLabel *label_18;
    QtColorButton *qcpWindDirection;
    QLabel *label_22;
    QLabel *label_23;
    QtColorButton *qcpReception;
    QtColorButton *qcpEvapotranspiration;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_8;
    QLabel *label_20;
    QtColorButton *qcpTitle;
    QSpacerItem *horizontalSpacer_4;
    QLabel *label_21;
    QtColorButton *qcpBackground;
    QSpacerItem *verticalSpacer_3;

    void setupUi(QDialog *SettingsDialog)
    {
        if (SettingsDialog->objectName().isEmpty())
            SettingsDialog->setObjectName(QStringLiteral("SettingsDialog"));
        SettingsDialog->resize(545, 419);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/settings"), QSize(), QIcon::Normal, QIcon::Off);
        SettingsDialog->setWindowIcon(icon);
        gridLayout_4 = new QGridLayout(SettingsDialog);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        gridLayout_4->setSizeConstraint(QLayout::SetDefaultConstraint);
        buttonBox = new QDialogButtonBox(SettingsDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout_4->addWidget(buttonBox, 2, 0, 1, 1);

        tabWidget = new QTabWidget(SettingsDialog);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        gridLayout_3 = new QGridLayout(tab);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        groupBox_6 = new QGroupBox(tab);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(groupBox_6->sizePolicy().hasHeightForWidth());
        groupBox_6->setSizePolicy(sizePolicy);
        groupBox_6->setMinimumSize(QSize(0, 80));
        gridLayout_5 = new QGridLayout(groupBox_6);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        chkMinimiseToSystemTray = new QCheckBox(groupBox_6);
        chkMinimiseToSystemTray->setObjectName(QStringLiteral("chkMinimiseToSystemTray"));

        gridLayout_5->addWidget(chkMinimiseToSystemTray, 0, 0, 1, 1);

        chkCloseToSystemTray = new QCheckBox(groupBox_6);
        chkCloseToSystemTray->setObjectName(QStringLiteral("chkCloseToSystemTray"));

        gridLayout_5->addWidget(chkCloseToSystemTray, 1, 0, 1, 1);


        gridLayout_3->addWidget(groupBox_6, 2, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer, 4, 0, 1, 1);

        gbLiveDataWarning = new QGroupBox(tab);
        gbLiveDataWarning->setObjectName(QStringLiteral("gbLiveDataWarning"));
        gbLiveDataWarning->setCheckable(true);
        gridLayout_6 = new QGridLayout(gbLiveDataWarning);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        label_15 = new QLabel(gbLiveDataWarning);
        label_15->setObjectName(QStringLiteral("label_15"));

        gridLayout_6->addWidget(label_15, 1, 0, 1, 1);

        sbLiveDataWarningInterval = new QSpinBox(gbLiveDataWarning);
        sbLiveDataWarningInterval->setObjectName(QStringLiteral("sbLiveDataWarningInterval"));
        sbLiveDataWarningInterval->setMaximum(3600);
        sbLiveDataWarningInterval->setValue(60);

        gridLayout_6->addWidget(sbLiveDataWarningInterval, 1, 1, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_6->addItem(horizontalSpacer_2, 1, 2, 1, 1);

        label_16 = new QLabel(gbLiveDataWarning);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setWordWrap(true);

        gridLayout_6->addWidget(label_16, 0, 0, 1, 3);


        gridLayout_3->addWidget(gbLiveDataWarning, 2, 1, 1, 1);

        groupBox_7 = new QGroupBox(tab);
        groupBox_7->setObjectName(QStringLiteral("groupBox_7"));
        gridLayout = new QGridLayout(groupBox_7);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        stationNameLabel = new QLabel(groupBox_7);
        stationNameLabel->setObjectName(QStringLiteral("stationNameLabel"));

        gridLayout->addWidget(stationNameLabel, 1, 0, 1, 1);

        stationNameLineEdit = new QLineEdit(groupBox_7);
        stationNameLineEdit->setObjectName(QStringLiteral("stationNameLineEdit"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(stationNameLineEdit->sizePolicy().hasHeightForWidth());
        stationNameLineEdit->setSizePolicy(sizePolicy1);
        stationNameLineEdit->setMaxLength(5);

        gridLayout->addWidget(stationNameLineEdit, 1, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 1, 2, 1, 1);

        label_7 = new QLabel(groupBox_7);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setWordWrap(true);

        gridLayout->addWidget(label_7, 0, 0, 1, 3);


        gridLayout_3->addWidget(groupBox_7, 1, 0, 1, 2);

        tabWidget->addTab(tab, QString());
        dbTab = new QWidget();
        dbTab->setObjectName(QStringLiteral("dbTab"));
        gridLayout_2 = new QGridLayout(dbTab);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gbDatabase = new QGroupBox(dbTab);
        gbDatabase->setObjectName(QStringLiteral("gbDatabase"));
        formLayout_2 = new QFormLayout(gbDatabase);
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        databaseLabel = new QLabel(gbDatabase);
        databaseLabel->setObjectName(QStringLiteral("databaseLabel"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, databaseLabel);

        databaseLineEdit = new QLineEdit(gbDatabase);
        databaseLineEdit->setObjectName(QStringLiteral("databaseLineEdit"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, databaseLineEdit);

        hostnameLabel = new QLabel(gbDatabase);
        hostnameLabel->setObjectName(QStringLiteral("hostnameLabel"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, hostnameLabel);

        hostnameLineEdit = new QLineEdit(gbDatabase);
        hostnameLineEdit->setObjectName(QStringLiteral("hostnameLineEdit"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, hostnameLineEdit);

        portLabel = new QLabel(gbDatabase);
        portLabel->setObjectName(QStringLiteral("portLabel"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, portLabel);

        portSpinBox = new QSpinBox(gbDatabase);
        portSpinBox->setObjectName(QStringLiteral("portSpinBox"));
        portSpinBox->setMaximum(65535);

        formLayout_2->setWidget(2, QFormLayout::FieldRole, portSpinBox);

        usernameLabel = new QLabel(gbDatabase);
        usernameLabel->setObjectName(QStringLiteral("usernameLabel"));

        formLayout_2->setWidget(3, QFormLayout::LabelRole, usernameLabel);

        usernameLineEdit = new QLineEdit(gbDatabase);
        usernameLineEdit->setObjectName(QStringLiteral("usernameLineEdit"));

        formLayout_2->setWidget(3, QFormLayout::FieldRole, usernameLineEdit);

        passwordLabel = new QLabel(gbDatabase);
        passwordLabel->setObjectName(QStringLiteral("passwordLabel"));

        formLayout_2->setWidget(4, QFormLayout::LabelRole, passwordLabel);

        passwordLineEdit = new QLineEdit(gbDatabase);
        passwordLineEdit->setObjectName(QStringLiteral("passwordLineEdit"));
        passwordLineEdit->setEchoMode(QLineEdit::PasswordEchoOnEdit);

        formLayout_2->setWidget(4, QFormLayout::FieldRole, passwordLineEdit);


        gridLayout_2->addWidget(gbDatabase, 2, 0, 2, 1);

        gbWeb = new QGroupBox(dbTab);
        gbWeb->setObjectName(QStringLiteral("gbWeb"));
        formLayout = new QFormLayout(gbWeb);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        UrlLabel = new QLabel(gbWeb);
        UrlLabel->setObjectName(QStringLiteral("UrlLabel"));

        formLayout->setWidget(1, QFormLayout::LabelRole, UrlLabel);

        UrlLineEdit = new QLineEdit(gbWeb);
        UrlLineEdit->setObjectName(QStringLiteral("UrlLineEdit"));
        UrlLineEdit->setEnabled(true);

        formLayout->setWidget(1, QFormLayout::FieldRole, UrlLineEdit);

        label_5 = new QLabel(gbWeb);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout->setWidget(0, QFormLayout::SpanningRole, label_5);


        gridLayout_2->addWidget(gbWeb, 2, 1, 1, 1);

        gbServer = new QGroupBox(dbTab);
        gbServer->setObjectName(QStringLiteral("gbServer"));
        formLayout_3 = new QFormLayout(gbServer);
        formLayout_3->setObjectName(QStringLiteral("formLayout_3"));
        label_3 = new QLabel(gbServer);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, label_3);

        serverHostnameLineEdit = new QLineEdit(gbServer);
        serverHostnameLineEdit->setObjectName(QStringLiteral("serverHostnameLineEdit"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, serverHostnameLineEdit);

        label_4 = new QLabel(gbServer);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout_3->setWidget(1, QFormLayout::LabelRole, label_4);

        serverPortSpinBox = new QSpinBox(gbServer);
        serverPortSpinBox->setObjectName(QStringLiteral("serverPortSpinBox"));
        serverPortSpinBox->setMaximum(65535);

        formLayout_3->setWidget(1, QFormLayout::FieldRole, serverPortSpinBox);


        gridLayout_2->addWidget(gbServer, 3, 1, 1, 1);

        groupBox_4 = new QGroupBox(dbTab);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        verticalLayout_2 = new QVBoxLayout(groupBox_4);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        rbSampleDatabase = new QRadioButton(groupBox_4);
        rbSampleDatabase->setObjectName(QStringLiteral("rbSampleDatabase"));
        rbSampleDatabase->setEnabled(true);

        verticalLayout_2->addWidget(rbSampleDatabase);

        rbSampleWeb = new QRadioButton(groupBox_4);
        rbSampleWeb->setObjectName(QStringLiteral("rbSampleWeb"));

        verticalLayout_2->addWidget(rbSampleWeb);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_2);


        gridLayout_2->addWidget(groupBox_4, 1, 1, 1, 1);

        groupBox_3 = new QGroupBox(dbTab);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        verticalLayout = new QVBoxLayout(groupBox_3);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        rbLiveDatabase = new QRadioButton(groupBox_3);
        rbLiveDatabase->setObjectName(QStringLiteral("rbLiveDatabase"));

        verticalLayout->addWidget(rbLiveDatabase);

        rbLiveWeb = new QRadioButton(groupBox_3);
        rbLiveWeb->setObjectName(QStringLiteral("rbLiveWeb"));

        verticalLayout->addWidget(rbLiveWeb);

        rbLiveServer = new QRadioButton(groupBox_3);
        rbLiveServer->setObjectName(QStringLiteral("rbLiveServer"));
        rbLiveServer->setEnabled(true);

        verticalLayout->addWidget(rbLiveServer);


        gridLayout_2->addWidget(groupBox_3, 1, 0, 1, 1);

        label_6 = new QLabel(dbTab);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setWordWrap(true);

        gridLayout_2->addWidget(label_6, 0, 0, 1, 2);

        tabWidget->addTab(dbTab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        verticalLayout_3 = new QVBoxLayout(tab_2);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        groupBox = new QGroupBox(tab_2);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout_7 = new QGridLayout(groupBox);
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        qcpGustWindSpeed = new QtColorButton(groupBox);
        qcpGustWindSpeed->setObjectName(QStringLiteral("qcpGustWindSpeed"));
        qcpGustWindSpeed->setMinimumSize(QSize(64, 23));
        qcpGustWindSpeed->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpGustWindSpeed, 9, 4, 1, 1);

        label_19 = new QLabel(groupBox);
        label_19->setObjectName(QStringLiteral("label_19"));

        gridLayout_7->addWidget(label_19, 9, 3, 1, 1);

        qcpIndoorTemperature = new QtColorButton(groupBox);
        qcpIndoorTemperature->setObjectName(QStringLiteral("qcpIndoorTemperature"));
        qcpIndoorTemperature->setMinimumSize(QSize(64, 23));
        qcpIndoorTemperature->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpIndoorTemperature, 0, 4, 1, 1);

        qcpTemperature = new QtColorButton(groupBox);
        qcpTemperature->setObjectName(QStringLiteral("qcpTemperature"));
        qcpTemperature->setMinimumSize(QSize(64, 23));
        qcpTemperature->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpTemperature, 0, 1, 1, 1);

        label_12 = new QLabel(groupBox);
        label_12->setObjectName(QStringLiteral("label_12"));

        gridLayout_7->addWidget(label_12, 5, 3, 1, 1);

        label_17 = new QLabel(groupBox);
        label_17->setObjectName(QStringLiteral("label_17"));

        gridLayout_7->addWidget(label_17, 9, 0, 1, 1);

        label_10 = new QLabel(groupBox);
        label_10->setObjectName(QStringLiteral("label_10"));

        gridLayout_7->addWidget(label_10, 4, 0, 1, 1);

        lblSolarRadiation = new QLabel(groupBox);
        lblSolarRadiation->setObjectName(QStringLiteral("lblSolarRadiation"));

        gridLayout_7->addWidget(lblSolarRadiation, 11, 0, 1, 1);

        lblUVIndex = new QLabel(groupBox);
        lblUVIndex->setObjectName(QStringLiteral("lblUVIndex"));

        gridLayout_7->addWidget(lblUVIndex, 11, 3, 1, 1);

        qcpSolarRadiation = new QtColorButton(groupBox);
        qcpSolarRadiation->setObjectName(QStringLiteral("qcpSolarRadiation"));
        qcpSolarRadiation->setMinimumSize(QSize(64, 23));
        qcpSolarRadiation->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpSolarRadiation, 11, 1, 1, 2);

        label_11 = new QLabel(groupBox);
        label_11->setObjectName(QStringLiteral("label_11"));

        gridLayout_7->addWidget(label_11, 5, 0, 1, 1);

        qcpUVIndex = new QtColorButton(groupBox);
        qcpUVIndex->setObjectName(QStringLiteral("qcpUVIndex"));
        qcpUVIndex->setMinimumSize(QSize(64, 23));
        qcpUVIndex->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpUVIndex, 11, 4, 1, 1);

        qcpAverageWindSpeed = new QtColorButton(groupBox);
        qcpAverageWindSpeed->setObjectName(QStringLiteral("qcpAverageWindSpeed"));
        qcpAverageWindSpeed->setMinimumSize(QSize(64, 23));
        qcpAverageWindSpeed->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpAverageWindSpeed, 9, 1, 1, 1);

        qcpApparentTemperature = new QtColorButton(groupBox);
        qcpApparentTemperature->setObjectName(QStringLiteral("qcpApparentTemperature"));
        qcpApparentTemperature->setMinimumSize(QSize(64, 23));
        qcpApparentTemperature->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpApparentTemperature, 2, 1, 1, 1);

        qcpDewPoint = new QtColorButton(groupBox);
        qcpDewPoint->setObjectName(QStringLiteral("qcpDewPoint"));
        qcpDewPoint->setMinimumSize(QSize(64, 23));
        qcpDewPoint->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpDewPoint, 4, 1, 1, 1);

        qcpWindChill = new QtColorButton(groupBox);
        qcpWindChill->setObjectName(QStringLiteral("qcpWindChill"));
        qcpWindChill->setMinimumSize(QSize(64, 23));
        qcpWindChill->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpWindChill, 2, 4, 1, 1);

        label_13 = new QLabel(groupBox);
        label_13->setObjectName(QStringLiteral("label_13"));

        gridLayout_7->addWidget(label_13, 4, 3, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        gridLayout_7->addItem(horizontalSpacer_3, 0, 2, 1, 1);

        qcpHumidity = new QtColorButton(groupBox);
        qcpHumidity->setObjectName(QStringLiteral("qcpHumidity"));
        qcpHumidity->setMinimumSize(QSize(64, 23));
        qcpHumidity->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpHumidity, 5, 1, 1, 1);

        qcpRainfall = new QtColorButton(groupBox);
        qcpRainfall->setObjectName(QStringLiteral("qcpRainfall"));
        qcpRainfall->setMinimumSize(QSize(64, 23));
        qcpRainfall->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpRainfall, 8, 1, 1, 1);

        qcpIndoorHumidity = new QtColorButton(groupBox);
        qcpIndoorHumidity->setObjectName(QStringLiteral("qcpIndoorHumidity"));
        qcpIndoorHumidity->setMinimumSize(QSize(64, 23));
        qcpIndoorHumidity->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpIndoorHumidity, 5, 4, 1, 1);

        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QStringLiteral("label_9"));

        gridLayout_7->addWidget(label_9, 2, 3, 1, 1);

        qcpPressure = new QtColorButton(groupBox);
        qcpPressure->setObjectName(QStringLiteral("qcpPressure"));
        qcpPressure->setMinimumSize(QSize(64, 23));
        qcpPressure->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpPressure, 4, 4, 1, 1);

        label_14 = new QLabel(groupBox);
        label_14->setObjectName(QStringLiteral("label_14"));

        gridLayout_7->addWidget(label_14, 8, 0, 1, 1);

        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));

        gridLayout_7->addWidget(label, 0, 0, 1, 1);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout_7->addWidget(label_2, 0, 3, 1, 1);

        label_8 = new QLabel(groupBox);
        label_8->setObjectName(QStringLiteral("label_8"));

        gridLayout_7->addWidget(label_8, 2, 0, 1, 1);

        label_18 = new QLabel(groupBox);
        label_18->setObjectName(QStringLiteral("label_18"));

        gridLayout_7->addWidget(label_18, 8, 3, 1, 1);

        qcpWindDirection = new QtColorButton(groupBox);
        qcpWindDirection->setObjectName(QStringLiteral("qcpWindDirection"));
        qcpWindDirection->setMinimumSize(QSize(64, 23));
        qcpWindDirection->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpWindDirection, 8, 4, 1, 1);

        label_22 = new QLabel(groupBox);
        label_22->setObjectName(QStringLiteral("label_22"));

        gridLayout_7->addWidget(label_22, 10, 0, 1, 1);

        label_23 = new QLabel(groupBox);
        label_23->setObjectName(QStringLiteral("label_23"));

        gridLayout_7->addWidget(label_23, 10, 3, 1, 1);

        qcpReception = new QtColorButton(groupBox);
        qcpReception->setObjectName(QStringLiteral("qcpReception"));
        qcpReception->setMinimumSize(QSize(64, 23));
        qcpReception->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpReception, 10, 1, 1, 1);

        qcpEvapotranspiration = new QtColorButton(groupBox);
        qcpEvapotranspiration->setObjectName(QStringLiteral("qcpEvapotranspiration"));
        qcpEvapotranspiration->setMinimumSize(QSize(64, 23));
        qcpEvapotranspiration->setMaximumSize(QSize(64, 23));

        gridLayout_7->addWidget(qcpEvapotranspiration, 10, 4, 1, 1);


        verticalLayout_3->addWidget(groupBox);

        groupBox_2 = new QGroupBox(tab_2);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        gridLayout_8 = new QGridLayout(groupBox_2);
        gridLayout_8->setObjectName(QStringLiteral("gridLayout_8"));
        label_20 = new QLabel(groupBox_2);
        label_20->setObjectName(QStringLiteral("label_20"));

        gridLayout_8->addWidget(label_20, 0, 0, 1, 1);

        qcpTitle = new QtColorButton(groupBox_2);
        qcpTitle->setObjectName(QStringLiteral("qcpTitle"));
        qcpTitle->setMinimumSize(QSize(64, 23));
        qcpTitle->setMaximumSize(QSize(64, 16777215));

        gridLayout_8->addWidget(qcpTitle, 0, 1, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        gridLayout_8->addItem(horizontalSpacer_4, 0, 2, 1, 1);

        label_21 = new QLabel(groupBox_2);
        label_21->setObjectName(QStringLiteral("label_21"));

        gridLayout_8->addWidget(label_21, 0, 3, 1, 1);

        qcpBackground = new QtColorButton(groupBox_2);
        qcpBackground->setObjectName(QStringLiteral("qcpBackground"));
        qcpBackground->setMinimumSize(QSize(64, 23));
        qcpBackground->setMaximumSize(QSize(64, 16777215));

        gridLayout_8->addWidget(qcpBackground, 0, 4, 1, 1);


        verticalLayout_3->addWidget(groupBox_2);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_3);

        tabWidget->addTab(tab_2, QString());

        gridLayout_4->addWidget(tabWidget, 0, 0, 1, 1);

        QWidget::setTabOrder(tabWidget, stationNameLineEdit);
        QWidget::setTabOrder(stationNameLineEdit, chkMinimiseToSystemTray);
        QWidget::setTabOrder(chkMinimiseToSystemTray, chkCloseToSystemTray);
        QWidget::setTabOrder(chkCloseToSystemTray, gbLiveDataWarning);
        QWidget::setTabOrder(gbLiveDataWarning, sbLiveDataWarningInterval);
        QWidget::setTabOrder(sbLiveDataWarningInterval, rbLiveDatabase);
        QWidget::setTabOrder(rbLiveDatabase, rbLiveWeb);
        QWidget::setTabOrder(rbLiveWeb, rbLiveServer);
        QWidget::setTabOrder(rbLiveServer, rbSampleDatabase);
        QWidget::setTabOrder(rbSampleDatabase, rbSampleWeb);
        QWidget::setTabOrder(rbSampleWeb, databaseLineEdit);
        QWidget::setTabOrder(databaseLineEdit, hostnameLineEdit);
        QWidget::setTabOrder(hostnameLineEdit, portSpinBox);
        QWidget::setTabOrder(portSpinBox, usernameLineEdit);
        QWidget::setTabOrder(usernameLineEdit, passwordLineEdit);
        QWidget::setTabOrder(passwordLineEdit, UrlLineEdit);
        QWidget::setTabOrder(UrlLineEdit, serverHostnameLineEdit);
        QWidget::setTabOrder(serverHostnameLineEdit, serverPortSpinBox);
        QWidget::setTabOrder(serverPortSpinBox, qcpTemperature);
        QWidget::setTabOrder(qcpTemperature, qcpApparentTemperature);
        QWidget::setTabOrder(qcpApparentTemperature, qcpDewPoint);
        QWidget::setTabOrder(qcpDewPoint, qcpHumidity);
        QWidget::setTabOrder(qcpHumidity, qcpRainfall);
        QWidget::setTabOrder(qcpRainfall, qcpAverageWindSpeed);
        QWidget::setTabOrder(qcpAverageWindSpeed, qcpReception);
        QWidget::setTabOrder(qcpReception, qcpSolarRadiation);
        QWidget::setTabOrder(qcpSolarRadiation, qcpIndoorTemperature);
        QWidget::setTabOrder(qcpIndoorTemperature, qcpWindChill);
        QWidget::setTabOrder(qcpWindChill, qcpPressure);
        QWidget::setTabOrder(qcpPressure, qcpIndoorHumidity);
        QWidget::setTabOrder(qcpIndoorHumidity, qcpWindDirection);
        QWidget::setTabOrder(qcpWindDirection, qcpGustWindSpeed);
        QWidget::setTabOrder(qcpGustWindSpeed, qcpEvapotranspiration);
        QWidget::setTabOrder(qcpEvapotranspiration, qcpUVIndex);
        QWidget::setTabOrder(qcpUVIndex, qcpTitle);
        QWidget::setTabOrder(qcpTitle, qcpBackground);

        retranslateUi(SettingsDialog);
        QObject::connect(buttonBox, SIGNAL(rejected()), SettingsDialog, SLOT(reject()));

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(SettingsDialog);
    } // setupUi

    void retranslateUi(QDialog *SettingsDialog)
    {
        SettingsDialog->setWindowTitle(QApplication::translate("SettingsDialog", "zxweather Settings", 0));
        groupBox_6->setTitle(QApplication::translate("SettingsDialog", "Minimise Action", 0));
#ifndef QT_NO_TOOLTIP
        chkMinimiseToSystemTray->setToolTip(QApplication::translate("SettingsDialog", "Minimise to the system tray instead of the task bar.", 0));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        chkMinimiseToSystemTray->setWhatsThis(QApplication::translate("SettingsDialog", "When the program is minimised it will minimise to the system tray instead of the task bar.", 0));
#endif // QT_NO_WHATSTHIS
        chkMinimiseToSystemTray->setText(QApplication::translate("SettingsDialog", "Minimise to system tray", 0));
#ifndef QT_NO_TOOLTIP
        chkCloseToSystemTray->setToolTip(QApplication::translate("SettingsDialog", "When the window is closed it will minimise to the system tray instead.", 0));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        chkCloseToSystemTray->setWhatsThis(QApplication::translate("SettingsDialog", "When the window is closed it will minimise to the system tray instead.", 0));
#endif // QT_NO_WHATSTHIS
        chkCloseToSystemTray->setText(QApplication::translate("SettingsDialog", "Minimise to system tray on close", 0));
#ifndef QT_NO_WHATSTHIS
        gbLiveDataWarning->setWhatsThis(QApplication::translate("SettingsDialog", "<html><head/><body><p>If no live data is receivied during the specified interval then a warning popup is displayed from the system tray icon saying when live data was last received. This warning popup is shown at the end of each interval. If the interval is set to 60 seconds then a message will be displayed every 60 seconds until live data is received.</p></body></html>", 0));
#endif // QT_NO_WHATSTHIS
        gbLiveDataWarning->setTitle(QApplication::translate("SettingsDialog", "Warn if live data is late", 0));
        label_15->setText(QApplication::translate("SettingsDialog", "Interval", 0));
        sbLiveDataWarningInterval->setSuffix(QApplication::translate("SettingsDialog", " seconds", 0));
        label_16->setText(QApplication::translate("SettingsDialog", "If no live data is received within the specified interval a warning will be displayed.", 0));
        groupBox_7->setTitle(QApplication::translate("SettingsDialog", "Station", 0));
        stationNameLabel->setText(QApplication::translate("SettingsDialog", "Station Code", 0));
#ifndef QT_NO_WHATSTHIS
        stationNameLineEdit->setWhatsThis(QApplication::translate("SettingsDialog", "The short 5-character code for the station to monitor.", 0));
#endif // QT_NO_WHATSTHIS
        stationNameLineEdit->setPlaceholderText(QApplication::translate("SettingsDialog", "station code", 0));
        label_7->setText(QApplication::translate("SettingsDialog", "<html><head/><body><p>This is the code for the station to monitor. It is present in all web interface URLs. For example: <br/>http://weather.example/s/<span style=\" font-weight:600;\">foo</span>/.</p></body></html>", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("SettingsDialog", "General", 0));
        gbDatabase->setTitle(QApplication::translate("SettingsDialog", "Database", 0));
        databaseLabel->setText(QApplication::translate("SettingsDialog", "Database", 0));
#ifndef QT_NO_TOOLTIP
        databaseLineEdit->setToolTip(QApplication::translate("SettingsDialog", "Name of the database containing weather data", 0));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        databaseLineEdit->setWhatsThis(QApplication::translate("SettingsDialog", "Name of the database containing weather data", 0));
#endif // QT_NO_WHATSTHIS
        hostnameLabel->setText(QApplication::translate("SettingsDialog", "Hostname", 0));
#ifndef QT_NO_TOOLTIP
        hostnameLineEdit->setToolTip(QApplication::translate("SettingsDialog", "IP Address or DNS name of the database server.", 0));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        hostnameLineEdit->setWhatsThis(QApplication::translate("SettingsDialog", "IP Address or DNS name of the database server.", 0));
#endif // QT_NO_WHATSTHIS
        hostnameLineEdit->setPlaceholderText(QApplication::translate("SettingsDialog", "localhost", 0));
        portLabel->setText(QApplication::translate("SettingsDialog", "Port", 0));
#ifndef QT_NO_TOOLTIP
        portSpinBox->setToolTip(QApplication::translate("SettingsDialog", "Port the database server is listening on. This is normally 5432.", 0));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        portSpinBox->setWhatsThis(QApplication::translate("SettingsDialog", "Port the database server is listening on. This is normally 5432.", 0));
#endif // QT_NO_WHATSTHIS
        usernameLabel->setText(QApplication::translate("SettingsDialog", "Username", 0));
#ifndef QT_NO_TOOLTIP
        usernameLineEdit->setToolTip(QApplication::translate("SettingsDialog", "User to login to the database server as", 0));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        usernameLineEdit->setWhatsThis(QApplication::translate("SettingsDialog", "User to login to the database server as", 0));
#endif // QT_NO_WHATSTHIS
        passwordLabel->setText(QApplication::translate("SettingsDialog", "Password", 0));
#ifndef QT_NO_TOOLTIP
        passwordLineEdit->setToolTip(QApplication::translate("SettingsDialog", "Password for the database user account", 0));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        passwordLineEdit->setWhatsThis(QApplication::translate("SettingsDialog", "Password for the database user account", 0));
#endif // QT_NO_WHATSTHIS
        gbWeb->setTitle(QApplication::translate("SettingsDialog", "Web Interface", 0));
        UrlLabel->setText(QApplication::translate("SettingsDialog", "URL", 0));
#ifndef QT_NO_TOOLTIP
        UrlLineEdit->setToolTip(QApplication::translate("SettingsDialog", "<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Web interface URL:</span></p><p>This is the full URL for the data section of the web interface. This will be something like:<br/>http://weather.example.com/data/&lt;your-station-name&gt;/</p><p>If you normally access your station data at:<br/>http://weather.example.com/s/foo/<br/>then the appropriate data URL will be:<br/>http://weather.example.com/data/foo/</p><p>You can enter the data URL into your web browser to confirm it is correct. You should get a &quot;Station Data&quot; page with links to various station-level datasets.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        UrlLineEdit->setWhatsThis(QApplication::translate("SettingsDialog", "<html><head/><body><p><span style=\" font-weight:600; text-decoration: underline;\">Web interface URL:</span></p><p>This is the full URL for the data section of the web interface. This will be something like:<br/>    http://weather.example.com/data/&lt;your-station-name&gt;/</p><p>If you normally access your station data at:<br/>    http://weather.example.com/s/foo/<br/>then the appropriate data URL will be:<br/>    http://weather.example.com/data/foo/</p><p>You can enter the data URL into your web browser to confirm it is correct. You should get a &quot;Station Data&quot; page with links to various station-level datasets.</p></body></html>", 0));
#endif // QT_NO_WHATSTHIS
        UrlLineEdit->setPlaceholderText(QApplication::translate("SettingsDialog", "http://weather.example.com/", 0));
        label_5->setText(QApplication::translate("SettingsDialog", "Enter the base URL for the web interface below:", 0));
        gbServer->setTitle(QApplication::translate("SettingsDialog", "Weather Server", 0));
        label_3->setText(QApplication::translate("SettingsDialog", "Hostname", 0));
#ifndef QT_NO_WHATSTHIS
        serverHostnameLineEdit->setWhatsThis(QApplication::translate("SettingsDialog", "<html><head/><body><p>The host name or Internet Protocol (IP) address for the weather server.</p></body></html>", 0));
#endif // QT_NO_WHATSTHIS
        label_4->setText(QApplication::translate("SettingsDialog", "Port", 0));
#ifndef QT_NO_WHATSTHIS
        serverPortSpinBox->setWhatsThis(QApplication::translate("SettingsDialog", "<html><head/><body><p>The port the weather server is listening on.</p></body></html>", 0));
#endif // QT_NO_WHATSTHIS
        groupBox_4->setTitle(QApplication::translate("SettingsDialog", "Sample Data Source", 0));
#ifndef QT_NO_WHATSTHIS
        rbSampleDatabase->setWhatsThis(QApplication::translate("SettingsDialog", "<html><head/><body><p>Samples for drawing charts are retrieived directly from the database. This is the fastest and most efficient option.</p></body></html>", 0));
#endif // QT_NO_WHATSTHIS
        rbSampleDatabase->setText(QApplication::translate("SettingsDialog", "Database", 0));
#ifndef QT_NO_WHATSTHIS
        rbSampleWeb->setWhatsThis(QApplication::translate("SettingsDialog", "<html><head/><body><p>Samples for drawing charts are downloaded from the web interface one full month at a time.</p></body></html>", 0));
#endif // QT_NO_WHATSTHIS
        rbSampleWeb->setText(QApplication::translate("SettingsDialog", "Web Interface", 0));
        groupBox_3->setTitle(QApplication::translate("SettingsDialog", "Live Data Source", 0));
#ifndef QT_NO_WHATSTHIS
        rbLiveDatabase->setWhatsThis(QApplication::translate("SettingsDialog", "Receives live data from the database. Updates as often as new data is made available in the database.", 0));
#endif // QT_NO_WHATSTHIS
        rbLiveDatabase->setText(QApplication::translate("SettingsDialog", "Database", 0));
#ifndef QT_NO_WHATSTHIS
        rbLiveWeb->setWhatsThis(QApplication::translate("SettingsDialog", "Receives live data from the web interface. This only updates every 30 seconds.", 0));
#endif // QT_NO_WHATSTHIS
        rbLiveWeb->setText(QApplication::translate("SettingsDialog", "Web Interface", 0));
#ifndef QT_NO_WHATSTHIS
        rbLiveServer->setWhatsThis(QApplication::translate("SettingsDialog", "<html><head/><body><p>Receives live data instantly from the weather server. This is the best option if the weather server is available. Note that proxy servers may prevent this from working.</p></body></html>", 0));
#endif // QT_NO_WHATSTHIS
        rbLiveServer->setText(QApplication::translate("SettingsDialog", "Weather Server", 0));
        label_6->setText(QApplication::translate("SettingsDialog", "Due to the different requirements for live data and sample data (used for charts and records) it is possbile to use different data sources for the two. The web interface is always the slowest option. For live data the Weather Server is fastest.", 0));
        tabWidget->setTabText(tabWidget->indexOf(dbTab), QApplication::translate("SettingsDialog", "Data Sources", 0));
        groupBox->setTitle(QApplication::translate("SettingsDialog", "Graphs", 0));
#ifndef QT_NO_WHATSTHIS
        qcpGustWindSpeed->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw rainfall lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpGustWindSpeed->setText(QString());
        label_19->setText(QApplication::translate("SettingsDialog", "Gust Wind Speed", 0));
#ifndef QT_NO_WHATSTHIS
        qcpIndoorTemperature->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw indoor temperature lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpIndoorTemperature->setText(QString());
#ifndef QT_NO_WHATSTHIS
        qcpTemperature->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw outdoor temperature lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpTemperature->setText(QString());
        label_12->setText(QApplication::translate("SettingsDialog", "Humidity (Indoor)", 0));
        label_17->setText(QApplication::translate("SettingsDialog", "Average Wind Speed", 0));
        label_10->setText(QApplication::translate("SettingsDialog", "Dew Point", 0));
        lblSolarRadiation->setText(QApplication::translate("SettingsDialog", "Solar Radiation", 0));
        lblUVIndex->setText(QApplication::translate("SettingsDialog", "UV Index", 0));
#ifndef QT_NO_WHATSTHIS
        qcpSolarRadiation->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw solar radiation lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpSolarRadiation->setText(QString());
        label_11->setText(QApplication::translate("SettingsDialog", "Humidity", 0));
        qcpUVIndex->setText(QString());
#ifndef QT_NO_WHATSTHIS
        qcpAverageWindSpeed->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw rainfall lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpAverageWindSpeed->setText(QString());
#ifndef QT_NO_WHATSTHIS
        qcpApparentTemperature->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw apparent temperature lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpApparentTemperature->setText(QString());
#ifndef QT_NO_WHATSTHIS
        qcpDewPoint->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw dew point lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpDewPoint->setText(QString());
#ifndef QT_NO_WHATSTHIS
        qcpWindChill->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw wind chill lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpWindChill->setText(QString());
        label_13->setText(QApplication::translate("SettingsDialog", "Pressure", 0));
#ifndef QT_NO_WHATSTHIS
        qcpHumidity->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw outdoor humidity lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpHumidity->setText(QString());
#ifndef QT_NO_WHATSTHIS
        qcpRainfall->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw rainfall lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpRainfall->setText(QString());
#ifndef QT_NO_WHATSTHIS
        qcpIndoorHumidity->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw indoor humidity lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpIndoorHumidity->setText(QString());
        label_9->setText(QApplication::translate("SettingsDialog", "Wind Chill", 0));
#ifndef QT_NO_WHATSTHIS
        qcpPressure->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw pressure lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpPressure->setText(QString());
        label_14->setText(QApplication::translate("SettingsDialog", "Rainfall", 0));
        label->setText(QApplication::translate("SettingsDialog", "Temperature", 0));
        label_2->setText(QApplication::translate("SettingsDialog", "Temperature (Indoor)", 0));
        label_8->setText(QApplication::translate("SettingsDialog", "Apparent Temperature", 0));
        label_18->setText(QApplication::translate("SettingsDialog", "Wind Direction", 0));
#ifndef QT_NO_WHATSTHIS
        qcpWindDirection->setWhatsThis(QApplication::translate("SettingsDialog", "Default colour to draw rainfall lines with in charts.", 0));
#endif // QT_NO_WHATSTHIS
        qcpWindDirection->setText(QString());
        label_22->setText(QApplication::translate("SettingsDialog", "Reception", 0));
        label_23->setText(QApplication::translate("SettingsDialog", "Evapotranspiration", 0));
        qcpReception->setText(QString());
        qcpEvapotranspiration->setText(QString());
        groupBox_2->setTitle(QApplication::translate("SettingsDialog", "Chart", 0));
        label_20->setText(QApplication::translate("SettingsDialog", "Title", 0));
        qcpTitle->setText(QString());
        label_21->setText(QApplication::translate("SettingsDialog", "Background", 0));
        qcpBackground->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("SettingsDialog", "Charts", 0));
    } // retranslateUi

};

namespace Ui {
    class SettingsDialog: public Ui_SettingsDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGSDIALOG_H
