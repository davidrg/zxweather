/********************************************************************************
** Form generated from reading UI file 'videoplayer.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIDEOPLAYER_H
#define UI_VIDEOPLAYER_H

#include <QVideoWidget>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_VideoPlayer
{
public:
    QVBoxLayout *verticalLayout;
    QVideoWidget *player;
    QFrame *frame;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout;
    QToolButton *tbPlay;
    QToolButton *tbPause;
    QToolButton *tbStop;
    QSpacerItem *horizontalSpacer;
    QWidget *statusPanel;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *lStatus;
    QLabel *lTime;

    void setupUi(QWidget *VideoPlayer)
    {
        if (VideoPlayer->objectName().isEmpty())
            VideoPlayer->setObjectName(QStringLiteral("VideoPlayer"));
        VideoPlayer->resize(400, 359);
        verticalLayout = new QVBoxLayout(VideoPlayer);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        player = new QVideoWidget(VideoPlayer);
        player->setObjectName(QStringLiteral("player"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(player->sizePolicy().hasHeightForWidth());
        player->setSizePolicy(sizePolicy);
        player->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0)"));

        verticalLayout->addWidget(player);

        frame = new QFrame(VideoPlayer);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setFrameShape(QFrame::Panel);
        frame->setFrameShadow(QFrame::Raised);
        verticalLayout_3 = new QVBoxLayout(frame);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(9, -1, 9, -1);
        tbPlay = new QToolButton(frame);
        tbPlay->setObjectName(QStringLiteral("tbPlay"));
        tbPlay->setCheckable(true);
        tbPlay->setAutoExclusive(true);
        tbPlay->setAutoRaise(true);

        horizontalLayout->addWidget(tbPlay);

        tbPause = new QToolButton(frame);
        tbPause->setObjectName(QStringLiteral("tbPause"));
        tbPause->setCheckable(true);
        tbPause->setAutoExclusive(true);
        tbPause->setAutoRaise(true);

        horizontalLayout->addWidget(tbPause);

        tbStop = new QToolButton(frame);
        tbStop->setObjectName(QStringLiteral("tbStop"));
        tbStop->setCheckable(true);
        tbStop->setChecked(true);
        tbStop->setAutoExclusive(true);
        tbStop->setAutoRaise(true);

        horizontalLayout->addWidget(tbStop);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);


        verticalLayout_3->addLayout(horizontalLayout);


        verticalLayout->addWidget(frame);

        statusPanel = new QWidget(VideoPlayer);
        statusPanel->setObjectName(QStringLiteral("statusPanel"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Minimum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(statusPanel->sizePolicy().hasHeightForWidth());
        statusPanel->setSizePolicy(sizePolicy1);
        statusPanel->setStyleSheet(QLatin1String("background-color: black; \n"
"color: white;"));
        verticalLayout_2 = new QVBoxLayout(statusPanel);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(5, 5, 5, 5);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        lStatus = new QLabel(statusPanel);
        lStatus->setObjectName(QStringLiteral("lStatus"));
        QSizePolicy sizePolicy2(QSizePolicy::MinimumExpanding, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(lStatus->sizePolicy().hasHeightForWidth());
        lStatus->setSizePolicy(sizePolicy2);
        lStatus->setStyleSheet(QStringLiteral(""));

        horizontalLayout_3->addWidget(lStatus);

        lTime = new QLabel(statusPanel);
        lTime->setObjectName(QStringLiteral("lTime"));
        QSizePolicy sizePolicy3(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(lTime->sizePolicy().hasHeightForWidth());
        lTime->setSizePolicy(sizePolicy3);
        lTime->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_3->addWidget(lTime);


        verticalLayout_2->addLayout(horizontalLayout_3);


        verticalLayout->addWidget(statusPanel);

        frame->raise();
        statusPanel->raise();
        player->raise();

        retranslateUi(VideoPlayer);

        QMetaObject::connectSlotsByName(VideoPlayer);
    } // setupUi

    void retranslateUi(QWidget *VideoPlayer)
    {
        VideoPlayer->setWindowTitle(QApplication::translate("VideoPlayer", "Form", 0));
#ifndef QT_NO_TOOLTIP
        tbPlay->setToolTip(QApplication::translate("VideoPlayer", "Play", 0));
#endif // QT_NO_TOOLTIP
        tbPlay->setText(QApplication::translate("VideoPlayer", "Play", 0));
#ifndef QT_NO_TOOLTIP
        tbPause->setToolTip(QApplication::translate("VideoPlayer", "Pause", 0));
#endif // QT_NO_TOOLTIP
        tbPause->setText(QApplication::translate("VideoPlayer", "Pause", 0));
#ifndef QT_NO_TOOLTIP
        tbStop->setToolTip(QApplication::translate("VideoPlayer", "Stop", 0));
#endif // QT_NO_TOOLTIP
        tbStop->setText(QApplication::translate("VideoPlayer", "Stop", 0));
        lStatus->setText(QApplication::translate("VideoPlayer", "No Status", 0));
        lTime->setText(QApplication::translate("VideoPlayer", "0:00 / 0:00", 0));
    } // retranslateUi

};

namespace Ui {
    class VideoPlayer: public Ui_VideoPlayer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIDEOPLAYER_H
