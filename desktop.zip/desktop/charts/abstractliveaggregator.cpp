#include "abstractliveaggregator.h"

AbstractLiveAggregator::AbstractLiveAggregator(QObject *parent) : QObject(parent)
{

}
