/********************************************************************************
** Form generated from reading UI file 'livedatawidget.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LIVEDATAWIDGET_H
#define UI_LIVEDATAWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>
#include "dash_widgets/weathervaluewidget.h"

QT_BEGIN_NAMESPACE

class Ui_LiveDataWidget
{
public:
    QGridLayout *gridLayout_2;
    QGridLayout *conditionsLayout;
    QLabel *uvIndex;
    QLabel *label_7;
    QLabel *lblTimestamp;
    QLabel *label_6;
    QLabel *label_4;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_5;
    QLabel *label;
    QLabel *rainRate;
    QLabel *label_10;
    QLabel *currentStormRain;
    QLabel *label_8;
    QFrame *line;
    QLabel *lblCurrentStormStartDate;
    QLabel *currentStormStart;
    QLabel *solarRadiation;
    WeatherValueWidget *lblTemperature;
    WeatherValueWidget *lblApparentTemperature;
    WeatherValueWidget *lblWindChill;
    WeatherValueWidget *lblDewPoint;
    WeatherValueWidget *lblHumidity;
    WeatherValueWidget *lblBarometer;
    WeatherValueWidget *lblWindSpeed;
    WeatherValueWidget *lblWindDirection;
    WeatherValueWidget *lblUVIndex;
    WeatherValueWidget *lblSolarRadiation;
    WeatherValueWidget *lblRainRate;
    WeatherValueWidget *lblStormRain;

    void setupUi(QWidget *LiveDataWidget)
    {
        if (LiveDataWidget->objectName().isEmpty())
            LiveDataWidget->setObjectName(QStringLiteral("LiveDataWidget"));
        LiveDataWidget->resize(343, 271);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(LiveDataWidget->sizePolicy().hasHeightForWidth());
        LiveDataWidget->setSizePolicy(sizePolicy);
        LiveDataWidget->setMinimumSize(QSize(343, 261));
        LiveDataWidget->setMaximumSize(QSize(343, 271));
        gridLayout_2 = new QGridLayout(LiveDataWidget);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        conditionsLayout = new QGridLayout();
        conditionsLayout->setSpacing(6);
        conditionsLayout->setObjectName(QStringLiteral("conditionsLayout"));
        uvIndex = new QLabel(LiveDataWidget);
        uvIndex->setObjectName(QStringLiteral("uvIndex"));

        conditionsLayout->addWidget(uvIndex, 10, 0, 1, 1);

        label_7 = new QLabel(LiveDataWidget);
        label_7->setObjectName(QStringLiteral("label_7"));

        conditionsLayout->addWidget(label_7, 7, 0, 1, 1);

        lblTimestamp = new QLabel(LiveDataWidget);
        lblTimestamp->setObjectName(QStringLiteral("lblTimestamp"));
        lblTimestamp->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        conditionsLayout->addWidget(lblTimestamp, 0, 1, 1, 1);

        label_6 = new QLabel(LiveDataWidget);
        label_6->setObjectName(QStringLiteral("label_6"));

        conditionsLayout->addWidget(label_6, 6, 0, 1, 1);

        label_4 = new QLabel(LiveDataWidget);
        label_4->setObjectName(QStringLiteral("label_4"));

        conditionsLayout->addWidget(label_4, 4, 0, 1, 1);

        label_2 = new QLabel(LiveDataWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        conditionsLayout->addWidget(label_2, 2, 0, 1, 1);

        label_3 = new QLabel(LiveDataWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        conditionsLayout->addWidget(label_3, 3, 0, 1, 1);

        label_5 = new QLabel(LiveDataWidget);
        label_5->setObjectName(QStringLiteral("label_5"));

        conditionsLayout->addWidget(label_5, 5, 0, 1, 1);

        label = new QLabel(LiveDataWidget);
        label->setObjectName(QStringLiteral("label"));

        conditionsLayout->addWidget(label, 0, 0, 1, 1);

        rainRate = new QLabel(LiveDataWidget);
        rainRate->setObjectName(QStringLiteral("rainRate"));

        conditionsLayout->addWidget(rainRate, 12, 0, 1, 1);

        label_10 = new QLabel(LiveDataWidget);
        label_10->setObjectName(QStringLiteral("label_10"));

        conditionsLayout->addWidget(label_10, 9, 0, 1, 1);

        currentStormRain = new QLabel(LiveDataWidget);
        currentStormRain->setObjectName(QStringLiteral("currentStormRain"));

        conditionsLayout->addWidget(currentStormRain, 13, 0, 1, 1);

        label_8 = new QLabel(LiveDataWidget);
        label_8->setObjectName(QStringLiteral("label_8"));

        conditionsLayout->addWidget(label_8, 8, 0, 1, 1);

        line = new QFrame(LiveDataWidget);
        line->setObjectName(QStringLiteral("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        conditionsLayout->addWidget(line, 1, 0, 1, 2);

        lblCurrentStormStartDate = new QLabel(LiveDataWidget);
        lblCurrentStormStartDate->setObjectName(QStringLiteral("lblCurrentStormStartDate"));

        conditionsLayout->addWidget(lblCurrentStormStartDate, 14, 1, 1, 1);

        currentStormStart = new QLabel(LiveDataWidget);
        currentStormStart->setObjectName(QStringLiteral("currentStormStart"));

        conditionsLayout->addWidget(currentStormStart, 14, 0, 1, 1);

        solarRadiation = new QLabel(LiveDataWidget);
        solarRadiation->setObjectName(QStringLiteral("solarRadiation"));

        conditionsLayout->addWidget(solarRadiation, 11, 0, 1, 1);

        lblTemperature = new WeatherValueWidget(LiveDataWidget);
        lblTemperature->setObjectName(QStringLiteral("lblTemperature"));

        conditionsLayout->addWidget(lblTemperature, 2, 1, 1, 1);

        lblApparentTemperature = new WeatherValueWidget(LiveDataWidget);
        lblApparentTemperature->setObjectName(QStringLiteral("lblApparentTemperature"));

        conditionsLayout->addWidget(lblApparentTemperature, 3, 1, 1, 1);

        lblWindChill = new WeatherValueWidget(LiveDataWidget);
        lblWindChill->setObjectName(QStringLiteral("lblWindChill"));

        conditionsLayout->addWidget(lblWindChill, 4, 1, 1, 1);

        lblDewPoint = new WeatherValueWidget(LiveDataWidget);
        lblDewPoint->setObjectName(QStringLiteral("lblDewPoint"));

        conditionsLayout->addWidget(lblDewPoint, 5, 1, 1, 1);

        lblHumidity = new WeatherValueWidget(LiveDataWidget);
        lblHumidity->setObjectName(QStringLiteral("lblHumidity"));

        conditionsLayout->addWidget(lblHumidity, 6, 1, 1, 1);

        lblBarometer = new WeatherValueWidget(LiveDataWidget);
        lblBarometer->setObjectName(QStringLiteral("lblBarometer"));

        conditionsLayout->addWidget(lblBarometer, 7, 1, 1, 1);

        lblWindSpeed = new WeatherValueWidget(LiveDataWidget);
        lblWindSpeed->setObjectName(QStringLiteral("lblWindSpeed"));

        conditionsLayout->addWidget(lblWindSpeed, 8, 1, 1, 1);

        lblWindDirection = new WeatherValueWidget(LiveDataWidget);
        lblWindDirection->setObjectName(QStringLiteral("lblWindDirection"));

        conditionsLayout->addWidget(lblWindDirection, 9, 1, 1, 1);

        lblUVIndex = new WeatherValueWidget(LiveDataWidget);
        lblUVIndex->setObjectName(QStringLiteral("lblUVIndex"));

        conditionsLayout->addWidget(lblUVIndex, 10, 1, 1, 1);

        lblSolarRadiation = new WeatherValueWidget(LiveDataWidget);
        lblSolarRadiation->setObjectName(QStringLiteral("lblSolarRadiation"));

        conditionsLayout->addWidget(lblSolarRadiation, 11, 1, 1, 1);

        lblRainRate = new WeatherValueWidget(LiveDataWidget);
        lblRainRate->setObjectName(QStringLiteral("lblRainRate"));

        conditionsLayout->addWidget(lblRainRate, 12, 1, 1, 1);

        lblStormRain = new WeatherValueWidget(LiveDataWidget);
        lblStormRain->setObjectName(QStringLiteral("lblStormRain"));

        conditionsLayout->addWidget(lblStormRain, 13, 1, 1, 1);


        gridLayout_2->addLayout(conditionsLayout, 0, 0, 2, 1);


        retranslateUi(LiveDataWidget);

        QMetaObject::connectSlotsByName(LiveDataWidget);
    } // setupUi

    void retranslateUi(QWidget *LiveDataWidget)
    {
        LiveDataWidget->setWindowTitle(QApplication::translate("LiveDataWidget", "Form", 0));
        uvIndex->setText(QApplication::translate("LiveDataWidget", "UV Index", 0));
        label_7->setText(QApplication::translate("LiveDataWidget", "Barometer:", 0));
        lblTimestamp->setText(QString());
        label_6->setText(QApplication::translate("LiveDataWidget", "Humidity:", 0));
        label_4->setText(QApplication::translate("LiveDataWidget", "Wind Chill:", 0));
        label_2->setText(QApplication::translate("LiveDataWidget", "Temperature:", 0));
        label_3->setText(QApplication::translate("LiveDataWidget", "Apparent Temperature:", 0));
        label_5->setText(QApplication::translate("LiveDataWidget", "Dew Point:", 0));
        label->setText(QApplication::translate("LiveDataWidget", "<b>Current Conditions</b>", 0));
        rainRate->setText(QApplication::translate("LiveDataWidget", "Rain Rate:", 0));
        label_10->setText(QApplication::translate("LiveDataWidget", "Wind Direction:", 0));
        currentStormRain->setText(QApplication::translate("LiveDataWidget", "Current Storm Rain:", 0));
        label_8->setText(QApplication::translate("LiveDataWidget", "Wind Speed:", 0));
        lblCurrentStormStartDate->setText(QString());
        currentStormStart->setText(QApplication::translate("LiveDataWidget", "Current Storm Start Date:", 0));
        solarRadiation->setText(QApplication::translate("LiveDataWidget", "Solar Radiation", 0));
    } // retranslateUi

};

namespace Ui {
    class LiveDataWidget: public Ui_LiveDataWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LIVEDATAWIDGET_H
