/********************************************************************************
** Form generated from reading UI file 'weatherimagewindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WEATHERIMAGEWINDOW_H
#define UI_WEATHERIMAGEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>
#include "dash_widgets/weathervaluewidget.h"
#include "imagewidget.h"

QT_BEGIN_NAMESPACE

class Ui_WeatherImageWindow
{
public:
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    ImageWidget *image;
    QWidget *widget_2;
    QGridLayout *gridLayout_3;
    QGridLayout *gridLayout_2;
    QLabel *label;
    QLabel *time;
    QLabel *label_17;
    QLabel *label_3;
    QLabel *label_19;
    QLabel *label_23;
    QLabel *label_21;
    QLabel *label_5;
    QLabel *label_9;
    QLabel *label_7;
    QSpacerItem *verticalSpacer;
    QLabel *label_15;
    QLabel *label_11;
    QLabel *label_13;
    QLabel *label_2;
    QLabel *date;
    WeatherValueWidget *temperature;
    WeatherValueWidget *apparentTemperature;
    WeatherValueWidget *windChill;
    WeatherValueWidget *dewPoint;
    WeatherValueWidget *humidity;
    WeatherValueWidget *barometer;
    WeatherValueWidget *windSpeed;
    WeatherValueWidget *windDirection;
    WeatherValueWidget *uvIndex;
    WeatherValueWidget *solarRadiation;
    WeatherValueWidget *rain;
    QLabel *message;

    void setupUi(QWidget *WeatherImageWindow)
    {
        if (WeatherImageWindow->objectName().isEmpty())
            WeatherImageWindow->setObjectName(QStringLiteral("WeatherImageWindow"));
        WeatherImageWindow->resize(869, 355);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(WeatherImageWindow->sizePolicy().hasHeightForWidth());
        WeatherImageWindow->setSizePolicy(sizePolicy);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/image"), QSize(), QIcon::Normal, QIcon::Off);
        WeatherImageWindow->setWindowIcon(icon);
        gridLayout = new QGridLayout(WeatherImageWindow);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        gridLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        image = new ImageWidget(WeatherImageWindow);
        image->setObjectName(QStringLiteral("image"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(image->sizePolicy().hasHeightForWidth());
        image->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(image);

        widget_2 = new QWidget(WeatherImageWindow);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        sizePolicy.setHeightForWidth(widget_2->sizePolicy().hasHeightForWidth());
        widget_2->setSizePolicy(sizePolicy);
        widget_2->setMinimumSize(QSize(250, 0));
        gridLayout_3 = new QGridLayout(widget_2);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gridLayout_3->setContentsMargins(9, 9, 9, 9);
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setSizeConstraint(QLayout::SetDefaultConstraint);
        label = new QLabel(widget_2);
        label->setObjectName(QStringLiteral("label"));

        gridLayout_2->addWidget(label, 1, 0, 1, 1);

        time = new QLabel(widget_2);
        time->setObjectName(QStringLiteral("time"));

        gridLayout_2->addWidget(time, 1, 1, 1, 1);

        label_17 = new QLabel(widget_2);
        label_17->setObjectName(QStringLiteral("label_17"));

        gridLayout_2->addWidget(label_17, 9, 0, 1, 1);

        label_3 = new QLabel(widget_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout_2->addWidget(label_3, 2, 0, 1, 1);

        label_19 = new QLabel(widget_2);
        label_19->setObjectName(QStringLiteral("label_19"));

        gridLayout_2->addWidget(label_19, 10, 0, 1, 1);

        label_23 = new QLabel(widget_2);
        label_23->setObjectName(QStringLiteral("label_23"));

        gridLayout_2->addWidget(label_23, 12, 0, 1, 1);

        label_21 = new QLabel(widget_2);
        label_21->setObjectName(QStringLiteral("label_21"));

        gridLayout_2->addWidget(label_21, 11, 0, 1, 1);

        label_5 = new QLabel(widget_2);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout_2->addWidget(label_5, 3, 0, 1, 1);

        label_9 = new QLabel(widget_2);
        label_9->setObjectName(QStringLiteral("label_9"));

        gridLayout_2->addWidget(label_9, 5, 0, 1, 1);

        label_7 = new QLabel(widget_2);
        label_7->setObjectName(QStringLiteral("label_7"));

        gridLayout_2->addWidget(label_7, 4, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer, 13, 0, 1, 1);

        label_15 = new QLabel(widget_2);
        label_15->setObjectName(QStringLiteral("label_15"));

        gridLayout_2->addWidget(label_15, 8, 0, 1, 1);

        label_11 = new QLabel(widget_2);
        label_11->setObjectName(QStringLiteral("label_11"));

        gridLayout_2->addWidget(label_11, 6, 0, 1, 1);

        label_13 = new QLabel(widget_2);
        label_13->setObjectName(QStringLiteral("label_13"));

        gridLayout_2->addWidget(label_13, 7, 0, 1, 1);

        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout_2->addWidget(label_2, 0, 0, 1, 1);

        date = new QLabel(widget_2);
        date->setObjectName(QStringLiteral("date"));

        gridLayout_2->addWidget(date, 0, 1, 1, 1);

        temperature = new WeatherValueWidget(widget_2);
        temperature->setObjectName(QStringLiteral("temperature"));

        gridLayout_2->addWidget(temperature, 2, 1, 1, 1);

        apparentTemperature = new WeatherValueWidget(widget_2);
        apparentTemperature->setObjectName(QStringLiteral("apparentTemperature"));

        gridLayout_2->addWidget(apparentTemperature, 3, 1, 1, 1);

        windChill = new WeatherValueWidget(widget_2);
        windChill->setObjectName(QStringLiteral("windChill"));

        gridLayout_2->addWidget(windChill, 4, 1, 1, 1);

        dewPoint = new WeatherValueWidget(widget_2);
        dewPoint->setObjectName(QStringLiteral("dewPoint"));

        gridLayout_2->addWidget(dewPoint, 5, 1, 1, 1);

        humidity = new WeatherValueWidget(widget_2);
        humidity->setObjectName(QStringLiteral("humidity"));

        gridLayout_2->addWidget(humidity, 6, 1, 1, 1);

        barometer = new WeatherValueWidget(widget_2);
        barometer->setObjectName(QStringLiteral("barometer"));

        gridLayout_2->addWidget(barometer, 7, 1, 1, 1);

        windSpeed = new WeatherValueWidget(widget_2);
        windSpeed->setObjectName(QStringLiteral("windSpeed"));

        gridLayout_2->addWidget(windSpeed, 8, 1, 1, 1);

        windDirection = new WeatherValueWidget(widget_2);
        windDirection->setObjectName(QStringLiteral("windDirection"));

        gridLayout_2->addWidget(windDirection, 9, 1, 1, 1);

        uvIndex = new WeatherValueWidget(widget_2);
        uvIndex->setObjectName(QStringLiteral("uvIndex"));

        gridLayout_2->addWidget(uvIndex, 10, 1, 1, 1);

        solarRadiation = new WeatherValueWidget(widget_2);
        solarRadiation->setObjectName(QStringLiteral("solarRadiation"));

        gridLayout_2->addWidget(solarRadiation, 11, 1, 1, 1);

        rain = new WeatherValueWidget(widget_2);
        rain->setObjectName(QStringLiteral("rain"));

        gridLayout_2->addWidget(rain, 12, 1, 1, 1);


        gridLayout_3->addLayout(gridLayout_2, 0, 0, 1, 1);

        message = new QLabel(widget_2);
        message->setObjectName(QStringLiteral("message"));
        message->setAlignment(Qt::AlignBottom|Qt::AlignRight|Qt::AlignTrailing);

        gridLayout_3->addWidget(message, 1, 0, 1, 1);


        horizontalLayout->addWidget(widget_2);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);


        retranslateUi(WeatherImageWindow);

        QMetaObject::connectSlotsByName(WeatherImageWindow);
    } // setupUi

    void retranslateUi(QWidget *WeatherImageWindow)
    {
        WeatherImageWindow->setWindowTitle(QApplication::translate("WeatherImageWindow", "Image", 0));
        label->setText(QApplication::translate("WeatherImageWindow", "Time:", 0));
        time->setText(QString());
        label_17->setText(QApplication::translate("WeatherImageWindow", "Wind Direction:", 0));
        label_3->setText(QApplication::translate("WeatherImageWindow", "Temperature:", 0));
        label_19->setText(QApplication::translate("WeatherImageWindow", "UV Index:", 0));
        label_23->setText(QApplication::translate("WeatherImageWindow", "Rain:", 0));
        label_21->setText(QApplication::translate("WeatherImageWindow", "Solar Radiation:", 0));
        label_5->setText(QApplication::translate("WeatherImageWindow", "Apparent temperature:", 0));
        label_9->setText(QApplication::translate("WeatherImageWindow", "Dew Point:", 0));
        label_7->setText(QApplication::translate("WeatherImageWindow", "Wind Chill:", 0));
        label_15->setText(QApplication::translate("WeatherImageWindow", "Wind Speed:", 0));
        label_11->setText(QApplication::translate("WeatherImageWindow", "Humidity:", 0));
        label_13->setText(QApplication::translate("WeatherImageWindow", "Barometer:", 0));
        label_2->setText(QApplication::translate("WeatherImageWindow", "Date:", 0));
        date->setText(QString());
        message->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class WeatherImageWindow: public Ui_WeatherImageWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WEATHERIMAGEWINDOW_H
