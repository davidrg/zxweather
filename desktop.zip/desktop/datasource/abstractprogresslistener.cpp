#include "abstractprogresslistener.h"

AbstractProgressListener::AbstractProgressListener(QObject *parent) : QObject(parent)
{

}
