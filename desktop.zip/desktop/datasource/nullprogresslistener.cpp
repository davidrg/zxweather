#include "nullprogresslistener.h"

NullProgressListener::NullProgressListener(QObject *parent) : AbstractProgressListener(parent)
{

}
