This directory contains 3rd-party libraries and code required to build this
software. Some of it is only used on Windows as that platform has no standard
way of handling libraries.

   
libecpg-9.1-win32
   libecpg libraries and headers for Win32 compiled with MinGW. Built from the
   PostgreSQL 9.1.2 sources. Used only for windows builds as there is no
   standard place for these to live.
   
