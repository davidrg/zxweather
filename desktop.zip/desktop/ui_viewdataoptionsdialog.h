/********************************************************************************
** Form generated from reading UI file 'viewdataoptionsdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIEWDATAOPTIONSDIALOG_H
#define UI_VIEWDATAOPTIONSDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include "aggregateoptionswidget.h"
#include "timespanwidget.h"

QT_BEGIN_NAMESPACE

class Ui_ViewDataOptionsDialog
{
public:
    QGridLayout *gridLayout_2;
    QDialogButtonBox *buttonBox;
    QGroupBox *gbAggregate;
    QGridLayout *gridLayout;
    QLabel *label_2;
    AggregateOptionsWidget *aggregateWidget;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_3;
    TimespanWidget *timespan;

    void setupUi(QDialog *ViewDataOptionsDialog)
    {
        if (ViewDataOptionsDialog->objectName().isEmpty())
            ViewDataOptionsDialog->setObjectName(QStringLiteral("ViewDataOptionsDialog"));
        ViewDataOptionsDialog->resize(422, 158);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/table"), QSize(), QIcon::Normal, QIcon::Off);
        ViewDataOptionsDialog->setWindowIcon(icon);
        gridLayout_2 = new QGridLayout(ViewDataOptionsDialog);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        buttonBox = new QDialogButtonBox(ViewDataOptionsDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout_2->addWidget(buttonBox, 2, 0, 1, 1);

        gbAggregate = new QGroupBox(ViewDataOptionsDialog);
        gbAggregate->setObjectName(QStringLiteral("gbAggregate"));
        gbAggregate->setCheckable(true);
        gbAggregate->setChecked(false);
        gridLayout = new QGridLayout(gbAggregate);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label_2 = new QLabel(gbAggregate);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 0, 0, 1, 1);

        aggregateWidget = new AggregateOptionsWidget(gbAggregate);
        aggregateWidget->setObjectName(QStringLiteral("aggregateWidget"));

        gridLayout->addWidget(aggregateWidget, 1, 0, 1, 1);


        gridLayout_2->addWidget(gbAggregate, 1, 0, 1, 1);

        groupBox = new QGroupBox(ViewDataOptionsDialog);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout_3 = new QGridLayout(groupBox);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        timespan = new TimespanWidget(groupBox);
        timespan->setObjectName(QStringLiteral("timespan"));

        gridLayout_3->addWidget(timespan, 0, 0, 1, 1);


        gridLayout_2->addWidget(groupBox, 0, 0, 1, 1);


        retranslateUi(ViewDataOptionsDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), ViewDataOptionsDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ViewDataOptionsDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(ViewDataOptionsDialog);
    } // setupUi

    void retranslateUi(QDialog *ViewDataOptionsDialog)
    {
        ViewDataOptionsDialog->setWindowTitle(QApplication::translate("ViewDataOptionsDialog", "View Data Options", 0));
        gbAggregate->setTitle(QApplication::translate("ViewDataOptionsDialog", "Aggregate", 0));
        label_2->setText(QApplication::translate("ViewDataOptionsDialog", "This allows you to view hourly averages, daily rainfall totals, monthly highs, etc.", 0));
        groupBox->setTitle(QApplication::translate("ViewDataOptionsDialog", "Timespan", 0));
    } // retranslateUi

};

namespace Ui {
    class ViewDataOptionsDialog: public Ui_ViewDataOptionsDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIEWDATAOPTIONSDIALOG_H
