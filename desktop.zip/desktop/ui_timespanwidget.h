/********************************************************************************
** Form generated from reading UI file 'timespanwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TIMESPANWIDGET_H
#define UI_TIMESPANWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TimespanWidget
{
public:
    QGridLayout *gridLayout;
    QRadioButton *rbTToday;
    QRadioButton *rbTYesterday;
    QRadioButton *rbTThisWeek;
    QRadioButton *rbTThisMonth;
    QRadioButton *rbTThisYear;
    QHBoxLayout *horizontalLayout;
    QRadioButton *rbTCustom;
    QDateTimeEdit *startTime;
    QLabel *label;
    QDateTimeEdit *endTime;

    void setupUi(QWidget *TimespanWidget)
    {
        if (TimespanWidget->objectName().isEmpty())
            TimespanWidget->setObjectName(QStringLiteral("TimespanWidget"));
        TimespanWidget->resize(361, 45);
        gridLayout = new QGridLayout(TimespanWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        rbTToday = new QRadioButton(TimespanWidget);
        rbTToday->setObjectName(QStringLiteral("rbTToday"));
        rbTToday->setChecked(true);

        gridLayout->addWidget(rbTToday, 0, 0, 1, 1);

        rbTYesterday = new QRadioButton(TimespanWidget);
        rbTYesterday->setObjectName(QStringLiteral("rbTYesterday"));

        gridLayout->addWidget(rbTYesterday, 0, 1, 1, 1);

        rbTThisWeek = new QRadioButton(TimespanWidget);
        rbTThisWeek->setObjectName(QStringLiteral("rbTThisWeek"));

        gridLayout->addWidget(rbTThisWeek, 0, 2, 1, 1);

        rbTThisMonth = new QRadioButton(TimespanWidget);
        rbTThisMonth->setObjectName(QStringLiteral("rbTThisMonth"));

        gridLayout->addWidget(rbTThisMonth, 0, 3, 1, 1);

        rbTThisYear = new QRadioButton(TimespanWidget);
        rbTThisYear->setObjectName(QStringLiteral("rbTThisYear"));

        gridLayout->addWidget(rbTThisYear, 0, 4, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        rbTCustom = new QRadioButton(TimespanWidget);
        rbTCustom->setObjectName(QStringLiteral("rbTCustom"));

        horizontalLayout->addWidget(rbTCustom);

        startTime = new QDateTimeEdit(TimespanWidget);
        startTime->setObjectName(QStringLiteral("startTime"));
        startTime->setEnabled(false);
        startTime->setKeyboardTracking(false);

        horizontalLayout->addWidget(startTime);

        label = new QLabel(TimespanWidget);
        label->setObjectName(QStringLiteral("label"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(label);

        endTime = new QDateTimeEdit(TimespanWidget);
        endTime->setObjectName(QStringLiteral("endTime"));
        endTime->setEnabled(false);
        endTime->setCalendarPopup(false);

        horizontalLayout->addWidget(endTime);


        gridLayout->addLayout(horizontalLayout, 1, 0, 1, 5);


        retranslateUi(TimespanWidget);

        QMetaObject::connectSlotsByName(TimespanWidget);
    } // setupUi

    void retranslateUi(QWidget *TimespanWidget)
    {
        TimespanWidget->setWindowTitle(QApplication::translate("TimespanWidget", "Form", 0));
        rbTToday->setText(QApplication::translate("TimespanWidget", "Today", 0));
        rbTYesterday->setText(QApplication::translate("TimespanWidget", "Yesterday", 0));
        rbTThisWeek->setText(QApplication::translate("TimespanWidget", "This week", 0));
        rbTThisMonth->setText(QApplication::translate("TimespanWidget", "This month", 0));
        rbTThisYear->setText(QApplication::translate("TimespanWidget", "This year", 0));
        rbTCustom->setText(QApplication::translate("TimespanWidget", "Custom:", 0));
        startTime->setDisplayFormat(QApplication::translate("TimespanWidget", "yyyy-MM-dd hh:mm:ss", 0));
        label->setText(QApplication::translate("TimespanWidget", "to", 0));
        endTime->setDisplayFormat(QApplication::translate("TimespanWidget", "yyyy-MM-dd hh:mm:ss", 0));
    } // retranslateUi

};

namespace Ui {
    class TimespanWidget: public Ui_TimespanWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TIMESPANWIDGET_H
