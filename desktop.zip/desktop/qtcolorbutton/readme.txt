These files were copied from QtCreator.
