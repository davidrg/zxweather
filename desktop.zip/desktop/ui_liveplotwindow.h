/********************************************************************************
** Form generated from reading UI file 'liveplotwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LIVEPLOTWINDOW_H
#define UI_LIVEPLOTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>
#include "charts/liveplot.h"

QT_BEGIN_NAMESPACE

class Ui_LivePlotWindow
{
public:
    QAction *actionAdd_Graph;
    QAction *actionSave;
    QAction *actionCopy;
    QAction *actionRemove_Graph;
    QAction *actionTitle;
    QAction *actionLegend;
    QAction *actionOptions;
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    LivePlot *plot;
    QMenuBar *menubar;
    QToolBar *toolBar;

    void setupUi(QMainWindow *LivePlotWindow)
    {
        if (LivePlotWindow->objectName().isEmpty())
            LivePlotWindow->setObjectName(QStringLiteral("LivePlotWindow"));
        LivePlotWindow->resize(799, 454);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/chart"), QSize(), QIcon::Normal, QIcon::Off);
        LivePlotWindow->setWindowIcon(icon);
        actionAdd_Graph = new QAction(LivePlotWindow);
        actionAdd_Graph->setObjectName(QStringLiteral("actionAdd_Graph"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/chart-add"), QSize(), QIcon::Normal, QIcon::Off);
        actionAdd_Graph->setIcon(icon1);
        actionSave = new QAction(LivePlotWindow);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/icons/save"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave->setIcon(icon2);
        actionCopy = new QAction(LivePlotWindow);
        actionCopy->setObjectName(QStringLiteral("actionCopy"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/icons/copy"), QSize(), QIcon::Normal, QIcon::Off);
        actionCopy->setIcon(icon3);
        actionRemove_Graph = new QAction(LivePlotWindow);
        actionRemove_Graph->setObjectName(QStringLiteral("actionRemove_Graph"));
        actionRemove_Graph->setEnabled(false);
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/icons/chart-remove"), QSize(), QIcon::Normal, QIcon::Off);
        actionRemove_Graph->setIcon(icon4);
        actionTitle = new QAction(LivePlotWindow);
        actionTitle->setObjectName(QStringLiteral("actionTitle"));
        actionTitle->setCheckable(true);
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/icons/title"), QSize(), QIcon::Normal, QIcon::Off);
        actionTitle->setIcon(icon5);
        actionLegend = new QAction(LivePlotWindow);
        actionLegend->setObjectName(QStringLiteral("actionLegend"));
        actionLegend->setCheckable(true);
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/icons/legend"), QSize(), QIcon::Normal, QIcon::Off);
        actionLegend->setIcon(icon6);
        actionOptions = new QAction(LivePlotWindow);
        actionOptions->setObjectName(QStringLiteral("actionOptions"));
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/icons/options"), QSize(), QIcon::Normal, QIcon::Off);
        actionOptions->setIcon(icon7);
        centralwidget = new QWidget(LivePlotWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        plot = new LivePlot(centralwidget);
        plot->setObjectName(QStringLiteral("plot"));

        gridLayout->addWidget(plot, 0, 0, 1, 1);

        LivePlotWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(LivePlotWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 799, 21));
        LivePlotWindow->setMenuBar(menubar);
        toolBar = new QToolBar(LivePlotWindow);
        toolBar->setObjectName(QStringLiteral("toolBar"));
        toolBar->setIconSize(QSize(16, 16));
        toolBar->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        LivePlotWindow->addToolBar(Qt::TopToolBarArea, toolBar);

        toolBar->addAction(actionAdd_Graph);
        toolBar->addAction(actionRemove_Graph);
        toolBar->addSeparator();
        toolBar->addAction(actionOptions);
        toolBar->addAction(actionTitle);
        toolBar->addAction(actionLegend);
        toolBar->addSeparator();
        toolBar->addAction(actionSave);
        toolBar->addAction(actionCopy);

        retranslateUi(LivePlotWindow);

        QMetaObject::connectSlotsByName(LivePlotWindow);
    } // setupUi

    void retranslateUi(QMainWindow *LivePlotWindow)
    {
        LivePlotWindow->setWindowTitle(QApplication::translate("LivePlotWindow", "Live Chart", 0));
        actionAdd_Graph->setText(QApplication::translate("LivePlotWindow", "Add Graph", 0));
        actionSave->setText(QApplication::translate("LivePlotWindow", "Save", 0));
        actionCopy->setText(QApplication::translate("LivePlotWindow", "Copy", 0));
        actionRemove_Graph->setText(QApplication::translate("LivePlotWindow", "Remove Graph", 0));
        actionTitle->setText(QApplication::translate("LivePlotWindow", "Title", 0));
        actionLegend->setText(QApplication::translate("LivePlotWindow", "Legend", 0));
        actionOptions->setText(QApplication::translate("LivePlotWindow", "Options", 0));
        toolBar->setWindowTitle(QApplication::translate("LivePlotWindow", "toolBar", 0));
    } // retranslateUi

};

namespace Ui {
    class LivePlotWindow: public Ui_LivePlotWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LIVEPLOTWINDOW_H
