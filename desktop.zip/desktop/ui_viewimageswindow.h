/********************************************************************************
** Form generated from reading UI file 'viewimageswindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIEWIMAGESWINDOW_H
#define UI_VIEWIMAGESWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QListView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QWidget>
#include "imagewidget.h"

QT_BEGIN_NAMESPACE

class Ui_ViewImagesWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_4;
    QSplitter *splitter_2;
    QTreeView *tvImageSet;
    QSplitter *splitter;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QGridLayout *gridLayout_3;
    ImageWidget *lImage;
    QListView *lvImageList;

    void setupUi(QMainWindow *ViewImagesWindow)
    {
        if (ViewImagesWindow->objectName().isEmpty())
            ViewImagesWindow->setObjectName(QStringLiteral("ViewImagesWindow"));
        ViewImagesWindow->resize(860, 633);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/image"), QSize(), QIcon::Normal, QIcon::Off);
        ViewImagesWindow->setWindowIcon(icon);
        centralwidget = new QWidget(ViewImagesWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        gridLayout_4 = new QGridLayout(centralwidget);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        gridLayout_4->setContentsMargins(2, 2, 2, 2);
        splitter_2 = new QSplitter(centralwidget);
        splitter_2->setObjectName(QStringLiteral("splitter_2"));
        splitter_2->setOrientation(Qt::Horizontal);
        tvImageSet = new QTreeView(splitter_2);
        tvImageSet->setObjectName(QStringLiteral("tvImageSet"));
        tvImageSet->setContextMenuPolicy(Qt::CustomContextMenu);
        tvImageSet->setFrameShadow(QFrame::Plain);
        tvImageSet->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tvImageSet->setDragEnabled(true);
        tvImageSet->setDragDropMode(QAbstractItemView::DragOnly);
        tvImageSet->setRootIsDecorated(true);
        splitter_2->addWidget(tvImageSet);
        tvImageSet->header()->setVisible(false);
        splitter = new QSplitter(splitter_2);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setOrientation(Qt::Vertical);
        scrollArea = new QScrollArea(splitter);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(0, 0, 0, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette.setBrush(QPalette::Active, QPalette::Light, brush1);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush1);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush1);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush1);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush1);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush1);
        QBrush brush2(QColor(255, 255, 220, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush2);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush1);
        scrollArea->setPalette(palette);
        scrollArea->setFrameShape(QFrame::StyledPanel);
        scrollArea->setFrameShadow(QFrame::Plain);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 423, 69));
        gridLayout_3 = new QGridLayout(scrollAreaWidgetContents);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        lImage = new ImageWidget(scrollAreaWidgetContents);
        lImage->setObjectName(QStringLiteral("lImage"));

        gridLayout_3->addWidget(lImage, 0, 0, 1, 1);

        scrollArea->setWidget(scrollAreaWidgetContents);
        splitter->addWidget(scrollArea);
        lvImageList = new QListView(splitter);
        lvImageList->setObjectName(QStringLiteral("lvImageList"));
        lvImageList->setContextMenuPolicy(Qt::CustomContextMenu);
        lvImageList->setAcceptDrops(false);
        lvImageList->setFrameShape(QFrame::StyledPanel);
        lvImageList->setFrameShadow(QFrame::Plain);
        lvImageList->setEditTriggers(QAbstractItemView::NoEditTriggers);
        lvImageList->setDragEnabled(true);
        lvImageList->setDragDropMode(QAbstractItemView::NoDragDrop);
        lvImageList->setSelectionMode(QAbstractItemView::ExtendedSelection);
        lvImageList->setMovement(QListView::Static);
        lvImageList->setResizeMode(QListView::Adjust);
        lvImageList->setSpacing(5);
        lvImageList->setViewMode(QListView::IconMode);
        splitter->addWidget(lvImageList);
        splitter_2->addWidget(splitter);

        gridLayout_4->addWidget(splitter_2, 0, 0, 1, 1);

        ViewImagesWindow->setCentralWidget(centralwidget);

        retranslateUi(ViewImagesWindow);

        QMetaObject::connectSlotsByName(ViewImagesWindow);
    } // setupUi

    void retranslateUi(QMainWindow *ViewImagesWindow)
    {
        ViewImagesWindow->setWindowTitle(QApplication::translate("ViewImagesWindow", "Images", 0));
    } // retranslateUi

};

namespace Ui {
    class ViewImagesWindow: public Ui_ViewImagesWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIEWIMAGESWINDOW_H
