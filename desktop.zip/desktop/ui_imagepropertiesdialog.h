/********************************************************************************
** Form generated from reading UI file 'imagepropertiesdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_IMAGEPROPERTIESDIALOG_H
#define UI_IMAGEPROPERTIESDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ImagePropertiesDialog
{
public:
    QGridLayout *gridLayout;
    QDialogButtonBox *buttonBox;
    QTabWidget *tabWidget;
    QWidget *genrealTab;
    QGridLayout *gridLayout_3;
    QGridLayout *gridLayout_2;
    QLabel *size;
    QFrame *line;
    QLabel *timeStamp;
    QFrame *line_3;
    QLabel *sourceName;
    QLabel *title;
    QLabel *icon;
    QLabel *label_13;
    QSpacerItem *horizontalSpacer;
    QLabel *label_9;
    QLabel *label_5;
    QLabel *mimeType;
    QLabel *label_7;
    QLabel *label_3;
    QFrame *line_2;
    QLabel *description;
    QLabel *label_11;
    QLabel *typeName;
    QLabel *dimensionsLabel;
    QLabel *dimensions;
    QSpacerItem *verticalSpacer;
    QWidget *metadataTab;
    QGridLayout *gridLayout_4;
    QTreeWidget *metadataTree;

    void setupUi(QDialog *ImagePropertiesDialog)
    {
        if (ImagePropertiesDialog->objectName().isEmpty())
            ImagePropertiesDialog->setObjectName(QStringLiteral("ImagePropertiesDialog"));
        ImagePropertiesDialog->resize(361, 477);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ImagePropertiesDialog->sizePolicy().hasHeightForWidth());
        ImagePropertiesDialog->setSizePolicy(sizePolicy);
        ImagePropertiesDialog->setMinimumSize(QSize(361, 477));
        ImagePropertiesDialog->setMaximumSize(QSize(361, 477));
        gridLayout = new QGridLayout(ImagePropertiesDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        gridLayout->setContentsMargins(6, 6, 6, 6);
        buttonBox = new QDialogButtonBox(ImagePropertiesDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Ok);

        gridLayout->addWidget(buttonBox, 1, 0, 1, 1);

        tabWidget = new QTabWidget(ImagePropertiesDialog);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        genrealTab = new QWidget();
        genrealTab->setObjectName(QStringLiteral("genrealTab"));
        gridLayout_3 = new QGridLayout(genrealTab);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gridLayout_3->setContentsMargins(13, 13, 13, 13);
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setVerticalSpacing(10);
        size = new QLabel(genrealTab);
        size->setObjectName(QStringLiteral("size"));
        size->setWordWrap(true);

        gridLayout_2->addWidget(size, 10, 1, 1, 1);

        line = new QFrame(genrealTab);
        line->setObjectName(QStringLiteral("line"));
        line->setLineWidth(2);
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        gridLayout_2->addWidget(line, 1, 0, 1, 2);

        timeStamp = new QLabel(genrealTab);
        timeStamp->setObjectName(QStringLiteral("timeStamp"));

        gridLayout_2->addWidget(timeStamp, 0, 1, 1, 1);

        line_3 = new QFrame(genrealTab);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShadow(QFrame::Sunken);
        line_3->setFrameShape(QFrame::HLine);

        gridLayout_2->addWidget(line_3, 9, 0, 1, 2);

        sourceName = new QLabel(genrealTab);
        sourceName->setObjectName(QStringLiteral("sourceName"));
        sourceName->setWordWrap(true);

        gridLayout_2->addWidget(sourceName, 3, 1, 1, 1);

        title = new QLabel(genrealTab);
        title->setObjectName(QStringLiteral("title"));
        title->setWordWrap(true);

        gridLayout_2->addWidget(title, 7, 1, 1, 1);

        icon = new QLabel(genrealTab);
        icon->setObjectName(QStringLiteral("icon"));
        icon->setMinimumSize(QSize(32, 32));

        gridLayout_2->addWidget(icon, 0, 0, 1, 1);

        label_13 = new QLabel(genrealTab);
        label_13->setObjectName(QStringLiteral("label_13"));

        gridLayout_2->addWidget(label_13, 10, 0, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 11, 1, 1, 1);

        label_9 = new QLabel(genrealTab);
        label_9->setObjectName(QStringLiteral("label_9"));

        gridLayout_2->addWidget(label_9, 7, 0, 1, 1);

        label_5 = new QLabel(genrealTab);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout_2->addWidget(label_5, 4, 0, 1, 1);

        mimeType = new QLabel(genrealTab);
        mimeType->setObjectName(QStringLiteral("mimeType"));
        mimeType->setWordWrap(true);

        gridLayout_2->addWidget(mimeType, 4, 1, 1, 1);

        label_7 = new QLabel(genrealTab);
        label_7->setObjectName(QStringLiteral("label_7"));

        gridLayout_2->addWidget(label_7, 3, 0, 1, 1);

        label_3 = new QLabel(genrealTab);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout_2->addWidget(label_3, 2, 0, 1, 1);

        line_2 = new QFrame(genrealTab);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        gridLayout_2->addWidget(line_2, 6, 0, 1, 2);

        description = new QLabel(genrealTab);
        description->setObjectName(QStringLiteral("description"));
        description->setWordWrap(true);

        gridLayout_2->addWidget(description, 8, 1, 1, 1);

        label_11 = new QLabel(genrealTab);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_2->addWidget(label_11, 8, 0, 1, 1);

        typeName = new QLabel(genrealTab);
        typeName->setObjectName(QStringLiteral("typeName"));
        typeName->setWordWrap(true);

        gridLayout_2->addWidget(typeName, 2, 1, 1, 1);

        dimensionsLabel = new QLabel(genrealTab);
        dimensionsLabel->setObjectName(QStringLiteral("dimensionsLabel"));

        gridLayout_2->addWidget(dimensionsLabel, 5, 0, 1, 1);

        dimensions = new QLabel(genrealTab);
        dimensions->setObjectName(QStringLiteral("dimensions"));
        dimensions->setWordWrap(true);

        gridLayout_2->addWidget(dimensions, 5, 1, 1, 1);


        gridLayout_3->addLayout(gridLayout_2, 0, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer, 1, 0, 1, 1);

        tabWidget->addTab(genrealTab, QString());
        metadataTab = new QWidget();
        metadataTab->setObjectName(QStringLiteral("metadataTab"));
        gridLayout_4 = new QGridLayout(metadataTab);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        gridLayout_4->setContentsMargins(13, 13, 13, 13);
        metadataTree = new QTreeWidget(metadataTab);
        metadataTree->setObjectName(QStringLiteral("metadataTree"));
        metadataTree->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        metadataTree->setRootIsDecorated(false);
        metadataTree->header()->setCascadingSectionResizes(true);

        gridLayout_4->addWidget(metadataTree, 0, 0, 1, 1);

        tabWidget->addTab(metadataTab, QString());

        gridLayout->addWidget(tabWidget, 0, 0, 1, 1);


        retranslateUi(ImagePropertiesDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), ImagePropertiesDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ImagePropertiesDialog, SLOT(reject()));

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(ImagePropertiesDialog);
    } // setupUi

    void retranslateUi(QDialog *ImagePropertiesDialog)
    {
        ImagePropertiesDialog->setWindowTitle(QApplication::translate("ImagePropertiesDialog", "Dialog", 0));
        size->setText(QString());
        timeStamp->setText(QString());
        sourceName->setText(QString());
        title->setText(QString());
        icon->setText(QString());
        label_13->setText(QApplication::translate("ImagePropertiesDialog", "Size:", 0));
        label_9->setText(QApplication::translate("ImagePropertiesDialog", "Title:", 0));
        label_5->setText(QApplication::translate("ImagePropertiesDialog", "MIME type:", 0));
        mimeType->setText(QString());
        label_7->setText(QApplication::translate("ImagePropertiesDialog", "Source:", 0));
        label_3->setText(QApplication::translate("ImagePropertiesDialog", "Type of image:", 0));
        description->setText(QString());
        label_11->setText(QApplication::translate("ImagePropertiesDialog", "Description:", 0));
        typeName->setText(QString());
        dimensionsLabel->setText(QApplication::translate("ImagePropertiesDialog", "Dimensions:", 0));
        dimensions->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(genrealTab), QApplication::translate("ImagePropertiesDialog", "General", 0));
        QTreeWidgetItem *___qtreewidgetitem = metadataTree->headerItem();
        ___qtreewidgetitem->setText(1, QApplication::translate("ImagePropertiesDialog", "Value", 0));
        ___qtreewidgetitem->setText(0, QApplication::translate("ImagePropertiesDialog", "Property", 0));
        tabWidget->setTabText(tabWidget->indexOf(metadataTab), QApplication::translate("ImagePropertiesDialog", "Metadata", 0));
    } // retranslateUi

};

namespace Ui {
    class ImagePropertiesDialog: public Ui_ImagePropertiesDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_IMAGEPROPERTIESDIALOG_H
