/****************************************************************************
** Meta object code from reading C++ file 'basicqcpinteractionmanager.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../charts/basicqcpinteractionmanager.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'basicqcpinteractionmanager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_BasicQCPInteractionManager_t {
    QByteArrayData data[23];
    char stringdata0[299];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_BasicQCPInteractionManager_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_BasicQCPInteractionManager_t qt_meta_stringdata_BasicQCPInteractionManager = {
    {
QT_MOC_LITERAL(0, 0, 26), // "BasicQCPInteractionManager"
QT_MOC_LITERAL(1, 27, 19), // "setYAxisLockEnabled"
QT_MOC_LITERAL(2, 47, 0), // ""
QT_MOC_LITERAL(3, 48, 7), // "enabled"
QT_MOC_LITERAL(4, 56, 19), // "setXAxisLockEnabled"
QT_MOC_LITERAL(5, 76, 10), // "mousePress"
QT_MOC_LITERAL(6, 87, 12), // "QMouseEvent*"
QT_MOC_LITERAL(7, 100, 5), // "event"
QT_MOC_LITERAL(8, 106, 9), // "mouseMove"
QT_MOC_LITERAL(9, 116, 12), // "mouseRelease"
QT_MOC_LITERAL(10, 129, 10), // "mouseWheel"
QT_MOC_LITERAL(11, 140, 12), // "QWheelEvent*"
QT_MOC_LITERAL(12, 153, 20), // "axisSelectionChanged"
QT_MOC_LITERAL(13, 174, 11), // "legendClick"
QT_MOC_LITERAL(14, 186, 10), // "QCPLegend*"
QT_MOC_LITERAL(15, 197, 6), // "legend"
QT_MOC_LITERAL(16, 204, 22), // "QCPAbstractLegendItem*"
QT_MOC_LITERAL(17, 227, 4), // "item"
QT_MOC_LITERAL(18, 232, 14), // "plottableClick"
QT_MOC_LITERAL(19, 247, 21), // "QCPAbstractPlottable*"
QT_MOC_LITERAL(20, 269, 9), // "plottable"
QT_MOC_LITERAL(21, 279, 9), // "dataIndex"
QT_MOC_LITERAL(22, 289, 9) // "yAxisLock"

    },
    "BasicQCPInteractionManager\0"
    "setYAxisLockEnabled\0\0enabled\0"
    "setXAxisLockEnabled\0mousePress\0"
    "QMouseEvent*\0event\0mouseMove\0mouseRelease\0"
    "mouseWheel\0QWheelEvent*\0axisSelectionChanged\0"
    "legendClick\0QCPLegend*\0legend\0"
    "QCPAbstractLegendItem*\0item\0plottableClick\0"
    "QCPAbstractPlottable*\0plottable\0"
    "dataIndex\0yAxisLock"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_BasicQCPInteractionManager[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       1,   90, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   59,    2, 0x0a /* Public */,
       4,    1,   62,    2, 0x0a /* Public */,
       5,    1,   65,    2, 0x08 /* Private */,
       8,    1,   68,    2, 0x08 /* Private */,
       9,    0,   71,    2, 0x08 /* Private */,
      10,    1,   72,    2, 0x08 /* Private */,
      12,    0,   75,    2, 0x08 /* Private */,
      13,    3,   76,    2, 0x08 /* Private */,
      18,    3,   83,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 11,    7,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 14, 0x80000000 | 16, 0x80000000 | 6,   15,   17,    7,
    QMetaType::Void, 0x80000000 | 19, QMetaType::Int, 0x80000000 | 6,   20,   21,    7,

 // properties: name, type, flags
      22, QMetaType::Bool, 0x00095003,

       0        // eod
};

void BasicQCPInteractionManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        BasicQCPInteractionManager *_t = static_cast<BasicQCPInteractionManager *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->setYAxisLockEnabled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->setXAxisLockEnabled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->mousePress((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 3: _t->mouseMove((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 4: _t->mouseRelease(); break;
        case 5: _t->mouseWheel((*reinterpret_cast< QWheelEvent*(*)>(_a[1]))); break;
        case 6: _t->axisSelectionChanged(); break;
        case 7: _t->legendClick((*reinterpret_cast< QCPLegend*(*)>(_a[1])),(*reinterpret_cast< QCPAbstractLegendItem*(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 8: _t->plottableClick((*reinterpret_cast< QCPAbstractPlottable*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractLegendItem* >(); break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLegend* >(); break;
            }
            break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractPlottable* >(); break;
            }
            break;
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        BasicQCPInteractionManager *_t = static_cast<BasicQCPInteractionManager *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->isYAxisLockEnabled(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        BasicQCPInteractionManager *_t = static_cast<BasicQCPInteractionManager *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setYAxisLockEnabled(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject BasicQCPInteractionManager::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_BasicQCPInteractionManager.data,
      qt_meta_data_BasicQCPInteractionManager,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *BasicQCPInteractionManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BasicQCPInteractionManager::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_BasicQCPInteractionManager.stringdata0))
        return static_cast<void*>(const_cast< BasicQCPInteractionManager*>(this));
    return QObject::qt_metacast(_clname);
}

int BasicQCPInteractionManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 1;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
