/****************************************************************************
** Meta object code from reading C++ file 'rainfallwidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../dash_widgets/rainfallwidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'rainfallwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_RainfallWidget_t {
    QByteArrayData data[32];
    char stringdata0[320];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RainfallWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RainfallWidget_t qt_meta_stringdata_RainfallWidget = {
    {
QT_MOC_LITERAL(0, 0, 14), // "RainfallWidget"
QT_MOC_LITERAL(1, 15, 14), // "chartRequested"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 7), // "DataSet"
QT_MOC_LITERAL(4, 39, 7), // "dataset"
QT_MOC_LITERAL(5, 47, 8), // "liveData"
QT_MOC_LITERAL(6, 56, 11), // "LiveDataSet"
QT_MOC_LITERAL(7, 68, 3), // "lds"
QT_MOC_LITERAL(8, 72, 9), // "newSample"
QT_MOC_LITERAL(9, 82, 6), // "Sample"
QT_MOC_LITERAL(10, 89, 6), // "sample"
QT_MOC_LITERAL(11, 96, 7), // "setRain"
QT_MOC_LITERAL(12, 104, 4), // "date"
QT_MOC_LITERAL(13, 109, 3), // "day"
QT_MOC_LITERAL(14, 113, 5), // "month"
QT_MOC_LITERAL(15, 119, 4), // "year"
QT_MOC_LITERAL(16, 124, 19), // "setStormRateEnabled"
QT_MOC_LITERAL(17, 144, 7), // "enabled"
QT_MOC_LITERAL(18, 152, 5), // "reset"
QT_MOC_LITERAL(19, 158, 19), // "mousePressEventSlot"
QT_MOC_LITERAL(20, 178, 12), // "QMouseEvent*"
QT_MOC_LITERAL(21, 191, 5), // "event"
QT_MOC_LITERAL(22, 197, 18), // "mouseMoveEventSlot"
QT_MOC_LITERAL(23, 216, 20), // "plottableDoubleClick"
QT_MOC_LITERAL(24, 237, 21), // "QCPAbstractPlottable*"
QT_MOC_LITERAL(25, 259, 9), // "plottable"
QT_MOC_LITERAL(26, 269, 9), // "dataIndex"
QT_MOC_LITERAL(27, 279, 15), // "showContextMenu"
QT_MOC_LITERAL(28, 295, 5), // "point"
QT_MOC_LITERAL(29, 301, 8), // "plotRain"
QT_MOC_LITERAL(30, 310, 4), // "save"
QT_MOC_LITERAL(31, 315, 4) // "copy"

    },
    "RainfallWidget\0chartRequested\0\0DataSet\0"
    "dataset\0liveData\0LiveDataSet\0lds\0"
    "newSample\0Sample\0sample\0setRain\0date\0"
    "day\0month\0year\0setStormRateEnabled\0"
    "enabled\0reset\0mousePressEventSlot\0"
    "QMouseEvent*\0event\0mouseMoveEventSlot\0"
    "plottableDoubleClick\0QCPAbstractPlottable*\0"
    "plottable\0dataIndex\0showContextMenu\0"
    "point\0plotRain\0save\0copy"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RainfallWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   79,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   82,    2, 0x0a /* Public */,
       8,    1,   85,    2, 0x0a /* Public */,
      11,    4,   88,    2, 0x0a /* Public */,
      16,    1,   97,    2, 0x0a /* Public */,
      18,    0,  100,    2, 0x0a /* Public */,
      19,    1,  101,    2, 0x08 /* Private */,
      22,    1,  104,    2, 0x08 /* Private */,
      23,    3,  107,    2, 0x08 /* Private */,
      27,    1,  114,    2, 0x08 /* Private */,
      29,    0,  117,    2, 0x08 /* Private */,
      30,    0,  118,    2, 0x08 /* Private */,
      31,    0,  119,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void, QMetaType::QDate, QMetaType::Double, QMetaType::Double, QMetaType::Double,   12,   13,   14,   15,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void, 0x80000000 | 24, QMetaType::Int, 0x80000000 | 20,   25,   26,   21,
    QMetaType::Void, QMetaType::QPoint,   28,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void RainfallWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        RainfallWidget *_t = static_cast<RainfallWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->chartRequested((*reinterpret_cast< DataSet(*)>(_a[1]))); break;
        case 1: _t->liveData((*reinterpret_cast< LiveDataSet(*)>(_a[1]))); break;
        case 2: _t->newSample((*reinterpret_cast< Sample(*)>(_a[1]))); break;
        case 3: _t->setRain((*reinterpret_cast< QDate(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4]))); break;
        case 4: _t->setStormRateEnabled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->reset(); break;
        case 6: _t->mousePressEventSlot((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 7: _t->mouseMoveEventSlot((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 8: _t->plottableDoubleClick((*reinterpret_cast< QCPAbstractPlottable*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 9: _t->showContextMenu((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 10: _t->plotRain(); break;
        case 11: _t->save(); break;
        case 12: _t->copy(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractPlottable* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (RainfallWidget::*_t)(DataSet );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&RainfallWidget::chartRequested)) {
                *result = 0;
            }
        }
    }
}

const QMetaObject RainfallWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_RainfallWidget.data,
      qt_meta_data_RainfallWidget,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *RainfallWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RainfallWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_RainfallWidget.stringdata0))
        return static_cast<void*>(const_cast< RainfallWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int RainfallWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    }
    return _id;
}

// SIGNAL 0
void RainfallWidget::chartRequested(DataSet _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
