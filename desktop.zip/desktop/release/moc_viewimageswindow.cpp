/****************************************************************************
** Meta object code from reading C++ file 'viewimageswindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../viewimageswindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'viewimageswindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ViewImagesWindow_t {
    QByteArrayData data[22];
    char stringdata0[329];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ViewImagesWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ViewImagesWindow_t qt_meta_stringdata_ViewImagesWindow = {
    {
QT_MOC_LITERAL(0, 0, 16), // "ViewImagesWindow"
QT_MOC_LITERAL(1, 17, 21), // "listItemDoubleClicked"
QT_MOC_LITERAL(2, 39, 0), // ""
QT_MOC_LITERAL(3, 40, 5), // "index"
QT_MOC_LITERAL(4, 46, 21), // "treeItemDoubleClicked"
QT_MOC_LITERAL(5, 68, 24), // "listItemSelectionChanged"
QT_MOC_LITERAL(6, 93, 14), // "QItemSelection"
QT_MOC_LITERAL(7, 108, 8), // "selected"
QT_MOC_LITERAL(8, 117, 10), // "deselected"
QT_MOC_LITERAL(9, 128, 24), // "treeItemSelectionChanged"
QT_MOC_LITERAL(10, 153, 14), // "hSplitterMoved"
QT_MOC_LITERAL(11, 168, 14), // "vSplitterMoved"
QT_MOC_LITERAL(12, 183, 19), // "listItemContextMenu"
QT_MOC_LITERAL(13, 203, 5), // "point"
QT_MOC_LITERAL(14, 209, 19), // "treeItemContextMenu"
QT_MOC_LITERAL(15, 229, 17), // "openImageInWindow"
QT_MOC_LITERAL(16, 247, 11), // "saveImageAs"
QT_MOC_LITERAL(17, 259, 11), // "viewWeather"
QT_MOC_LITERAL(18, 271, 10), // "properties"
QT_MOC_LITERAL(19, 282, 8), // "openItem"
QT_MOC_LITERAL(20, 291, 17), // "expandRecursively"
QT_MOC_LITERAL(21, 309, 19) // "collapseRecursively"

    },
    "ViewImagesWindow\0listItemDoubleClicked\0"
    "\0index\0treeItemDoubleClicked\0"
    "listItemSelectionChanged\0QItemSelection\0"
    "selected\0deselected\0treeItemSelectionChanged\0"
    "hSplitterMoved\0vSplitterMoved\0"
    "listItemContextMenu\0point\0treeItemContextMenu\0"
    "openImageInWindow\0saveImageAs\0viewWeather\0"
    "properties\0openItem\0expandRecursively\0"
    "collapseRecursively"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ViewImagesWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   89,    2, 0x08 /* Private */,
       4,    1,   92,    2, 0x08 /* Private */,
       5,    2,   95,    2, 0x08 /* Private */,
       9,    2,  100,    2, 0x08 /* Private */,
      10,    2,  105,    2, 0x08 /* Private */,
      11,    2,  110,    2, 0x08 /* Private */,
      12,    1,  115,    2, 0x08 /* Private */,
      14,    1,  118,    2, 0x08 /* Private */,
      15,    0,  121,    2, 0x08 /* Private */,
      16,    0,  122,    2, 0x08 /* Private */,
      17,    0,  123,    2, 0x08 /* Private */,
      18,    0,  124,    2, 0x08 /* Private */,
      19,    0,  125,    2, 0x08 /* Private */,
      20,    0,  126,    2, 0x08 /* Private */,
      21,    0,  127,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, 0x80000000 | 6, 0x80000000 | 6,    7,    8,
    QMetaType::Void, 0x80000000 | 6, 0x80000000 | 6,    7,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::QPoint,   13,
    QMetaType::Void, QMetaType::QPoint,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void ViewImagesWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ViewImagesWindow *_t = static_cast<ViewImagesWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->listItemDoubleClicked((*reinterpret_cast< QModelIndex(*)>(_a[1]))); break;
        case 1: _t->treeItemDoubleClicked((*reinterpret_cast< QModelIndex(*)>(_a[1]))); break;
        case 2: _t->listItemSelectionChanged((*reinterpret_cast< QItemSelection(*)>(_a[1])),(*reinterpret_cast< QItemSelection(*)>(_a[2]))); break;
        case 3: _t->treeItemSelectionChanged((*reinterpret_cast< QItemSelection(*)>(_a[1])),(*reinterpret_cast< QItemSelection(*)>(_a[2]))); break;
        case 4: _t->hSplitterMoved((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 5: _t->vSplitterMoved((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 6: _t->listItemContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 7: _t->treeItemContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 8: _t->openImageInWindow(); break;
        case 9: _t->saveImageAs(); break;
        case 10: _t->viewWeather(); break;
        case 11: _t->properties(); break;
        case 12: _t->openItem(); break;
        case 13: _t->expandRecursively(); break;
        case 14: _t->collapseRecursively(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QItemSelection >(); break;
            }
            break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QItemSelection >(); break;
            }
            break;
        }
    }
}

const QMetaObject ViewImagesWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_ViewImagesWindow.data,
      qt_meta_data_ViewImagesWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ViewImagesWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ViewImagesWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ViewImagesWindow.stringdata0))
        return static_cast<void*>(const_cast< ViewImagesWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int ViewImagesWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
