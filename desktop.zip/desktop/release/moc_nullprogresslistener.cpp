/****************************************************************************
** Meta object code from reading C++ file 'nullprogresslistener.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../datasource/nullprogresslistener.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'nullprogresslistener.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_NullProgressListener_t {
    QByteArrayData data[16];
    char stringdata0[126];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_NullProgressListener_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_NullProgressListener_t qt_meta_stringdata_NullProgressListener = {
    {
QT_MOC_LITERAL(0, 0, 20), // "NullProgressListener"
QT_MOC_LITERAL(1, 21, 11), // "setTaskName"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 5), // "title"
QT_MOC_LITERAL(4, 40, 14), // "setSubtaskName"
QT_MOC_LITERAL(5, 55, 5), // "label"
QT_MOC_LITERAL(6, 61, 10), // "setMaximum"
QT_MOC_LITERAL(7, 72, 3), // "max"
QT_MOC_LITERAL(8, 76, 8), // "setRange"
QT_MOC_LITERAL(9, 85, 3), // "min"
QT_MOC_LITERAL(10, 89, 8), // "setValue"
QT_MOC_LITERAL(11, 98, 5), // "value"
QT_MOC_LITERAL(12, 104, 5), // "reset"
QT_MOC_LITERAL(13, 110, 4), // "show"
QT_MOC_LITERAL(14, 115, 4), // "hide"
QT_MOC_LITERAL(15, 120, 5) // "close"

    },
    "NullProgressListener\0setTaskName\0\0"
    "title\0setSubtaskName\0label\0setMaximum\0"
    "max\0setRange\0min\0setValue\0value\0reset\0"
    "show\0hide\0close"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_NullProgressListener[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   59,    2, 0x0a /* Public */,
       4,    1,   62,    2, 0x0a /* Public */,
       6,    1,   65,    2, 0x0a /* Public */,
       8,    2,   68,    2, 0x0a /* Public */,
      10,    1,   73,    2, 0x0a /* Public */,
      12,    0,   76,    2, 0x0a /* Public */,
      13,    0,   77,    2, 0x0a /* Public */,
      14,    0,   78,    2, 0x0a /* Public */,
      15,    0,   79,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    9,    7,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void NullProgressListener::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        NullProgressListener *_t = static_cast<NullProgressListener *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->setTaskName((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->setSubtaskName((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->setMaximum((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->setRange((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->setValue((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->reset(); break;
        case 6: _t->show(); break;
        case 7: _t->hide(); break;
        case 8: _t->close(); break;
        default: ;
        }
    }
}

const QMetaObject NullProgressListener::staticMetaObject = {
    { &AbstractProgressListener::staticMetaObject, qt_meta_stringdata_NullProgressListener.data,
      qt_meta_data_NullProgressListener,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *NullProgressListener::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *NullProgressListener::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_NullProgressListener.stringdata0))
        return static_cast<void*>(const_cast< NullProgressListener*>(this));
    return AbstractProgressListener::qt_metacast(_clname);
}

int NullProgressListener::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = AbstractProgressListener::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
