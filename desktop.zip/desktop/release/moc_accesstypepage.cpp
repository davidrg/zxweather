/****************************************************************************
** Meta object code from reading C++ file 'accesstypepage.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../config_wizard/accesstypepage.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'accesstypepage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_AccessTypePage_t {
    QByteArrayData data[9];
    char stringdata0[125];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AccessTypePage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AccessTypePage_t qt_meta_stringdata_AccessTypePage = {
    {
QT_MOC_LITERAL(0, 0, 14), // "AccessTypePage"
QT_MOC_LITERAL(1, 15, 19), // "completenessChanged"
QT_MOC_LITERAL(2, 35, 0), // ""
QT_MOC_LITERAL(3, 36, 26), // "multipleStationsArePresent"
QT_MOC_LITERAL(4, 63, 11), // "stationList"
QT_MOC_LITERAL(5, 75, 7), // "station"
QT_MOC_LITERAL(6, 83, 15), // "serverAvailable"
QT_MOC_LITERAL(7, 99, 14), // "serverHostname"
QT_MOC_LITERAL(8, 114, 10) // "serverPort"

    },
    "AccessTypePage\0completenessChanged\0\0"
    "multipleStationsArePresent\0stationList\0"
    "station\0serverAvailable\0serverHostname\0"
    "serverPort"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AccessTypePage[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       6,   20, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,

 // properties: name, type, flags
       3, QMetaType::Bool, 0x00095003,
       4, QMetaType::QVariant, 0x00095103,
       5, QMetaType::QVariant, 0x00095103,
       6, QMetaType::Bool, 0x00095103,
       7, QMetaType::QString, 0x00095103,
       8, QMetaType::Int, 0x00095103,

       0        // eod
};

void AccessTypePage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        AccessTypePage *_t = static_cast<AccessTypePage *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->completenessChanged(); break;
        default: ;
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        AccessTypePage *_t = static_cast<AccessTypePage *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->getMultipleStationsPresent(); break;
        case 1: *reinterpret_cast< QVariant*>(_v) = _t->getStationList(); break;
        case 2: *reinterpret_cast< QVariant*>(_v) = _t->getStation(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->getServerAvailable(); break;
        case 4: *reinterpret_cast< QString*>(_v) = _t->getServerHostname(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->getServerPort(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        AccessTypePage *_t = static_cast<AccessTypePage *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setMultipleStationsPresent(*reinterpret_cast< bool*>(_v)); break;
        case 1: _t->setStationList(*reinterpret_cast< QVariant*>(_v)); break;
        case 2: _t->setStation(*reinterpret_cast< QVariant*>(_v)); break;
        case 3: _t->setServerAvailable(*reinterpret_cast< bool*>(_v)); break;
        case 4: _t->setServerHostname(*reinterpret_cast< QString*>(_v)); break;
        case 5: _t->setServerPort(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_a);
}

const QMetaObject AccessTypePage::staticMetaObject = {
    { &QWizardPage::staticMetaObject, qt_meta_stringdata_AccessTypePage.data,
      qt_meta_data_AccessTypePage,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *AccessTypePage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AccessTypePage::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_AccessTypePage.stringdata0))
        return static_cast<void*>(const_cast< AccessTypePage*>(this));
    return QWizardPage::qt_metacast(_clname);
}

int AccessTypePage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWizardPage::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
