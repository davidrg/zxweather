/****************************************************************************
** Meta object code from reading C++ file 'activeimagesourceswebtask.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../datasource/webtasks/activeimagesourceswebtask.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'activeimagesourceswebtask.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ActiveImageSourcesWebTask_t {
    QByteArrayData data[7];
    char stringdata0[121];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ActiveImageSourcesWebTask_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ActiveImageSourcesWebTask_t qt_meta_stringdata_ActiveImageSourcesWebTask = {
    {
QT_MOC_LITERAL(0, 0, 25), // "ActiveImageSourcesWebTask"
QT_MOC_LITERAL(1, 26, 23), // "archivedImagesAvailable"
QT_MOC_LITERAL(2, 50, 0), // ""
QT_MOC_LITERAL(3, 51, 27), // "activeImageSourcesAvailable"
QT_MOC_LITERAL(4, 79, 20), // "networkReplyReceived"
QT_MOC_LITERAL(5, 100, 14), // "QNetworkReply*"
QT_MOC_LITERAL(6, 115, 5) // "reply"

    },
    "ActiveImageSourcesWebTask\0"
    "archivedImagesAvailable\0\0"
    "activeImageSourcesAvailable\0"
    "networkReplyReceived\0QNetworkReply*\0"
    "reply"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ActiveImageSourcesWebTask[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   29,    2, 0x06 /* Public */,
       3,    0,   30,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    1,   31,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 5,    6,

       0        // eod
};

void ActiveImageSourcesWebTask::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ActiveImageSourcesWebTask *_t = static_cast<ActiveImageSourcesWebTask *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->archivedImagesAvailable(); break;
        case 1: _t->activeImageSourcesAvailable(); break;
        case 2: _t->networkReplyReceived((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (ActiveImageSourcesWebTask::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ActiveImageSourcesWebTask::archivedImagesAvailable)) {
                *result = 0;
            }
        }
        {
            typedef void (ActiveImageSourcesWebTask::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ActiveImageSourcesWebTask::activeImageSourcesAvailable)) {
                *result = 1;
            }
        }
    }
}

const QMetaObject ActiveImageSourcesWebTask::staticMetaObject = {
    { &AbstractWebTask::staticMetaObject, qt_meta_stringdata_ActiveImageSourcesWebTask.data,
      qt_meta_data_ActiveImageSourcesWebTask,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ActiveImageSourcesWebTask::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ActiveImageSourcesWebTask::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ActiveImageSourcesWebTask.stringdata0))
        return static_cast<void*>(const_cast< ActiveImageSourcesWebTask*>(this));
    return AbstractWebTask::qt_metacast(_clname);
}

int ActiveImageSourcesWebTask::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = AbstractWebTask::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void ActiveImageSourcesWebTask::archivedImagesAvailable()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void ActiveImageSourcesWebTask::activeImageSourcesAvailable()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
