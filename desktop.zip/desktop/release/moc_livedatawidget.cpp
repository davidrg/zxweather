/****************************************************************************
** Meta object code from reading C++ file 'livedatawidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../dash_widgets/livedatawidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'livedatawidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_LiveDataWidget_t {
    QByteArrayData data[15];
    char stringdata0[172];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_LiveDataWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_LiveDataWidget_t qt_meta_stringdata_LiveDataWidget = {
    {
QT_MOC_LITERAL(0, 0, 14), // "LiveDataWidget"
QT_MOC_LITERAL(1, 15, 18), // "sysTrayTextChanged"
QT_MOC_LITERAL(2, 34, 0), // ""
QT_MOC_LITERAL(3, 35, 4), // "text"
QT_MOC_LITERAL(4, 40, 18), // "sysTrayIconChanged"
QT_MOC_LITERAL(5, 59, 4), // "icon"
QT_MOC_LITERAL(6, 64, 13), // "plotRequested"
QT_MOC_LITERAL(7, 78, 7), // "DataSet"
QT_MOC_LITERAL(8, 86, 2), // "ds"
QT_MOC_LITERAL(9, 89, 15), // "refreshLiveData"
QT_MOC_LITERAL(10, 105, 11), // "LiveDataSet"
QT_MOC_LITERAL(11, 117, 3), // "lds"
QT_MOC_LITERAL(12, 121, 21), // "setSolarDataAvailable"
QT_MOC_LITERAL(13, 143, 9), // "available"
QT_MOC_LITERAL(14, 153, 18) // "childPlotRequested"

    },
    "LiveDataWidget\0sysTrayTextChanged\0\0"
    "text\0sysTrayIconChanged\0icon\0plotRequested\0"
    "DataSet\0ds\0refreshLiveData\0LiveDataSet\0"
    "lds\0setSolarDataAvailable\0available\0"
    "childPlotRequested"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_LiveDataWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   44,    2, 0x06 /* Public */,
       4,    1,   47,    2, 0x06 /* Public */,
       6,    1,   50,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       9,    1,   53,    2, 0x0a /* Public */,
      12,    1,   56,    2, 0x0a /* Public */,
      14,    1,   59,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QIcon,    5,
    QMetaType::Void, 0x80000000 | 7,    8,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 10,   11,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void, 0x80000000 | 7,    8,

       0        // eod
};

void LiveDataWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        LiveDataWidget *_t = static_cast<LiveDataWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sysTrayTextChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->sysTrayIconChanged((*reinterpret_cast< QIcon(*)>(_a[1]))); break;
        case 2: _t->plotRequested((*reinterpret_cast< DataSet(*)>(_a[1]))); break;
        case 3: _t->refreshLiveData((*reinterpret_cast< LiveDataSet(*)>(_a[1]))); break;
        case 4: _t->setSolarDataAvailable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->childPlotRequested((*reinterpret_cast< DataSet(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (LiveDataWidget::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LiveDataWidget::sysTrayTextChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (LiveDataWidget::*_t)(QIcon );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LiveDataWidget::sysTrayIconChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (LiveDataWidget::*_t)(DataSet );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LiveDataWidget::plotRequested)) {
                *result = 2;
            }
        }
    }
}

const QMetaObject LiveDataWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_LiveDataWidget.data,
      qt_meta_data_LiveDataWidget,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *LiveDataWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LiveDataWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_LiveDataWidget.stringdata0))
        return static_cast<void*>(const_cast< LiveDataWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int LiveDataWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void LiveDataWidget::sysTrayTextChanged(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void LiveDataWidget::sysTrayIconChanged(QIcon _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void LiveDataWidget::plotRequested(DataSet _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_END_MOC_NAMESPACE
