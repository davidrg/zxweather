/****************************************************************************
** Meta object code from reading C++ file 'liveplotwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../charts/liveplotwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'liveplotwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_LivePlotWindow_t {
    QByteArrayData data[16];
    char stringdata0[171];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_LivePlotWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_LivePlotWindow_t qt_meta_stringdata_LivePlotWindow = {
    {
QT_MOC_LITERAL(0, 0, 14), // "LivePlotWindow"
QT_MOC_LITERAL(1, 15, 8), // "liveData"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 11), // "LiveDataSet"
QT_MOC_LITERAL(4, 37, 2), // "ds"
QT_MOC_LITERAL(5, 40, 18), // "showAddGraphDialog"
QT_MOC_LITERAL(6, 59, 7), // "message"
QT_MOC_LITERAL(7, 67, 5), // "title"
QT_MOC_LITERAL(8, 73, 13), // "graphRemoving"
QT_MOC_LITERAL(9, 87, 9), // "QCPGraph*"
QT_MOC_LITERAL(10, 97, 5), // "graph"
QT_MOC_LITERAL(11, 103, 17), // "graphStyleChanged"
QT_MOC_LITERAL(12, 121, 11), // "GraphStyle&"
QT_MOC_LITERAL(13, 133, 8), // "newStyle"
QT_MOC_LITERAL(14, 142, 16), // "selectionChanged"
QT_MOC_LITERAL(15, 159, 11) // "showOptions"

    },
    "LivePlotWindow\0liveData\0\0LiveDataSet\0"
    "ds\0showAddGraphDialog\0message\0title\0"
    "graphRemoving\0QCPGraph*\0graph\0"
    "graphStyleChanged\0GraphStyle&\0newStyle\0"
    "selectionChanged\0showOptions"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_LivePlotWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   54,    2, 0x08 /* Private */,
       5,    2,   57,    2, 0x08 /* Private */,
       5,    1,   62,    2, 0x28 /* Private | MethodCloned */,
       5,    0,   65,    2, 0x28 /* Private | MethodCloned */,
       8,    1,   66,    2, 0x08 /* Private */,
      11,    2,   69,    2, 0x08 /* Private */,
      14,    0,   74,    2, 0x08 /* Private */,
      15,    0,   75,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    6,    7,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void, 0x80000000 | 9, 0x80000000 | 12,   10,   13,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void LivePlotWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        LivePlotWindow *_t = static_cast<LivePlotWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->liveData((*reinterpret_cast< LiveDataSet(*)>(_a[1]))); break;
        case 1: _t->showAddGraphDialog((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 2: _t->showAddGraphDialog((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->showAddGraphDialog(); break;
        case 4: _t->graphRemoving((*reinterpret_cast< QCPGraph*(*)>(_a[1]))); break;
        case 5: _t->graphStyleChanged((*reinterpret_cast< QCPGraph*(*)>(_a[1])),(*reinterpret_cast< GraphStyle(*)>(_a[2]))); break;
        case 6: _t->selectionChanged(); break;
        case 7: _t->showOptions(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPGraph* >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPGraph* >(); break;
            }
            break;
        }
    }
}

const QMetaObject LivePlotWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_LivePlotWindow.data,
      qt_meta_data_LivePlotWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *LivePlotWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LivePlotWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_LivePlotWindow.stringdata0))
        return static_cast<void*>(const_cast< LivePlotWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int LivePlotWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
