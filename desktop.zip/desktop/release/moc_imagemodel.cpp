/****************************************************************************
** Meta object code from reading C++ file 'imagemodel.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../imagemodel.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'imagemodel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ImageModel_t {
    QByteArrayData data[19];
    char stringdata0[224];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ImageModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ImageModel_t qt_meta_stringdata_ImageModel = {
    {
QT_MOC_LITERAL(0, 0, 10), // "ImageModel"
QT_MOC_LITERAL(1, 11, 15), // "imageDatesReady"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 16), // "QList<ImageDate>"
QT_MOC_LITERAL(4, 45, 5), // "dates"
QT_MOC_LITERAL(5, 51, 18), // "QList<ImageSource>"
QT_MOC_LITERAL(6, 70, 7), // "sources"
QT_MOC_LITERAL(7, 78, 28), // "processImageLoadRequestQueue"
QT_MOC_LITERAL(8, 107, 14), // "imageListReady"
QT_MOC_LITERAL(9, 122, 16), // "QList<ImageInfo>"
QT_MOC_LITERAL(10, 139, 9), // "imageList"
QT_MOC_LITERAL(11, 149, 14), // "thumbnailReady"
QT_MOC_LITERAL(12, 164, 7), // "imageId"
QT_MOC_LITERAL(13, 172, 9), // "thumbnail"
QT_MOC_LITERAL(14, 182, 10), // "imageReady"
QT_MOC_LITERAL(15, 193, 9), // "ImageInfo"
QT_MOC_LITERAL(16, 203, 4), // "info"
QT_MOC_LITERAL(17, 208, 5), // "image"
QT_MOC_LITERAL(18, 214, 9) // "cacheFile"

    },
    "ImageModel\0imageDatesReady\0\0"
    "QList<ImageDate>\0dates\0QList<ImageSource>\0"
    "sources\0processImageLoadRequestQueue\0"
    "imageListReady\0QList<ImageInfo>\0"
    "imageList\0thumbnailReady\0imageId\0"
    "thumbnail\0imageReady\0ImageInfo\0info\0"
    "image\0cacheFile"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ImageModel[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    2,   39,    2, 0x08 /* Private */,
       7,    0,   44,    2, 0x08 /* Private */,
       8,    1,   45,    2, 0x08 /* Private */,
      11,    2,   48,    2, 0x08 /* Private */,
      14,    3,   53,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5,    4,    6,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void, QMetaType::Int, QMetaType::QImage,   12,   13,
    QMetaType::Void, 0x80000000 | 15, QMetaType::QImage, QMetaType::QString,   16,   17,   18,

       0        // eod
};

void ImageModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ImageModel *_t = static_cast<ImageModel *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->imageDatesReady((*reinterpret_cast< QList<ImageDate>(*)>(_a[1])),(*reinterpret_cast< QList<ImageSource>(*)>(_a[2]))); break;
        case 1: _t->processImageLoadRequestQueue(); break;
        case 2: _t->imageListReady((*reinterpret_cast< QList<ImageInfo>(*)>(_a[1]))); break;
        case 3: _t->thumbnailReady((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QImage(*)>(_a[2]))); break;
        case 4: _t->imageReady((*reinterpret_cast< ImageInfo(*)>(_a[1])),(*reinterpret_cast< QImage(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        default: ;
        }
    }
}

const QMetaObject ImageModel::staticMetaObject = {
    { &QAbstractItemModel::staticMetaObject, qt_meta_stringdata_ImageModel.data,
      qt_meta_data_ImageModel,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ImageModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ImageModel::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ImageModel.stringdata0))
        return static_cast<void*>(const_cast< ImageModel*>(this));
    return QAbstractItemModel::qt_metacast(_clname);
}

int ImageModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QAbstractItemModel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
