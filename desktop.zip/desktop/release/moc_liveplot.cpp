/****************************************************************************
** Meta object code from reading C++ file 'liveplot.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../charts/liveplot.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'liveplot.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_LivePlot_t {
    QByteArrayData data[47];
    char stringdata0[663];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_LivePlot_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_LivePlot_t qt_meta_stringdata_LivePlot = {
    {
QT_MOC_LITERAL(0, 0, 8), // "LivePlot"
QT_MOC_LITERAL(1, 9, 13), // "removingGraph"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 9), // "QCPGraph*"
QT_MOC_LITERAL(4, 34, 5), // "graph"
QT_MOC_LITERAL(5, 40, 17), // "addGraphRequested"
QT_MOC_LITERAL(6, 58, 23), // "legendVisibilityChanged"
QT_MOC_LITERAL(7, 82, 7), // "visible"
QT_MOC_LITERAL(8, 90, 22), // "titleVisibilityChanged"
QT_MOC_LITERAL(9, 113, 17), // "graphStyleChanged"
QT_MOC_LITERAL(10, 131, 11), // "GraphStyle&"
QT_MOC_LITERAL(11, 143, 5), // "style"
QT_MOC_LITERAL(12, 149, 4), // "copy"
QT_MOC_LITERAL(13, 154, 4), // "save"
QT_MOC_LITERAL(14, 159, 24), // "changeSelectedGraphStyle"
QT_MOC_LITERAL(15, 184, 19), // "renameSelectedGraph"
QT_MOC_LITERAL(16, 204, 19), // "removeSelectedGraph"
QT_MOC_LITERAL(17, 224, 8), // "addTitle"
QT_MOC_LITERAL(18, 233, 12), // "toggleLegend"
QT_MOC_LITERAL(19, 246, 11), // "toggleTitle"
QT_MOC_LITERAL(20, 258, 19), // "setAddGraphsEnabled"
QT_MOC_LITERAL(21, 278, 7), // "enabled"
QT_MOC_LITERAL(22, 286, 15), // "removeAllGraphs"
QT_MOC_LITERAL(23, 302, 23), // "recreateDefaultAxisRect"
QT_MOC_LITERAL(24, 326, 16), // "plottableClicked"
QT_MOC_LITERAL(25, 343, 21), // "QCPAbstractPlottable*"
QT_MOC_LITERAL(26, 365, 13), // "plottableItem"
QT_MOC_LITERAL(27, 379, 9), // "dataIndex"
QT_MOC_LITERAL(28, 389, 12), // "QMouseEvent*"
QT_MOC_LITERAL(29, 402, 5), // "event"
QT_MOC_LITERAL(30, 408, 22), // "plottableDoubleClicked"
QT_MOC_LITERAL(31, 431, 9), // "plottable"
QT_MOC_LITERAL(32, 441, 13), // "legendClicked"
QT_MOC_LITERAL(33, 455, 10), // "QCPLegend*"
QT_MOC_LITERAL(34, 466, 22), // "QCPAbstractLegendItem*"
QT_MOC_LITERAL(35, 489, 4), // "item"
QT_MOC_LITERAL(36, 494, 19), // "legendDoubleClicked"
QT_MOC_LITERAL(37, 514, 17), // "axisDoubleClicked"
QT_MOC_LITERAL(38, 532, 8), // "QCPAxis*"
QT_MOC_LITERAL(39, 541, 4), // "axis"
QT_MOC_LITERAL(40, 546, 23), // "QCPAxis::SelectablePart"
QT_MOC_LITERAL(41, 570, 4), // "part"
QT_MOC_LITERAL(42, 575, 22), // "textElementDoubleClick"
QT_MOC_LITERAL(43, 598, 10), // "moveLegend"
QT_MOC_LITERAL(44, 609, 25), // "chartContextMenuRequested"
QT_MOC_LITERAL(45, 635, 5), // "point"
QT_MOC_LITERAL(46, 641, 21) // "emitAddGraphRequested"

    },
    "LivePlot\0removingGraph\0\0QCPGraph*\0"
    "graph\0addGraphRequested\0legendVisibilityChanged\0"
    "visible\0titleVisibilityChanged\0"
    "graphStyleChanged\0GraphStyle&\0style\0"
    "copy\0save\0changeSelectedGraphStyle\0"
    "renameSelectedGraph\0removeSelectedGraph\0"
    "addTitle\0toggleLegend\0toggleTitle\0"
    "setAddGraphsEnabled\0enabled\0removeAllGraphs\0"
    "recreateDefaultAxisRect\0plottableClicked\0"
    "QCPAbstractPlottable*\0plottableItem\0"
    "dataIndex\0QMouseEvent*\0event\0"
    "plottableDoubleClicked\0plottable\0"
    "legendClicked\0QCPLegend*\0"
    "QCPAbstractLegendItem*\0item\0"
    "legendDoubleClicked\0axisDoubleClicked\0"
    "QCPAxis*\0axis\0QCPAxis::SelectablePart\0"
    "part\0textElementDoubleClick\0moveLegend\0"
    "chartContextMenuRequested\0point\0"
    "emitAddGraphRequested"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_LivePlot[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  139,    2, 0x06 /* Public */,
       5,    0,  142,    2, 0x06 /* Public */,
       6,    1,  143,    2, 0x06 /* Public */,
       8,    1,  146,    2, 0x06 /* Public */,
       9,    2,  149,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      12,    0,  154,    2, 0x0a /* Public */,
      13,    0,  155,    2, 0x0a /* Public */,
      14,    0,  156,    2, 0x0a /* Public */,
      15,    0,  157,    2, 0x0a /* Public */,
      16,    0,  158,    2, 0x0a /* Public */,
      17,    0,  159,    2, 0x0a /* Public */,
      18,    0,  160,    2, 0x0a /* Public */,
      19,    0,  161,    2, 0x0a /* Public */,
      20,    1,  162,    2, 0x0a /* Public */,
      22,    0,  165,    2, 0x0a /* Public */,
      23,    0,  166,    2, 0x0a /* Public */,
      24,    3,  167,    2, 0x08 /* Private */,
      30,    3,  174,    2, 0x08 /* Private */,
      32,    3,  181,    2, 0x08 /* Private */,
      36,    3,  188,    2, 0x08 /* Private */,
      37,    3,  195,    2, 0x08 /* Private */,
      42,    1,  202,    2, 0x08 /* Private */,
      43,    0,  205,    2, 0x08 /* Private */,
      44,    1,  206,    2, 0x08 /* Private */,
      46,    0,  209,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    7,
    QMetaType::Void, QMetaType::Bool,    7,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 10,    4,   11,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 25, QMetaType::Int, 0x80000000 | 28,   26,   27,   29,
    QMetaType::Void, 0x80000000 | 25, QMetaType::Int, 0x80000000 | 28,   31,    2,    2,
    QMetaType::Void, 0x80000000 | 33, 0x80000000 | 34, 0x80000000 | 28,    2,   35,    2,
    QMetaType::Void, 0x80000000 | 33, 0x80000000 | 34, 0x80000000 | 28,    2,   35,    2,
    QMetaType::Void, 0x80000000 | 38, 0x80000000 | 40, 0x80000000 | 28,   39,   41,   29,
    QMetaType::Void, 0x80000000 | 28,   29,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   45,
    QMetaType::Void,

       0        // eod
};

void LivePlot::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        LivePlot *_t = static_cast<LivePlot *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->removingGraph((*reinterpret_cast< QCPGraph*(*)>(_a[1]))); break;
        case 1: _t->addGraphRequested(); break;
        case 2: _t->legendVisibilityChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->titleVisibilityChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->graphStyleChanged((*reinterpret_cast< QCPGraph*(*)>(_a[1])),(*reinterpret_cast< GraphStyle(*)>(_a[2]))); break;
        case 5: _t->copy(); break;
        case 6: _t->save(); break;
        case 7: _t->changeSelectedGraphStyle(); break;
        case 8: _t->renameSelectedGraph(); break;
        case 9: _t->removeSelectedGraph(); break;
        case 10: _t->addTitle(); break;
        case 11: _t->toggleLegend(); break;
        case 12: _t->toggleTitle(); break;
        case 13: _t->setAddGraphsEnabled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: _t->removeAllGraphs(); break;
        case 15: _t->recreateDefaultAxisRect(); break;
        case 16: _t->plottableClicked((*reinterpret_cast< QCPAbstractPlottable*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 17: _t->plottableDoubleClicked((*reinterpret_cast< QCPAbstractPlottable*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 18: _t->legendClicked((*reinterpret_cast< QCPLegend*(*)>(_a[1])),(*reinterpret_cast< QCPAbstractLegendItem*(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 19: _t->legendDoubleClicked((*reinterpret_cast< QCPLegend*(*)>(_a[1])),(*reinterpret_cast< QCPAbstractLegendItem*(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 20: _t->axisDoubleClicked((*reinterpret_cast< QCPAxis*(*)>(_a[1])),(*reinterpret_cast< QCPAxis::SelectablePart(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 21: _t->textElementDoubleClick((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 22: _t->moveLegend(); break;
        case 23: _t->chartContextMenuRequested((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 24: _t->emitAddGraphRequested(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPGraph* >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPGraph* >(); break;
            }
            break;
        case 16:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractPlottable* >(); break;
            }
            break;
        case 17:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractPlottable* >(); break;
            }
            break;
        case 18:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractLegendItem* >(); break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLegend* >(); break;
            }
            break;
        case 19:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractLegendItem* >(); break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLegend* >(); break;
            }
            break;
        case 20:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis* >(); break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::SelectablePart >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (LivePlot::*_t)(QCPGraph * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LivePlot::removingGraph)) {
                *result = 0;
            }
        }
        {
            typedef void (LivePlot::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LivePlot::addGraphRequested)) {
                *result = 1;
            }
        }
        {
            typedef void (LivePlot::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LivePlot::legendVisibilityChanged)) {
                *result = 2;
            }
        }
        {
            typedef void (LivePlot::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LivePlot::titleVisibilityChanged)) {
                *result = 3;
            }
        }
        {
            typedef void (LivePlot::*_t)(QCPGraph * , GraphStyle & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LivePlot::graphStyleChanged)) {
                *result = 4;
            }
        }
    }
}

const QMetaObject LivePlot::staticMetaObject = {
    { &QCustomPlot::staticMetaObject, qt_meta_stringdata_LivePlot.data,
      qt_meta_data_LivePlot,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *LivePlot::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LivePlot::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_LivePlot.stringdata0))
        return static_cast<void*>(const_cast< LivePlot*>(this));
    return QCustomPlot::qt_metacast(_clname);
}

int LivePlot::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCustomPlot::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    }
    return _id;
}

// SIGNAL 0
void LivePlot::removingGraph(QCPGraph * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void LivePlot::addGraphRequested()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void LivePlot::legendVisibilityChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void LivePlot::titleVisibilityChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void LivePlot::graphStyleChanged(QCPGraph * _t1, GraphStyle & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
QT_END_MOC_NAMESPACE
