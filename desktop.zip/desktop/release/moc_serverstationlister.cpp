/****************************************************************************
** Meta object code from reading C++ file 'serverstationlister.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../config_wizard/serverstationlister.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'serverstationlister.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ServerStationLister_t {
    QByteArrayData data[16];
    char stringdata0[182];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ServerStationLister_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ServerStationLister_t qt_meta_stringdata_ServerStationLister = {
    {
QT_MOC_LITERAL(0, 0, 19), // "ServerStationLister"
QT_MOC_LITERAL(1, 20, 8), // "finished"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 8), // "stations"
QT_MOC_LITERAL(4, 39, 5), // "error"
QT_MOC_LITERAL(5, 45, 12), // "errorMessage"
QT_MOC_LITERAL(6, 58, 12), // "statusUpdate"
QT_MOC_LITERAL(7, 71, 7), // "message"
QT_MOC_LITERAL(8, 79, 16), // "fetchStationList"
QT_MOC_LITERAL(9, 96, 6), // "server"
QT_MOC_LITERAL(10, 103, 4), // "port"
QT_MOC_LITERAL(11, 108, 9), // "connected"
QT_MOC_LITERAL(12, 118, 12), // "disconnected"
QT_MOC_LITERAL(13, 131, 28), // "QAbstractSocket::SocketError"
QT_MOC_LITERAL(14, 160, 11), // "errorNumber"
QT_MOC_LITERAL(15, 172, 9) // "readyRead"

    },
    "ServerStationLister\0finished\0\0stations\0"
    "error\0errorMessage\0statusUpdate\0message\0"
    "fetchStationList\0server\0port\0connected\0"
    "disconnected\0QAbstractSocket::SocketError\0"
    "errorNumber\0readyRead"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ServerStationLister[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   54,    2, 0x06 /* Public */,
       4,    1,   57,    2, 0x06 /* Public */,
       6,    1,   60,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    2,   63,    2, 0x0a /* Public */,
      11,    0,   68,    2, 0x08 /* Private */,
      12,    0,   69,    2, 0x08 /* Private */,
       4,    1,   70,    2, 0x08 /* Private */,
      15,    0,   73,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QStringList,    3,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    7,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    9,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 13,   14,
    QMetaType::Void,

       0        // eod
};

void ServerStationLister::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ServerStationLister *_t = static_cast<ServerStationLister *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->finished((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 1: _t->error((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->statusUpdate((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->fetchStationList((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->connected(); break;
        case 5: _t->disconnected(); break;
        case 6: _t->error((*reinterpret_cast< QAbstractSocket::SocketError(*)>(_a[1]))); break;
        case 7: _t->readyRead(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAbstractSocket::SocketError >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (ServerStationLister::*_t)(QStringList );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ServerStationLister::finished)) {
                *result = 0;
            }
        }
        {
            typedef void (ServerStationLister::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ServerStationLister::error)) {
                *result = 1;
            }
        }
        {
            typedef void (ServerStationLister::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ServerStationLister::statusUpdate)) {
                *result = 2;
            }
        }
    }
}

const QMetaObject ServerStationLister::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_ServerStationLister.data,
      qt_meta_data_ServerStationLister,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ServerStationLister::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ServerStationLister::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ServerStationLister.stringdata0))
        return static_cast<void*>(const_cast< ServerStationLister*>(this));
    return QObject::qt_metacast(_clname);
}

int ServerStationLister::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void ServerStationLister::finished(QStringList _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ServerStationLister::error(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void ServerStationLister::statusUpdate(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_END_MOC_NAMESPACE
