/****************************************************************************
** Meta object code from reading C++ file 'chartwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../charts/chartwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'chartwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ChartWindow_t {
    QByteArrayData data[48];
    char stringdata0[669];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ChartWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ChartWindow_t qt_meta_stringdata_ChartWindow = {
    {
QT_MOC_LITERAL(0, 0, 11), // "ChartWindow"
QT_MOC_LITERAL(1, 12, 21), // "chartAxisCountChanged"
QT_MOC_LITERAL(2, 34, 0), // ""
QT_MOC_LITERAL(3, 35, 5), // "count"
QT_MOC_LITERAL(4, 41, 14), // "dataSetRemoved"
QT_MOC_LITERAL(5, 56, 12), // "dataset_id_t"
QT_MOC_LITERAL(6, 69, 9), // "dataSetId"
QT_MOC_LITERAL(7, 79, 15), // "axisDoubleClick"
QT_MOC_LITERAL(8, 95, 8), // "QCPAxis*"
QT_MOC_LITERAL(9, 104, 4), // "axis"
QT_MOC_LITERAL(10, 109, 23), // "QCPAxis::SelectablePart"
QT_MOC_LITERAL(11, 133, 4), // "part"
QT_MOC_LITERAL(12, 138, 12), // "QMouseEvent*"
QT_MOC_LITERAL(13, 151, 5), // "event"
QT_MOC_LITERAL(14, 157, 22), // "textElementDoubleClick"
QT_MOC_LITERAL(15, 180, 20), // "plottableDoubleClick"
QT_MOC_LITERAL(16, 201, 21), // "QCPAbstractPlottable*"
QT_MOC_LITERAL(17, 223, 9), // "plottable"
QT_MOC_LITERAL(18, 233, 9), // "dataIndex"
QT_MOC_LITERAL(19, 243, 17), // "legendDoubleClick"
QT_MOC_LITERAL(20, 261, 10), // "QCPLegend*"
QT_MOC_LITERAL(21, 272, 22), // "QCPAbstractLegendItem*"
QT_MOC_LITERAL(22, 295, 4), // "item"
QT_MOC_LITERAL(23, 300, 12), // "setYAxisLock"
QT_MOC_LITERAL(24, 313, 15), // "toggleYAxisLock"
QT_MOC_LITERAL(25, 329, 12), // "setXAxisLock"
QT_MOC_LITERAL(26, 342, 15), // "toggleXAxisLock"
QT_MOC_LITERAL(27, 358, 25), // "chartContextMenuRequested"
QT_MOC_LITERAL(28, 384, 5), // "point"
QT_MOC_LITERAL(29, 390, 8), // "addTitle"
QT_MOC_LITERAL(30, 399, 11), // "removeTitle"
QT_MOC_LITERAL(31, 411, 6), // "replot"
QT_MOC_LITERAL(32, 418, 16), // "showLegendToggle"
QT_MOC_LITERAL(33, 435, 15), // "showTitleToggle"
QT_MOC_LITERAL(34, 451, 14), // "showGridToggle"
QT_MOC_LITERAL(35, 466, 10), // "moveLegend"
QT_MOC_LITERAL(36, 477, 19), // "removeSelectedGraph"
QT_MOC_LITERAL(37, 497, 19), // "renameSelectedGraph"
QT_MOC_LITERAL(38, 517, 24), // "changeSelectedGraphStyle"
QT_MOC_LITERAL(39, 542, 8), // "addGraph"
QT_MOC_LITERAL(40, 551, 14), // "customiseChart"
QT_MOC_LITERAL(41, 566, 10), // "addDataSet"
QT_MOC_LITERAL(42, 577, 21), // "renameSelectedKeyAxis"
QT_MOC_LITERAL(43, 599, 29), // "changeSelectedKeyAxisTimespan"
QT_MOC_LITERAL(44, 629, 21), // "removeSelectedKeyAxis"
QT_MOC_LITERAL(45, 651, 7), // "refresh"
QT_MOC_LITERAL(46, 659, 4), // "save"
QT_MOC_LITERAL(47, 664, 4) // "copy"

    },
    "ChartWindow\0chartAxisCountChanged\0\0"
    "count\0dataSetRemoved\0dataset_id_t\0"
    "dataSetId\0axisDoubleClick\0QCPAxis*\0"
    "axis\0QCPAxis::SelectablePart\0part\0"
    "QMouseEvent*\0event\0textElementDoubleClick\0"
    "plottableDoubleClick\0QCPAbstractPlottable*\0"
    "plottable\0dataIndex\0legendDoubleClick\0"
    "QCPLegend*\0QCPAbstractLegendItem*\0"
    "item\0setYAxisLock\0toggleYAxisLock\0"
    "setXAxisLock\0toggleXAxisLock\0"
    "chartContextMenuRequested\0point\0"
    "addTitle\0removeTitle\0replot\0"
    "showLegendToggle\0showTitleToggle\0"
    "showGridToggle\0moveLegend\0removeSelectedGraph\0"
    "renameSelectedGraph\0changeSelectedGraphStyle\0"
    "addGraph\0customiseChart\0addDataSet\0"
    "renameSelectedKeyAxis\0"
    "changeSelectedKeyAxisTimespan\0"
    "removeSelectedKeyAxis\0refresh\0save\0"
    "copy"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ChartWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      30,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  164,    2, 0x08 /* Private */,
       4,    1,  167,    2, 0x08 /* Private */,
       7,    3,  170,    2, 0x08 /* Private */,
      14,    1,  177,    2, 0x08 /* Private */,
      15,    3,  180,    2, 0x08 /* Private */,
      19,    3,  187,    2, 0x08 /* Private */,
      23,    0,  194,    2, 0x08 /* Private */,
      24,    0,  195,    2, 0x08 /* Private */,
      25,    0,  196,    2, 0x08 /* Private */,
      26,    0,  197,    2, 0x08 /* Private */,
      27,    1,  198,    2, 0x08 /* Private */,
      29,    0,  201,    2, 0x08 /* Private */,
      30,    1,  202,    2, 0x08 /* Private */,
      30,    0,  205,    2, 0x28 /* Private | MethodCloned */,
      32,    0,  206,    2, 0x08 /* Private */,
      33,    0,  207,    2, 0x08 /* Private */,
      34,    0,  208,    2, 0x08 /* Private */,
      35,    0,  209,    2, 0x08 /* Private */,
      36,    0,  210,    2, 0x08 /* Private */,
      37,    0,  211,    2, 0x08 /* Private */,
      38,    0,  212,    2, 0x08 /* Private */,
      39,    0,  213,    2, 0x08 /* Private */,
      40,    0,  214,    2, 0x08 /* Private */,
      41,    0,  215,    2, 0x08 /* Private */,
      42,    0,  216,    2, 0x08 /* Private */,
      43,    0,  217,    2, 0x08 /* Private */,
      44,    0,  218,    2, 0x08 /* Private */,
      45,    0,  219,    2, 0x08 /* Private */,
      46,    0,  220,    2, 0x08 /* Private */,
      47,    0,  221,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void, 0x80000000 | 8, 0x80000000 | 10, 0x80000000 | 12,    9,   11,   13,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void, 0x80000000 | 16, QMetaType::Int, 0x80000000 | 12,   17,   18,   13,
    QMetaType::Void, 0x80000000 | 20, 0x80000000 | 21, 0x80000000 | 12,    2,   22,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   28,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   31,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void ChartWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ChartWindow *_t = static_cast<ChartWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->chartAxisCountChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->dataSetRemoved((*reinterpret_cast< dataset_id_t(*)>(_a[1]))); break;
        case 2: _t->axisDoubleClick((*reinterpret_cast< QCPAxis*(*)>(_a[1])),(*reinterpret_cast< QCPAxis::SelectablePart(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 3: _t->textElementDoubleClick((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 4: _t->plottableDoubleClick((*reinterpret_cast< QCPAbstractPlottable*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 5: _t->legendDoubleClick((*reinterpret_cast< QCPLegend*(*)>(_a[1])),(*reinterpret_cast< QCPAbstractLegendItem*(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 6: _t->setYAxisLock(); break;
        case 7: _t->toggleYAxisLock(); break;
        case 8: _t->setXAxisLock(); break;
        case 9: _t->toggleXAxisLock(); break;
        case 10: _t->chartContextMenuRequested((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 11: _t->addTitle(); break;
        case 12: _t->removeTitle((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->removeTitle(); break;
        case 14: _t->showLegendToggle(); break;
        case 15: _t->showTitleToggle(); break;
        case 16: _t->showGridToggle(); break;
        case 17: _t->moveLegend(); break;
        case 18: _t->removeSelectedGraph(); break;
        case 19: _t->renameSelectedGraph(); break;
        case 20: _t->changeSelectedGraphStyle(); break;
        case 21: _t->addGraph(); break;
        case 22: _t->customiseChart(); break;
        case 23: _t->addDataSet(); break;
        case 24: _t->renameSelectedKeyAxis(); break;
        case 25: _t->changeSelectedKeyAxisTimespan(); break;
        case 26: _t->removeSelectedKeyAxis(); break;
        case 27: _t->refresh(); break;
        case 28: _t->save(); break;
        case 29: _t->copy(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis* >(); break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::SelectablePart >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractPlottable* >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractLegendItem* >(); break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLegend* >(); break;
            }
            break;
        }
    }
}

const QMetaObject ChartWindow::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ChartWindow.data,
      qt_meta_data_ChartWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ChartWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ChartWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ChartWindow.stringdata0))
        return static_cast<void*>(const_cast< ChartWindow*>(this));
    return QWidget::qt_metacast(_clname);
}

int ChartWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 30)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 30;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 30)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 30;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
