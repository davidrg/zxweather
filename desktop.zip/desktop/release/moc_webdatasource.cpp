/****************************************************************************
** Meta object code from reading C++ file 'webdatasource.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../datasource/webdatasource.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'webdatasource.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_WebDataSource_t {
    QByteArrayData data[31];
    char stringdata0[410];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_WebDataSource_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_WebDataSource_t qt_meta_stringdata_WebDataSource = {
    {
QT_MOC_LITERAL(0, 0, 13), // "WebDataSource"
QT_MOC_LITERAL(1, 14, 13), // "liveDataReady"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 14), // "QNetworkReply*"
QT_MOC_LITERAL(4, 44, 5), // "reply"
QT_MOC_LITERAL(5, 50, 12), // "liveDataPoll"
QT_MOC_LITERAL(6, 63, 22), // "foundActiveImageSource"
QT_MOC_LITERAL(7, 86, 19), // "foundArchivedImages"
QT_MOC_LITERAL(8, 106, 26), // "fetchImageDateListComplete"
QT_MOC_LITERAL(9, 133, 16), // "QList<ImageDate>"
QT_MOC_LITERAL(10, 150, 10), // "imageDates"
QT_MOC_LITERAL(11, 161, 18), // "QList<ImageSource>"
QT_MOC_LITERAL(12, 180, 12), // "imageSources"
QT_MOC_LITERAL(13, 193, 17), // "imageListComplete"
QT_MOC_LITERAL(14, 211, 16), // "QList<ImageInfo>"
QT_MOC_LITERAL(15, 228, 6), // "images"
QT_MOC_LITERAL(16, 235, 9), // "queueTask"
QT_MOC_LITERAL(17, 245, 16), // "AbstractWebTask*"
QT_MOC_LITERAL(18, 262, 4), // "task"
QT_MOC_LITERAL(19, 267, 15), // "startProcessing"
QT_MOC_LITERAL(20, 283, 8), // "priority"
QT_MOC_LITERAL(21, 292, 14), // "subtaskChanged"
QT_MOC_LITERAL(22, 307, 4), // "name"
QT_MOC_LITERAL(23, 312, 7), // "httpGet"
QT_MOC_LITERAL(24, 320, 15), // "QNetworkRequest"
QT_MOC_LITERAL(25, 336, 7), // "request"
QT_MOC_LITERAL(26, 344, 8), // "httpHead"
QT_MOC_LITERAL(27, 353, 12), // "taskFinished"
QT_MOC_LITERAL(28, 366, 10), // "taskFailed"
QT_MOC_LITERAL(29, 377, 5), // "error"
QT_MOC_LITERAL(30, 383, 26) // "taskQueueResponseDataReady"

    },
    "WebDataSource\0liveDataReady\0\0"
    "QNetworkReply*\0reply\0liveDataPoll\0"
    "foundActiveImageSource\0foundArchivedImages\0"
    "fetchImageDateListComplete\0QList<ImageDate>\0"
    "imageDates\0QList<ImageSource>\0"
    "imageSources\0imageListComplete\0"
    "QList<ImageInfo>\0images\0queueTask\0"
    "AbstractWebTask*\0task\0startProcessing\0"
    "priority\0subtaskChanged\0name\0httpGet\0"
    "QNetworkRequest\0request\0httpHead\0"
    "taskFinished\0taskFailed\0error\0"
    "taskQueueResponseDataReady"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_WebDataSource[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   89,    2, 0x08 /* Private */,
       5,    0,   92,    2, 0x08 /* Private */,
       6,    0,   93,    2, 0x08 /* Private */,
       7,    0,   94,    2, 0x08 /* Private */,
       8,    2,   95,    2, 0x08 /* Private */,
      13,    1,  100,    2, 0x08 /* Private */,
      16,    1,  103,    2, 0x08 /* Private */,
      16,    3,  106,    2, 0x08 /* Private */,
      16,    2,  113,    2, 0x28 /* Private | MethodCloned */,
      21,    1,  118,    2, 0x08 /* Private */,
      23,    1,  121,    2, 0x08 /* Private */,
      26,    1,  124,    2, 0x08 /* Private */,
      27,    0,  127,    2, 0x08 /* Private */,
      28,    1,  128,    2, 0x08 /* Private */,
      30,    1,  131,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9, 0x80000000 | 11,   10,   12,
    QMetaType::Void, 0x80000000 | 14,   15,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void, 0x80000000 | 17, QMetaType::Bool, QMetaType::Bool,   18,   19,   20,
    QMetaType::Void, 0x80000000 | 17, QMetaType::Bool,   18,   19,
    QMetaType::Void, QMetaType::QString,   22,
    QMetaType::Void, 0x80000000 | 24,   25,
    QMetaType::Void, 0x80000000 | 24,   25,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   29,
    QMetaType::Void, 0x80000000 | 3,    4,

       0        // eod
};

void WebDataSource::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        WebDataSource *_t = static_cast<WebDataSource *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->liveDataReady((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 1: _t->liveDataPoll(); break;
        case 2: _t->foundActiveImageSource(); break;
        case 3: _t->foundArchivedImages(); break;
        case 4: _t->fetchImageDateListComplete((*reinterpret_cast< QList<ImageDate>(*)>(_a[1])),(*reinterpret_cast< QList<ImageSource>(*)>(_a[2]))); break;
        case 5: _t->imageListComplete((*reinterpret_cast< QList<ImageInfo>(*)>(_a[1]))); break;
        case 6: _t->queueTask((*reinterpret_cast< AbstractWebTask*(*)>(_a[1]))); break;
        case 7: _t->queueTask((*reinterpret_cast< AbstractWebTask*(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 8: _t->queueTask((*reinterpret_cast< AbstractWebTask*(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 9: _t->subtaskChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 10: _t->httpGet((*reinterpret_cast< QNetworkRequest(*)>(_a[1]))); break;
        case 11: _t->httpHead((*reinterpret_cast< QNetworkRequest(*)>(_a[1]))); break;
        case 12: _t->taskFinished(); break;
        case 13: _t->taskFailed((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 14: _t->taskQueueResponseDataReady((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkRequest >(); break;
            }
            break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkRequest >(); break;
            }
            break;
        case 14:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        }
    }
}

const QMetaObject WebDataSource::staticMetaObject = {
    { &AbstractDataSource::staticMetaObject, qt_meta_stringdata_WebDataSource.data,
      qt_meta_data_WebDataSource,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *WebDataSource::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *WebDataSource::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_WebDataSource.stringdata0))
        return static_cast<void*>(const_cast< WebDataSource*>(this));
    return AbstractDataSource::qt_metacast(_clname);
}

int WebDataSource::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = AbstractDataSource::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
