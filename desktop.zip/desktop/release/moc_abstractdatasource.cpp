/****************************************************************************
** Meta object code from reading C++ file 'abstractdatasource.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../datasource/abstractdatasource.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'abstractdatasource.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_AbstractDataSource_t {
    QByteArrayData data[30];
    char stringdata0[362];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AbstractDataSource_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AbstractDataSource_t qt_meta_stringdata_AbstractDataSource = {
    {
QT_MOC_LITERAL(0, 0, 18), // "AbstractDataSource"
QT_MOC_LITERAL(1, 19, 12), // "samplesReady"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 9), // "SampleSet"
QT_MOC_LITERAL(4, 43, 7), // "samples"
QT_MOC_LITERAL(5, 51, 15), // "rainTotalsReady"
QT_MOC_LITERAL(6, 67, 4), // "date"
QT_MOC_LITERAL(7, 72, 3), // "day"
QT_MOC_LITERAL(8, 76, 5), // "month"
QT_MOC_LITERAL(9, 82, 4), // "year"
QT_MOC_LITERAL(10, 87, 15), // "imageDatesReady"
QT_MOC_LITERAL(11, 103, 16), // "QList<ImageDate>"
QT_MOC_LITERAL(12, 120, 10), // "imageDates"
QT_MOC_LITERAL(13, 131, 18), // "QList<ImageSource>"
QT_MOC_LITERAL(14, 150, 12), // "imageSources"
QT_MOC_LITERAL(15, 163, 14), // "imageListReady"
QT_MOC_LITERAL(16, 178, 16), // "QList<ImageInfo>"
QT_MOC_LITERAL(17, 195, 6), // "images"
QT_MOC_LITERAL(18, 202, 10), // "imageReady"
QT_MOC_LITERAL(19, 213, 9), // "ImageInfo"
QT_MOC_LITERAL(20, 223, 9), // "imageInfo"
QT_MOC_LITERAL(21, 233, 5), // "image"
QT_MOC_LITERAL(22, 239, 8), // "filename"
QT_MOC_LITERAL(23, 248, 14), // "thumbnailReady"
QT_MOC_LITERAL(24, 263, 7), // "imageId"
QT_MOC_LITERAL(25, 271, 9), // "thumbnail"
QT_MOC_LITERAL(26, 281, 20), // "sampleRetrievalError"
QT_MOC_LITERAL(27, 302, 7), // "message"
QT_MOC_LITERAL(28, 310, 27), // "activeImageSourcesAvailable"
QT_MOC_LITERAL(29, 338, 23) // "archivedImagesAvailable"

    },
    "AbstractDataSource\0samplesReady\0\0"
    "SampleSet\0samples\0rainTotalsReady\0"
    "date\0day\0month\0year\0imageDatesReady\0"
    "QList<ImageDate>\0imageDates\0"
    "QList<ImageSource>\0imageSources\0"
    "imageListReady\0QList<ImageInfo>\0images\0"
    "imageReady\0ImageInfo\0imageInfo\0image\0"
    "filename\0thumbnailReady\0imageId\0"
    "thumbnail\0sampleRetrievalError\0message\0"
    "activeImageSourcesAvailable\0"
    "archivedImagesAvailable"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AbstractDataSource[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   59,    2, 0x06 /* Public */,
       5,    4,   62,    2, 0x06 /* Public */,
      10,    2,   71,    2, 0x06 /* Public */,
      15,    1,   76,    2, 0x06 /* Public */,
      18,    3,   79,    2, 0x06 /* Public */,
      23,    2,   86,    2, 0x06 /* Public */,
      26,    1,   91,    2, 0x06 /* Public */,
      28,    0,   94,    2, 0x06 /* Public */,
      29,    0,   95,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, QMetaType::QDate, QMetaType::Double, QMetaType::Double, QMetaType::Double,    6,    7,    8,    9,
    QMetaType::Void, 0x80000000 | 11, 0x80000000 | 13,   12,   14,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void, 0x80000000 | 19, QMetaType::QImage, QMetaType::QString,   20,   21,   22,
    QMetaType::Void, QMetaType::Int, QMetaType::QImage,   24,   25,
    QMetaType::Void, QMetaType::QString,   27,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void AbstractDataSource::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        AbstractDataSource *_t = static_cast<AbstractDataSource *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->samplesReady((*reinterpret_cast< SampleSet(*)>(_a[1]))); break;
        case 1: _t->rainTotalsReady((*reinterpret_cast< QDate(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4]))); break;
        case 2: _t->imageDatesReady((*reinterpret_cast< QList<ImageDate>(*)>(_a[1])),(*reinterpret_cast< QList<ImageSource>(*)>(_a[2]))); break;
        case 3: _t->imageListReady((*reinterpret_cast< QList<ImageInfo>(*)>(_a[1]))); break;
        case 4: _t->imageReady((*reinterpret_cast< ImageInfo(*)>(_a[1])),(*reinterpret_cast< QImage(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 5: _t->thumbnailReady((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QImage(*)>(_a[2]))); break;
        case 6: _t->sampleRetrievalError((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->activeImageSourcesAvailable(); break;
        case 8: _t->archivedImagesAvailable(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (AbstractDataSource::*_t)(SampleSet );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AbstractDataSource::samplesReady)) {
                *result = 0;
            }
        }
        {
            typedef void (AbstractDataSource::*_t)(QDate , double , double , double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AbstractDataSource::rainTotalsReady)) {
                *result = 1;
            }
        }
        {
            typedef void (AbstractDataSource::*_t)(QList<ImageDate> , QList<ImageSource> );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AbstractDataSource::imageDatesReady)) {
                *result = 2;
            }
        }
        {
            typedef void (AbstractDataSource::*_t)(QList<ImageInfo> );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AbstractDataSource::imageListReady)) {
                *result = 3;
            }
        }
        {
            typedef void (AbstractDataSource::*_t)(ImageInfo , QImage , QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AbstractDataSource::imageReady)) {
                *result = 4;
            }
        }
        {
            typedef void (AbstractDataSource::*_t)(int , QImage );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AbstractDataSource::thumbnailReady)) {
                *result = 5;
            }
        }
        {
            typedef void (AbstractDataSource::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AbstractDataSource::sampleRetrievalError)) {
                *result = 6;
            }
        }
        {
            typedef void (AbstractDataSource::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AbstractDataSource::activeImageSourcesAvailable)) {
                *result = 7;
            }
        }
        {
            typedef void (AbstractDataSource::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&AbstractDataSource::archivedImagesAvailable)) {
                *result = 8;
            }
        }
    }
}

const QMetaObject AbstractDataSource::staticMetaObject = {
    { &AbstractLiveDataSource::staticMetaObject, qt_meta_stringdata_AbstractDataSource.data,
      qt_meta_data_AbstractDataSource,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *AbstractDataSource::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AbstractDataSource::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_AbstractDataSource.stringdata0))
        return static_cast<void*>(const_cast< AbstractDataSource*>(this));
    return AbstractLiveDataSource::qt_metacast(_clname);
}

int AbstractDataSource::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = AbstractLiveDataSource::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void AbstractDataSource::samplesReady(SampleSet _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void AbstractDataSource::rainTotalsReady(QDate _t1, double _t2, double _t3, double _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void AbstractDataSource::imageDatesReady(QList<ImageDate> _t1, QList<ImageSource> _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void AbstractDataSource::imageListReady(QList<ImageInfo> _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void AbstractDataSource::imageReady(ImageInfo _t1, QImage _t2, QString _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void AbstractDataSource::thumbnailReady(int _t1, QImage _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void AbstractDataSource::sampleRetrievalError(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void AbstractDataSource::activeImageSourcesAvailable()
{
    QMetaObject::activate(this, &staticMetaObject, 7, Q_NULLPTR);
}

// SIGNAL 8
void AbstractDataSource::archivedImagesAvailable()
{
    QMetaObject::activate(this, &staticMetaObject, 8, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
