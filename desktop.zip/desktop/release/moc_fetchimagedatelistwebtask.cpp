/****************************************************************************
** Meta object code from reading C++ file 'fetchimagedatelistwebtask.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../datasource/webtasks/fetchimagedatelistwebtask.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fetchimagedatelistwebtask.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_FetchImageDateListWebTask_t {
    QByteArrayData data[10];
    char stringdata0[143];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FetchImageDateListWebTask_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FetchImageDateListWebTask_t qt_meta_stringdata_FetchImageDateListWebTask = {
    {
QT_MOC_LITERAL(0, 0, 25), // "FetchImageDateListWebTask"
QT_MOC_LITERAL(1, 26, 13), // "dateListReady"
QT_MOC_LITERAL(2, 40, 0), // ""
QT_MOC_LITERAL(3, 41, 16), // "QList<ImageDate>"
QT_MOC_LITERAL(4, 58, 10), // "imageDates"
QT_MOC_LITERAL(5, 69, 18), // "QList<ImageSource>"
QT_MOC_LITERAL(6, 88, 12), // "imageSources"
QT_MOC_LITERAL(7, 101, 20), // "networkReplyReceived"
QT_MOC_LITERAL(8, 122, 14), // "QNetworkReply*"
QT_MOC_LITERAL(9, 137, 5) // "reply"

    },
    "FetchImageDateListWebTask\0dateListReady\0"
    "\0QList<ImageDate>\0imageDates\0"
    "QList<ImageSource>\0imageSources\0"
    "networkReplyReceived\0QNetworkReply*\0"
    "reply"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FetchImageDateListWebTask[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   24,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    1,   29,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5,    4,    6,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 8,    9,

       0        // eod
};

void FetchImageDateListWebTask::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        FetchImageDateListWebTask *_t = static_cast<FetchImageDateListWebTask *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->dateListReady((*reinterpret_cast< QList<ImageDate>(*)>(_a[1])),(*reinterpret_cast< QList<ImageSource>(*)>(_a[2]))); break;
        case 1: _t->networkReplyReceived((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (FetchImageDateListWebTask::*_t)(QList<ImageDate> , QList<ImageSource> );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FetchImageDateListWebTask::dateListReady)) {
                *result = 0;
            }
        }
    }
}

const QMetaObject FetchImageDateListWebTask::staticMetaObject = {
    { &AbstractWebTask::staticMetaObject, qt_meta_stringdata_FetchImageDateListWebTask.data,
      qt_meta_data_FetchImageDateListWebTask,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *FetchImageDateListWebTask::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FetchImageDateListWebTask::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_FetchImageDateListWebTask.stringdata0))
        return static_cast<void*>(const_cast< FetchImageDateListWebTask*>(this));
    return AbstractWebTask::qt_metacast(_clname);
}

int FetchImageDateListWebTask::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = AbstractWebTask::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void FetchImageDateListWebTask::dateListReady(QList<ImageDate> _t1, QList<ImageSource> _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
