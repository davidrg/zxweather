/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[41];
    char stringdata0[546];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 12), // "showSettings"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 14), // "adjustSizeSlot"
QT_MOC_LITERAL(4, 40, 15), // "showChartWindow"
QT_MOC_LITERAL(5, 56, 19), // "showLiveChartWindow"
QT_MOC_LITERAL(6, 76, 16), // "showExportDialog"
QT_MOC_LITERAL(7, 93, 16), // "showImagesWindow"
QT_MOC_LITERAL(8, 110, 17), // "trayIconActivated"
QT_MOC_LITERAL(9, 128, 33), // "QSystemTrayIcon::ActivationRe..."
QT_MOC_LITERAL(10, 162, 6), // "reason"
QT_MOC_LITERAL(11, 169, 4), // "quit"
QT_MOC_LITERAL(12, 174, 9), // "showAbout"
QT_MOC_LITERAL(13, 184, 16), // "showWarningPopup"
QT_MOC_LITERAL(14, 201, 7), // "message"
QT_MOC_LITERAL(15, 209, 5), // "title"
QT_MOC_LITERAL(16, 215, 7), // "tooltip"
QT_MOC_LITERAL(17, 223, 14), // "setWarningIcon"
QT_MOC_LITERAL(18, 238, 17), // "clearWarningPopup"
QT_MOC_LITERAL(19, 256, 15), // "dataSourceError"
QT_MOC_LITERAL(20, 272, 17), // "updateSysTrayText"
QT_MOC_LITERAL(21, 290, 4), // "text"
QT_MOC_LITERAL(22, 295, 17), // "updateSysTrayIcon"
QT_MOC_LITERAL(23, 313, 4), // "icon"
QT_MOC_LITERAL(24, 318, 14), // "setStationName"
QT_MOC_LITERAL(25, 333, 4), // "name"
QT_MOC_LITERAL(26, 338, 21), // "setSolarDataAvailable"
QT_MOC_LITERAL(27, 360, 9), // "available"
QT_MOC_LITERAL(28, 370, 17), // "liveDataRefreshed"
QT_MOC_LITERAL(29, 388, 11), // "LiveDataSet"
QT_MOC_LITERAL(30, 400, 3), // "lds"
QT_MOC_LITERAL(31, 404, 17), // "reconnectDatabase"
QT_MOC_LITERAL(32, 422, 8), // "viewData"
QT_MOC_LITERAL(33, 431, 27), // "activeImageSourcesAvailable"
QT_MOC_LITERAL(34, 459, 23), // "archivedImagesAvailable"
QT_MOC_LITERAL(35, 483, 14), // "chartRequested"
QT_MOC_LITERAL(36, 498, 7), // "DataSet"
QT_MOC_LITERAL(37, 506, 7), // "dataSet"
QT_MOC_LITERAL(38, 514, 8), // "newImage"
QT_MOC_LITERAL(39, 523, 12), // "NewImageInfo"
QT_MOC_LITERAL(40, 536, 9) // "imageInfo"

    },
    "MainWindow\0showSettings\0\0adjustSizeSlot\0"
    "showChartWindow\0showLiveChartWindow\0"
    "showExportDialog\0showImagesWindow\0"
    "trayIconActivated\0QSystemTrayIcon::ActivationReason\0"
    "reason\0quit\0showAbout\0showWarningPopup\0"
    "message\0title\0tooltip\0setWarningIcon\0"
    "clearWarningPopup\0dataSourceError\0"
    "updateSysTrayText\0text\0updateSysTrayIcon\0"
    "icon\0setStationName\0name\0setSolarDataAvailable\0"
    "available\0liveDataRefreshed\0LiveDataSet\0"
    "lds\0reconnectDatabase\0viewData\0"
    "activeImageSourcesAvailable\0"
    "archivedImagesAvailable\0chartRequested\0"
    "DataSet\0dataSet\0newImage\0NewImageInfo\0"
    "imageInfo"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  139,    2, 0x0a /* Public */,
       3,    0,  140,    2, 0x0a /* Public */,
       4,    0,  141,    2, 0x0a /* Public */,
       5,    0,  142,    2, 0x0a /* Public */,
       6,    0,  143,    2, 0x0a /* Public */,
       7,    0,  144,    2, 0x0a /* Public */,
       8,    1,  145,    2, 0x0a /* Public */,
      11,    0,  148,    2, 0x0a /* Public */,
      12,    0,  149,    2, 0x0a /* Public */,
      13,    4,  150,    2, 0x0a /* Public */,
      13,    3,  159,    2, 0x2a /* Public | MethodCloned */,
      13,    2,  166,    2, 0x2a /* Public | MethodCloned */,
      18,    0,  171,    2, 0x0a /* Public */,
      19,    1,  172,    2, 0x0a /* Public */,
      20,    1,  175,    2, 0x0a /* Public */,
      22,    1,  178,    2, 0x0a /* Public */,
      24,    1,  181,    2, 0x0a /* Public */,
      26,    1,  184,    2, 0x0a /* Public */,
      28,    1,  187,    2, 0x08 /* Private */,
      31,    0,  190,    2, 0x08 /* Private */,
      32,    0,  191,    2, 0x08 /* Private */,
      33,    0,  192,    2, 0x08 /* Private */,
      34,    0,  193,    2, 0x08 /* Private */,
      35,    1,  194,    2, 0x08 /* Private */,
      38,    1,  197,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::Bool,   14,   15,   16,   17,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString,   14,   15,   16,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   14,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   14,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QIcon,   23,
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::Void, QMetaType::Bool,   27,
    QMetaType::Void, 0x80000000 | 29,   30,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 36,   37,
    QMetaType::Void, 0x80000000 | 39,   40,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->showSettings(); break;
        case 1: _t->adjustSizeSlot(); break;
        case 2: _t->showChartWindow(); break;
        case 3: _t->showLiveChartWindow(); break;
        case 4: _t->showExportDialog(); break;
        case 5: _t->showImagesWindow(); break;
        case 6: _t->trayIconActivated((*reinterpret_cast< QSystemTrayIcon::ActivationReason(*)>(_a[1]))); break;
        case 7: _t->quit(); break;
        case 8: _t->showAbout(); break;
        case 9: _t->showWarningPopup((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4]))); break;
        case 10: _t->showWarningPopup((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 11: _t->showWarningPopup((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 12: _t->clearWarningPopup(); break;
        case 13: _t->dataSourceError((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 14: _t->updateSysTrayText((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 15: _t->updateSysTrayIcon((*reinterpret_cast< QIcon(*)>(_a[1]))); break;
        case 16: _t->setStationName((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 17: _t->setSolarDataAvailable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: _t->liveDataRefreshed((*reinterpret_cast< LiveDataSet(*)>(_a[1]))); break;
        case 19: _t->reconnectDatabase(); break;
        case 20: _t->viewData(); break;
        case 21: _t->activeImageSourcesAvailable(); break;
        case 22: _t->archivedImagesAvailable(); break;
        case 23: _t->chartRequested((*reinterpret_cast< DataSet(*)>(_a[1]))); break;
        case 24: _t->newImage((*reinterpret_cast< NewImageInfo(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 25;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
