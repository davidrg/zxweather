/********************************************************************************
** Form generated from reading UI file 'forecastwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORECASTWIDGET_H
#define UI_FORECASTWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ForecastWidget
{
public:
    QGridLayout *gridLayout;
    QGridLayout *forecastLayout;
    QLabel *label_9;
    QLabel *lblForecastIcon;
    QLabel *lblForecast;
    QFrame *line_3;

    void setupUi(QWidget *ForecastWidget)
    {
        if (ForecastWidget->objectName().isEmpty())
            ForecastWidget->setObjectName(QStringLiteral("ForecastWidget"));
        ForecastWidget->resize(343, 47);
        ForecastWidget->setMinimumSize(QSize(343, 0));
        ForecastWidget->setMaximumSize(QSize(343, 16777215));
        gridLayout = new QGridLayout(ForecastWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        forecastLayout = new QGridLayout();
        forecastLayout->setObjectName(QStringLiteral("forecastLayout"));
        label_9 = new QLabel(ForecastWidget);
        label_9->setObjectName(QStringLiteral("label_9"));

        forecastLayout->addWidget(label_9, 0, 0, 1, 2);

        lblForecastIcon = new QLabel(ForecastWidget);
        lblForecastIcon->setObjectName(QStringLiteral("lblForecastIcon"));
        lblForecastIcon->setMaximumSize(QSize(16, 16));
        lblForecastIcon->setPixmap(QPixmap(QString::fromUtf8(":/icons/weather/clear")));

        forecastLayout->addWidget(lblForecastIcon, 2, 0, 1, 1);

        lblForecast = new QLabel(ForecastWidget);
        lblForecast->setObjectName(QStringLiteral("lblForecast"));
        lblForecast->setWordWrap(true);

        forecastLayout->addWidget(lblForecast, 2, 1, 1, 1);

        line_3 = new QFrame(ForecastWidget);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        forecastLayout->addWidget(line_3, 1, 0, 1, 2);


        gridLayout->addLayout(forecastLayout, 0, 0, 1, 1);


        retranslateUi(ForecastWidget);

        QMetaObject::connectSlotsByName(ForecastWidget);
    } // setupUi

    void retranslateUi(QWidget *ForecastWidget)
    {
        ForecastWidget->setWindowTitle(QApplication::translate("ForecastWidget", "Form", 0));
        label_9->setText(QApplication::translate("ForecastWidget", "<b>Forecast</b>", 0));
        lblForecastIcon->setText(QString());
        lblForecast->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class ForecastWidget: public Ui_ForecastWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORECASTWIDGET_H
