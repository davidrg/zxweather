/********************************************************************************
** Form generated from reading UI file 'chartwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHARTWINDOW_H
#define UI_CHARTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "charts/qcp/qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_ChartWindow
{
public:
    QAction *actionSave_as_PDF;
    QAction *actionSave_as_PostScript;
    QAction *actionSave_as_PNG;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *lblStartTime;
    QDateTimeEdit *startTime;
    QLabel *lblEndTime;
    QDateTimeEdit *endTime;
    QToolButton *pbRefresh;
    QFrame *divRefresh;
    QCheckBox *cbYLock;
    QCheckBox *cbXLock;
    QFrame *YLockDiv;
    QToolButton *saveButton;
    QSpacerItem *horizontalSpacer;
    QFrame *frame;
    QCustomPlot *chart;

    void setupUi(QWidget *ChartWindow)
    {
        if (ChartWindow->objectName().isEmpty())
            ChartWindow->setObjectName(QStringLiteral("ChartWindow"));
        ChartWindow->resize(779, 454);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/chart"), QSize(), QIcon::Normal, QIcon::Off);
        ChartWindow->setWindowIcon(icon);
        actionSave_as_PDF = new QAction(ChartWindow);
        actionSave_as_PDF->setObjectName(QStringLiteral("actionSave_as_PDF"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/export-chart/pdf"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave_as_PDF->setIcon(icon1);
        actionSave_as_PostScript = new QAction(ChartWindow);
        actionSave_as_PostScript->setObjectName(QStringLiteral("actionSave_as_PostScript"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/icons/export-chart/postscript"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave_as_PostScript->setIcon(icon2);
        actionSave_as_PNG = new QAction(ChartWindow);
        actionSave_as_PNG->setObjectName(QStringLiteral("actionSave_as_PNG"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/icons/export-chart/png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave_as_PNG->setIcon(icon3);
        gridLayout = new QGridLayout(ChartWindow);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(10);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(9, 9, 9, 9);
        lblStartTime = new QLabel(ChartWindow);
        lblStartTime->setObjectName(QStringLiteral("lblStartTime"));

        horizontalLayout->addWidget(lblStartTime);

        startTime = new QDateTimeEdit(ChartWindow);
        startTime->setObjectName(QStringLiteral("startTime"));
        startTime->setDateTime(QDateTime(QDate(2013, 1, 1), QTime(0, 0, 0)));

        horizontalLayout->addWidget(startTime);

        lblEndTime = new QLabel(ChartWindow);
        lblEndTime->setObjectName(QStringLiteral("lblEndTime"));

        horizontalLayout->addWidget(lblEndTime);

        endTime = new QDateTimeEdit(ChartWindow);
        endTime->setObjectName(QStringLiteral("endTime"));
        endTime->setDateTime(QDateTime(QDate(2013, 1, 1), QTime(23, 59, 59)));
        endTime->setTime(QTime(23, 59, 59));

        horizontalLayout->addWidget(endTime);

        pbRefresh = new QToolButton(ChartWindow);
        pbRefresh->setObjectName(QStringLiteral("pbRefresh"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/icons/refresh"), QSize(), QIcon::Normal, QIcon::Off);
        pbRefresh->setIcon(icon4);
        pbRefresh->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        pbRefresh->setAutoRaise(true);

        horizontalLayout->addWidget(pbRefresh);

        divRefresh = new QFrame(ChartWindow);
        divRefresh->setObjectName(QStringLiteral("divRefresh"));
        divRefresh->setFrameShadow(QFrame::Sunken);
        divRefresh->setFrameShape(QFrame::VLine);

        horizontalLayout->addWidget(divRefresh);

        cbYLock = new QCheckBox(ChartWindow);
        cbYLock->setObjectName(QStringLiteral("cbYLock"));
        cbYLock->setEnabled(true);
        cbYLock->setChecked(true);

        horizontalLayout->addWidget(cbYLock);

        cbXLock = new QCheckBox(ChartWindow);
        cbXLock->setObjectName(QStringLiteral("cbXLock"));
        cbXLock->setChecked(true);

        horizontalLayout->addWidget(cbXLock);

        YLockDiv = new QFrame(ChartWindow);
        YLockDiv->setObjectName(QStringLiteral("YLockDiv"));
        YLockDiv->setFrameShape(QFrame::VLine);
        YLockDiv->setFrameShadow(QFrame::Sunken);

        horizontalLayout->addWidget(YLockDiv);

        saveButton = new QToolButton(ChartWindow);
        saveButton->setObjectName(QStringLiteral("saveButton"));
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/icons/save"), QSize(), QIcon::Normal, QIcon::Off);
        saveButton->setIcon(icon5);
        saveButton->setPopupMode(QToolButton::DelayedPopup);
        saveButton->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        saveButton->setAutoRaise(true);

        horizontalLayout->addWidget(saveButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);


        verticalLayout->addLayout(horizontalLayout);

        frame = new QFrame(ChartWindow);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setFrameShape(QFrame::HLine);
        frame->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(frame);

        chart = new QCustomPlot(ChartWindow);
        chart->setObjectName(QStringLiteral("chart"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(chart->sizePolicy().hasHeightForWidth());
        chart->setSizePolicy(sizePolicy);
        chart->setContextMenuPolicy(Qt::CustomContextMenu);

        verticalLayout->addWidget(chart);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);


        retranslateUi(ChartWindow);

        QMetaObject::connectSlotsByName(ChartWindow);
    } // setupUi

    void retranslateUi(QWidget *ChartWindow)
    {
        ChartWindow->setWindowTitle(QApplication::translate("ChartWindow", "Chart", 0));
        actionSave_as_PDF->setText(QApplication::translate("ChartWindow", "Save as PDF...", 0));
        actionSave_as_PostScript->setText(QApplication::translate("ChartWindow", "Save as PostScript...", 0));
        actionSave_as_PNG->setText(QApplication::translate("ChartWindow", "Save as PNG...", 0));
        lblStartTime->setText(QApplication::translate("ChartWindow", "Start Time:", 0));
#ifndef QT_NO_WHATSTHIS
        startTime->setWhatsThis(QApplication::translate("ChartWindow", "<html><head/><body><p>Allows you to change the start time of the chart. Click the refresh button to update.</p></body></html>", 0));
#endif // QT_NO_WHATSTHIS
        startTime->setDisplayFormat(QApplication::translate("ChartWindow", "yyyy-MM-dd hh:mm:ss", 0));
        lblEndTime->setText(QApplication::translate("ChartWindow", "End Time:", 0));
#ifndef QT_NO_WHATSTHIS
        endTime->setWhatsThis(QApplication::translate("ChartWindow", "<html><head/><body><p>Allows you to change the end time of the chart. Click the refresh button to update.</p></body></html>", 0));
#endif // QT_NO_WHATSTHIS
        endTime->setDisplayFormat(QApplication::translate("ChartWindow", "yyyy-MM-dd hh:mm:ss", 0));
#ifndef QT_NO_WHATSTHIS
        pbRefresh->setWhatsThis(QApplication::translate("ChartWindow", "Reloads the chart. Click this if you have changed the time range to display new data.", 0));
#endif // QT_NO_WHATSTHIS
        pbRefresh->setText(QApplication::translate("ChartWindow", "Refresh", 0));
#ifndef QT_NO_TOOLTIP
        cbYLock->setToolTip(QApplication::translate("ChartWindow", "If any Y axis is selected all Y axes will scale and pan at the same time", 0));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        cbYLock->setWhatsThis(QApplication::translate("ChartWindow", "<html><head/><body><p>When this checkbox is checked then all Y axes will be selected at once. This allows all Y axes to be scaled/panned together.</p></body></html>", 0));
#endif // QT_NO_WHATSTHIS
        cbYLock->setText(QApplication::translate("ChartWindow", "Lock Y Axes", 0));
        cbXLock->setText(QApplication::translate("ChartWindow", "Lock X Axes", 0));
#ifndef QT_NO_WHATSTHIS
        saveButton->setWhatsThis(QApplication::translate("ChartWindow", "Allows saving the chart in PNG, JPG, BMP and PDF formats.", 0));
#endif // QT_NO_WHATSTHIS
        saveButton->setText(QApplication::translate("ChartWindow", "Save", 0));
#ifndef QT_NO_WHATSTHIS
        chart->setWhatsThis(QApplication::translate("ChartWindow", "Use the mouse wheel to zoom, drag to pan. Double click on the axes to limit pan and zoom.", 0));
#endif // QT_NO_WHATSTHIS
    } // retranslateUi

};

namespace Ui {
    class ChartWindow: public Ui_ChartWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHARTWINDOW_H
