/********************************************************************************
** Form generated from reading UI file 'statuswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATUSWIDGET_H
#define UI_STATUSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StatusWidget
{
public:
    QGridLayout *gridLayout;
    QGridLayout *statusLayout;
    QLabel *lblTxBattery;
    QLabel *label_11;
    QLabel *label_13;
    QLabel *label_17;
    QLabel *lblUpdateCount;
    QLabel *label_19;
    QLabel *lblConsoleBattery;
    QFrame *line_2;

    void setupUi(QWidget *StatusWidget)
    {
        if (StatusWidget->objectName().isEmpty())
            StatusWidget->setObjectName(QStringLiteral("StatusWidget"));
        StatusWidget->resize(343, 81);
        StatusWidget->setMinimumSize(QSize(343, 81));
        StatusWidget->setMaximumSize(QSize(343, 81));
        gridLayout = new QGridLayout(StatusWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        statusLayout = new QGridLayout();
        statusLayout->setObjectName(QStringLiteral("statusLayout"));
        lblTxBattery = new QLabel(StatusWidget);
        lblTxBattery->setObjectName(QStringLiteral("lblTxBattery"));

        statusLayout->addWidget(lblTxBattery, 3, 1, 1, 1);

        label_11 = new QLabel(StatusWidget);
        label_11->setObjectName(QStringLiteral("label_11"));

        statusLayout->addWidget(label_11, 0, 0, 1, 1);

        label_13 = new QLabel(StatusWidget);
        label_13->setObjectName(QStringLiteral("label_13"));

        statusLayout->addWidget(label_13, 2, 0, 1, 1);

        label_17 = new QLabel(StatusWidget);
        label_17->setObjectName(QStringLiteral("label_17"));

        statusLayout->addWidget(label_17, 3, 0, 1, 1);

        lblUpdateCount = new QLabel(StatusWidget);
        lblUpdateCount->setObjectName(QStringLiteral("lblUpdateCount"));

        statusLayout->addWidget(lblUpdateCount, 4, 1, 1, 1);

        label_19 = new QLabel(StatusWidget);
        label_19->setObjectName(QStringLiteral("label_19"));

        statusLayout->addWidget(label_19, 4, 0, 1, 1);

        lblConsoleBattery = new QLabel(StatusWidget);
        lblConsoleBattery->setObjectName(QStringLiteral("lblConsoleBattery"));

        statusLayout->addWidget(lblConsoleBattery, 2, 1, 1, 1);

        line_2 = new QFrame(StatusWidget);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        statusLayout->addWidget(line_2, 1, 0, 1, 2);


        gridLayout->addLayout(statusLayout, 0, 0, 1, 1);


        retranslateUi(StatusWidget);

        QMetaObject::connectSlotsByName(StatusWidget);
    } // setupUi

    void retranslateUi(QWidget *StatusWidget)
    {
        StatusWidget->setWindowTitle(QApplication::translate("StatusWidget", "Form", 0));
        lblTxBattery->setText(QString());
        label_11->setText(QApplication::translate("StatusWidget", "<b>Status</b>", 0));
        label_13->setText(QApplication::translate("StatusWidget", "Console Battery Voltage:", 0));
        label_17->setText(QApplication::translate("StatusWidget", "Transmitter Battery Status:", 0));
        lblUpdateCount->setText(QString());
        label_19->setText(QApplication::translate("StatusWidget", "Update Count:", 0));
        lblConsoleBattery->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class StatusWidget: public Ui_StatusWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATUSWIDGET_H
