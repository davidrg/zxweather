/********************************************************************************
** Form generated from reading UI file 'addgraphdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDGRAPHDIALOG_H
#define UI_ADDGRAPHDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_AddGraphDialog
{
public:
    QVBoxLayout *verticalLayout_9;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_6;
    QGroupBox *gbTemperature;
    QVBoxLayout *verticalLayout;
    QCheckBox *cbTemperature;
    QCheckBox *cbInsideTemperature;
    QCheckBox *cbApparentTemperature;
    QCheckBox *cbWindChill;
    QCheckBox *cbDewPoint;
    QCheckBox *cbHighTemperature;
    QCheckBox *cbLowTemperature;
    QGroupBox *gbHumidity;
    QVBoxLayout *verticalLayout_2;
    QCheckBox *cbHumidity;
    QCheckBox *cbInsideHumidity;
    QVBoxLayout *verticalLayout_7;
    QGroupBox *gbWind;
    QVBoxLayout *verticalLayout_3;
    QCheckBox *cbAverageWindSpeed;
    QCheckBox *cbGustWindSpeed;
    QCheckBox *cbWindDirection;
    QCheckBox *cbGustDirection;
    QGroupBox *gbOther;
    QVBoxLayout *verticalLayout_4;
    QCheckBox *cbBarometricPressure;
    QCheckBox *cbRainfall;
    QCheckBox *cbHighRainRate;
    QCheckBox *cbReception;
    QSpacerItem *verticalSpacer_3;
    QVBoxLayout *verticalLayout_8;
    QGroupBox *gbSolar;
    QVBoxLayout *verticalLayout_5;
    QCheckBox *cbUVIndex;
    QCheckBox *cbSolarRadiation;
    QCheckBox *cbEvapotranspiration;
    QCheckBox *cbHighSolarRadiation;
    QCheckBox *cbHighUVIndex;
    QSpacerItem *verticalSpacer_2;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *AddGraphDialog)
    {
        if (AddGraphDialog->objectName().isEmpty())
            AddGraphDialog->setObjectName(QStringLiteral("AddGraphDialog"));
        AddGraphDialog->resize(486, 500);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/chart-add"), QSize(), QIcon::Normal, QIcon::Off);
        AddGraphDialog->setWindowIcon(icon);
        verticalLayout_9 = new QVBoxLayout(AddGraphDialog);
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        verticalLayout_9->setSizeConstraint(QLayout::SetFixedSize);
        label = new QLabel(AddGraphDialog);
        label->setObjectName(QStringLiteral("label"));
        label->setWordWrap(true);

        verticalLayout_9->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        gbTemperature = new QGroupBox(AddGraphDialog);
        gbTemperature->setObjectName(QStringLiteral("gbTemperature"));
        verticalLayout = new QVBoxLayout(gbTemperature);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        cbTemperature = new QCheckBox(gbTemperature);
        cbTemperature->setObjectName(QStringLiteral("cbTemperature"));

        verticalLayout->addWidget(cbTemperature);

        cbInsideTemperature = new QCheckBox(gbTemperature);
        cbInsideTemperature->setObjectName(QStringLiteral("cbInsideTemperature"));

        verticalLayout->addWidget(cbInsideTemperature);

        cbApparentTemperature = new QCheckBox(gbTemperature);
        cbApparentTemperature->setObjectName(QStringLiteral("cbApparentTemperature"));

        verticalLayout->addWidget(cbApparentTemperature);

        cbWindChill = new QCheckBox(gbTemperature);
        cbWindChill->setObjectName(QStringLiteral("cbWindChill"));

        verticalLayout->addWidget(cbWindChill);

        cbDewPoint = new QCheckBox(gbTemperature);
        cbDewPoint->setObjectName(QStringLiteral("cbDewPoint"));

        verticalLayout->addWidget(cbDewPoint);

        cbHighTemperature = new QCheckBox(gbTemperature);
        cbHighTemperature->setObjectName(QStringLiteral("cbHighTemperature"));

        verticalLayout->addWidget(cbHighTemperature);

        cbLowTemperature = new QCheckBox(gbTemperature);
        cbLowTemperature->setObjectName(QStringLiteral("cbLowTemperature"));

        verticalLayout->addWidget(cbLowTemperature);


        verticalLayout_6->addWidget(gbTemperature);

        gbHumidity = new QGroupBox(AddGraphDialog);
        gbHumidity->setObjectName(QStringLiteral("gbHumidity"));
        verticalLayout_2 = new QVBoxLayout(gbHumidity);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        cbHumidity = new QCheckBox(gbHumidity);
        cbHumidity->setObjectName(QStringLiteral("cbHumidity"));

        verticalLayout_2->addWidget(cbHumidity);

        cbInsideHumidity = new QCheckBox(gbHumidity);
        cbInsideHumidity->setObjectName(QStringLiteral("cbInsideHumidity"));

        verticalLayout_2->addWidget(cbInsideHumidity);


        verticalLayout_6->addWidget(gbHumidity);


        horizontalLayout->addLayout(verticalLayout_6);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        verticalLayout_7->setSizeConstraint(QLayout::SetFixedSize);
        gbWind = new QGroupBox(AddGraphDialog);
        gbWind->setObjectName(QStringLiteral("gbWind"));
        verticalLayout_3 = new QVBoxLayout(gbWind);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        cbAverageWindSpeed = new QCheckBox(gbWind);
        cbAverageWindSpeed->setObjectName(QStringLiteral("cbAverageWindSpeed"));

        verticalLayout_3->addWidget(cbAverageWindSpeed);

        cbGustWindSpeed = new QCheckBox(gbWind);
        cbGustWindSpeed->setObjectName(QStringLiteral("cbGustWindSpeed"));

        verticalLayout_3->addWidget(cbGustWindSpeed);

        cbWindDirection = new QCheckBox(gbWind);
        cbWindDirection->setObjectName(QStringLiteral("cbWindDirection"));

        verticalLayout_3->addWidget(cbWindDirection);

        cbGustDirection = new QCheckBox(gbWind);
        cbGustDirection->setObjectName(QStringLiteral("cbGustDirection"));

        verticalLayout_3->addWidget(cbGustDirection);


        verticalLayout_7->addWidget(gbWind);

        gbOther = new QGroupBox(AddGraphDialog);
        gbOther->setObjectName(QStringLiteral("gbOther"));
        verticalLayout_4 = new QVBoxLayout(gbOther);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        cbBarometricPressure = new QCheckBox(gbOther);
        cbBarometricPressure->setObjectName(QStringLiteral("cbBarometricPressure"));

        verticalLayout_4->addWidget(cbBarometricPressure);

        cbRainfall = new QCheckBox(gbOther);
        cbRainfall->setObjectName(QStringLiteral("cbRainfall"));

        verticalLayout_4->addWidget(cbRainfall);

        cbHighRainRate = new QCheckBox(gbOther);
        cbHighRainRate->setObjectName(QStringLiteral("cbHighRainRate"));

        verticalLayout_4->addWidget(cbHighRainRate);

        cbReception = new QCheckBox(gbOther);
        cbReception->setObjectName(QStringLiteral("cbReception"));

        verticalLayout_4->addWidget(cbReception);


        verticalLayout_7->addWidget(gbOther);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_7->addItem(verticalSpacer_3);


        horizontalLayout->addLayout(verticalLayout_7);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        verticalLayout_8->setSizeConstraint(QLayout::SetFixedSize);
        gbSolar = new QGroupBox(AddGraphDialog);
        gbSolar->setObjectName(QStringLiteral("gbSolar"));
        verticalLayout_5 = new QVBoxLayout(gbSolar);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        cbUVIndex = new QCheckBox(gbSolar);
        cbUVIndex->setObjectName(QStringLiteral("cbUVIndex"));

        verticalLayout_5->addWidget(cbUVIndex);

        cbSolarRadiation = new QCheckBox(gbSolar);
        cbSolarRadiation->setObjectName(QStringLiteral("cbSolarRadiation"));

        verticalLayout_5->addWidget(cbSolarRadiation);

        cbEvapotranspiration = new QCheckBox(gbSolar);
        cbEvapotranspiration->setObjectName(QStringLiteral("cbEvapotranspiration"));

        verticalLayout_5->addWidget(cbEvapotranspiration);

        cbHighSolarRadiation = new QCheckBox(gbSolar);
        cbHighSolarRadiation->setObjectName(QStringLiteral("cbHighSolarRadiation"));

        verticalLayout_5->addWidget(cbHighSolarRadiation);

        cbHighUVIndex = new QCheckBox(gbSolar);
        cbHighUVIndex->setObjectName(QStringLiteral("cbHighUVIndex"));

        verticalLayout_5->addWidget(cbHighUVIndex);


        verticalLayout_8->addWidget(gbSolar);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_8->addItem(verticalSpacer_2);


        horizontalLayout->addLayout(verticalLayout_8);


        verticalLayout_9->addLayout(horizontalLayout);

        buttonBox = new QDialogButtonBox(AddGraphDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout_9->addWidget(buttonBox);

        QWidget::setTabOrder(cbTemperature, cbInsideTemperature);
        QWidget::setTabOrder(cbInsideTemperature, cbApparentTemperature);
        QWidget::setTabOrder(cbApparentTemperature, cbWindChill);
        QWidget::setTabOrder(cbWindChill, cbDewPoint);
        QWidget::setTabOrder(cbDewPoint, cbHighTemperature);
        QWidget::setTabOrder(cbHighTemperature, cbLowTemperature);
        QWidget::setTabOrder(cbLowTemperature, cbHumidity);
        QWidget::setTabOrder(cbHumidity, cbInsideHumidity);
        QWidget::setTabOrder(cbInsideHumidity, cbAverageWindSpeed);
        QWidget::setTabOrder(cbAverageWindSpeed, cbGustWindSpeed);
        QWidget::setTabOrder(cbGustWindSpeed, cbWindDirection);
        QWidget::setTabOrder(cbWindDirection, cbGustDirection);
        QWidget::setTabOrder(cbGustDirection, cbBarometricPressure);
        QWidget::setTabOrder(cbBarometricPressure, cbRainfall);
        QWidget::setTabOrder(cbRainfall, cbHighRainRate);
        QWidget::setTabOrder(cbHighRainRate, cbReception);
        QWidget::setTabOrder(cbReception, cbUVIndex);
        QWidget::setTabOrder(cbUVIndex, cbSolarRadiation);
        QWidget::setTabOrder(cbSolarRadiation, cbEvapotranspiration);
        QWidget::setTabOrder(cbEvapotranspiration, cbHighSolarRadiation);
        QWidget::setTabOrder(cbHighSolarRadiation, cbHighUVIndex);

        retranslateUi(AddGraphDialog);
        QObject::connect(buttonBox, SIGNAL(rejected()), AddGraphDialog, SLOT(reject()));
        QObject::connect(buttonBox, SIGNAL(accepted()), AddGraphDialog, SLOT(accept()));

        QMetaObject::connectSlotsByName(AddGraphDialog);
    } // setupUi

    void retranslateUi(QDialog *AddGraphDialog)
    {
        AddGraphDialog->setWindowTitle(QApplication::translate("AddGraphDialog", "Add graph", 0));
        label->setText(QApplication::translate("AddGraphDialog", "Select the additional graphs you would like to add to the chart. To remove a graph select it in the chart, right click and choose the remove graph option.", 0));
        gbTemperature->setTitle(QApplication::translate("AddGraphDialog", "Temperature", 0));
        cbTemperature->setText(QApplication::translate("AddGraphDialog", "Temperature", 0));
        cbInsideTemperature->setText(QApplication::translate("AddGraphDialog", "Inside Temperature", 0));
        cbApparentTemperature->setText(QApplication::translate("AddGraphDialog", "Apparent Temperature", 0));
        cbWindChill->setText(QApplication::translate("AddGraphDialog", "Wind Chill", 0));
        cbDewPoint->setText(QApplication::translate("AddGraphDialog", "Dew Point", 0));
        cbHighTemperature->setText(QApplication::translate("AddGraphDialog", "High Temperature", 0));
        cbLowTemperature->setText(QApplication::translate("AddGraphDialog", "Low Temperature", 0));
        gbHumidity->setTitle(QApplication::translate("AddGraphDialog", "Humidity", 0));
        cbHumidity->setText(QApplication::translate("AddGraphDialog", "Humidity", 0));
        cbInsideHumidity->setText(QApplication::translate("AddGraphDialog", "Inside Humidity", 0));
        gbWind->setTitle(QApplication::translate("AddGraphDialog", "Wind", 0));
        cbAverageWindSpeed->setText(QApplication::translate("AddGraphDialog", "Average Wind Speed", 0));
        cbGustWindSpeed->setText(QApplication::translate("AddGraphDialog", "Gust Wind Speed", 0));
        cbWindDirection->setText(QApplication::translate("AddGraphDialog", "Average Wind Direction", 0));
        cbGustDirection->setText(QApplication::translate("AddGraphDialog", "Gust Wind Direction", 0));
        gbOther->setTitle(QApplication::translate("AddGraphDialog", "Other", 0));
        cbBarometricPressure->setText(QApplication::translate("AddGraphDialog", "Barometric Pressure", 0));
        cbRainfall->setText(QApplication::translate("AddGraphDialog", "Rainfall", 0));
        cbHighRainRate->setText(QApplication::translate("AddGraphDialog", "High Rain Rate", 0));
        cbReception->setText(QApplication::translate("AddGraphDialog", "Wireless Reception", 0));
        gbSolar->setTitle(QApplication::translate("AddGraphDialog", "Solar", 0));
        cbUVIndex->setText(QApplication::translate("AddGraphDialog", "UV Index", 0));
        cbSolarRadiation->setText(QApplication::translate("AddGraphDialog", "Solar Radiation", 0));
        cbEvapotranspiration->setText(QApplication::translate("AddGraphDialog", "Evapotranspiration", 0));
        cbHighSolarRadiation->setText(QApplication::translate("AddGraphDialog", "High Solar Radiation", 0));
        cbHighUVIndex->setText(QApplication::translate("AddGraphDialog", "High UV Index", 0));
    } // retranslateUi

};

namespace Ui {
    class AddGraphDialog: public Ui_AddGraphDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDGRAPHDIALOG_H
