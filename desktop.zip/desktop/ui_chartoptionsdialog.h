/********************************************************************************
** Form generated from reading UI file 'chartoptionsdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHARTOPTIONSDIALOG_H
#define UI_CHARTOPTIONSDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include "aggregateoptionswidget.h"
#include "timespanwidget.h"

QT_BEGIN_NAMESPACE

class Ui_ChartOptionsDialog
{
public:
    QGridLayout *gridLayout_4;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_2;
    QCheckBox *cbLowTemperature;
    QCheckBox *cbHighRainRate;
    QCheckBox *cbWirelessReception;
    QCheckBox *cbHighTemperature;
    QCheckBox *cbPressure;
    QLabel *label_3;
    QCheckBox *cbTemperature;
    QCheckBox *cbDewPoint;
    QCheckBox *cbIndoorHumidity;
    QCheckBox *cbHumidity;
    QCheckBox *cbWindChill;
    QCheckBox *cbApparentTemperature;
    QCheckBox *cbIndoorTemperature;
    QLabel *label_4;
    QLabel *label_2;
    QCheckBox *cbRainfall;
    QLabel *lblSolar;
    QCheckBox *cbUVIndex;
    QCheckBox *cbSolarRadiation;
    QCheckBox *cbEvapotranspiration;
    QLabel *label_5;
    QCheckBox *cbAverageWindSpeed;
    QCheckBox *cbGustWindSpeed;
    QCheckBox *cbHighSolarRadiation;
    QCheckBox *cbWindDirection;
    QCheckBox *cbHighUVIndex;
    QCheckBox *cbGustDirection;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout_3;
    TimespanWidget *timespan;
    QGroupBox *gbAggregate;
    QGridLayout *gridLayout;
    QLabel *label_9;
    AggregateOptionsWidget *aggregateWidget;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *ChartOptionsDialog)
    {
        if (ChartOptionsDialog->objectName().isEmpty())
            ChartOptionsDialog->setObjectName(QStringLiteral("ChartOptionsDialog"));
        ChartOptionsDialog->resize(536, 371);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/chart-edit"), QSize(), QIcon::Normal, QIcon::Off);
        ChartOptionsDialog->setWindowIcon(icon);
        gridLayout_4 = new QGridLayout(ChartOptionsDialog);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        gridLayout_4->setSizeConstraint(QLayout::SetFixedSize);
        groupBox_2 = new QGroupBox(ChartOptionsDialog);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        gridLayout_2 = new QGridLayout(groupBox_2);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        cbLowTemperature = new QCheckBox(groupBox_2);
        cbLowTemperature->setObjectName(QStringLiteral("cbLowTemperature"));

        gridLayout_2->addWidget(cbLowTemperature, 7, 0, 1, 1);

        cbHighRainRate = new QCheckBox(groupBox_2);
        cbHighRainRate->setObjectName(QStringLiteral("cbHighRainRate"));

        gridLayout_2->addWidget(cbHighRainRate, 3, 3, 1, 1);

        cbWirelessReception = new QCheckBox(groupBox_2);
        cbWirelessReception->setObjectName(QStringLiteral("cbWirelessReception"));

        gridLayout_2->addWidget(cbWirelessReception, 4, 3, 1, 1);

        cbHighTemperature = new QCheckBox(groupBox_2);
        cbHighTemperature->setObjectName(QStringLiteral("cbHighTemperature"));

        gridLayout_2->addWidget(cbHighTemperature, 6, 0, 1, 1);

        cbPressure = new QCheckBox(groupBox_2);
        cbPressure->setObjectName(QStringLiteral("cbPressure"));
        cbPressure->setEnabled(true);
        cbPressure->setChecked(false);

        gridLayout_2->addWidget(cbPressure, 1, 3, 1, 1);

        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout_2->addWidget(label_3, 0, 1, 1, 1);

        cbTemperature = new QCheckBox(groupBox_2);
        cbTemperature->setObjectName(QStringLiteral("cbTemperature"));
        cbTemperature->setChecked(false);

        gridLayout_2->addWidget(cbTemperature, 1, 0, 1, 1);

        cbDewPoint = new QCheckBox(groupBox_2);
        cbDewPoint->setObjectName(QStringLiteral("cbDewPoint"));

        gridLayout_2->addWidget(cbDewPoint, 5, 0, 1, 1);

        cbIndoorHumidity = new QCheckBox(groupBox_2);
        cbIndoorHumidity->setObjectName(QStringLiteral("cbIndoorHumidity"));
        cbIndoorHumidity->setEnabled(true);

        gridLayout_2->addWidget(cbIndoorHumidity, 2, 1, 1, 1);

        cbHumidity = new QCheckBox(groupBox_2);
        cbHumidity->setObjectName(QStringLiteral("cbHumidity"));
        cbHumidity->setEnabled(true);
        cbHumidity->setChecked(false);

        gridLayout_2->addWidget(cbHumidity, 1, 1, 1, 1);

        cbWindChill = new QCheckBox(groupBox_2);
        cbWindChill->setObjectName(QStringLiteral("cbWindChill"));

        gridLayout_2->addWidget(cbWindChill, 4, 0, 1, 1);

        cbApparentTemperature = new QCheckBox(groupBox_2);
        cbApparentTemperature->setObjectName(QStringLiteral("cbApparentTemperature"));

        gridLayout_2->addWidget(cbApparentTemperature, 3, 0, 1, 1);

        cbIndoorTemperature = new QCheckBox(groupBox_2);
        cbIndoorTemperature->setObjectName(QStringLiteral("cbIndoorTemperature"));

        gridLayout_2->addWidget(cbIndoorTemperature, 2, 0, 1, 1);

        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout_2->addWidget(label_4, 0, 3, 1, 1);

        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout_2->addWidget(label_2, 0, 0, 1, 1);

        cbRainfall = new QCheckBox(groupBox_2);
        cbRainfall->setObjectName(QStringLiteral("cbRainfall"));
        cbRainfall->setEnabled(true);
        cbRainfall->setChecked(false);

        gridLayout_2->addWidget(cbRainfall, 2, 3, 1, 1);

        lblSolar = new QLabel(groupBox_2);
        lblSolar->setObjectName(QStringLiteral("lblSolar"));

        gridLayout_2->addWidget(lblSolar, 0, 2, 1, 1);

        cbUVIndex = new QCheckBox(groupBox_2);
        cbUVIndex->setObjectName(QStringLiteral("cbUVIndex"));

        gridLayout_2->addWidget(cbUVIndex, 1, 2, 1, 1);

        cbSolarRadiation = new QCheckBox(groupBox_2);
        cbSolarRadiation->setObjectName(QStringLiteral("cbSolarRadiation"));

        gridLayout_2->addWidget(cbSolarRadiation, 2, 2, 1, 1);

        cbEvapotranspiration = new QCheckBox(groupBox_2);
        cbEvapotranspiration->setObjectName(QStringLiteral("cbEvapotranspiration"));

        gridLayout_2->addWidget(cbEvapotranspiration, 3, 2, 1, 1);

        label_5 = new QLabel(groupBox_2);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout_2->addWidget(label_5, 3, 1, 1, 1);

        cbAverageWindSpeed = new QCheckBox(groupBox_2);
        cbAverageWindSpeed->setObjectName(QStringLiteral("cbAverageWindSpeed"));

        gridLayout_2->addWidget(cbAverageWindSpeed, 4, 1, 1, 1);

        cbGustWindSpeed = new QCheckBox(groupBox_2);
        cbGustWindSpeed->setObjectName(QStringLiteral("cbGustWindSpeed"));

        gridLayout_2->addWidget(cbGustWindSpeed, 5, 1, 1, 1);

        cbHighSolarRadiation = new QCheckBox(groupBox_2);
        cbHighSolarRadiation->setObjectName(QStringLiteral("cbHighSolarRadiation"));

        gridLayout_2->addWidget(cbHighSolarRadiation, 4, 2, 1, 1);

        cbWindDirection = new QCheckBox(groupBox_2);
        cbWindDirection->setObjectName(QStringLiteral("cbWindDirection"));

        gridLayout_2->addWidget(cbWindDirection, 6, 1, 1, 1);

        cbHighUVIndex = new QCheckBox(groupBox_2);
        cbHighUVIndex->setObjectName(QStringLiteral("cbHighUVIndex"));

        gridLayout_2->addWidget(cbHighUVIndex, 5, 2, 1, 1);

        cbGustDirection = new QCheckBox(groupBox_2);
        cbGustDirection->setObjectName(QStringLiteral("cbGustDirection"));

        gridLayout_2->addWidget(cbGustDirection, 7, 1, 1, 1);


        gridLayout_4->addWidget(groupBox_2, 0, 0, 1, 2);

        groupBox_3 = new QGroupBox(ChartOptionsDialog);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        gridLayout_3 = new QGridLayout(groupBox_3);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        timespan = new TimespanWidget(groupBox_3);
        timespan->setObjectName(QStringLiteral("timespan"));
        timespan->setFocusPolicy(Qt::TabFocus);

        gridLayout_3->addWidget(timespan, 0, 0, 1, 1);


        gridLayout_4->addWidget(groupBox_3, 1, 0, 1, 2);

        gbAggregate = new QGroupBox(ChartOptionsDialog);
        gbAggregate->setObjectName(QStringLiteral("gbAggregate"));
        gbAggregate->setCheckable(true);
        gbAggregate->setChecked(false);
        gridLayout = new QGridLayout(gbAggregate);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label_9 = new QLabel(gbAggregate);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setWordWrap(true);

        gridLayout->addWidget(label_9, 0, 0, 1, 2);

        aggregateWidget = new AggregateOptionsWidget(gbAggregate);
        aggregateWidget->setObjectName(QStringLiteral("aggregateWidget"));

        gridLayout->addWidget(aggregateWidget, 1, 0, 1, 2);


        gridLayout_4->addWidget(gbAggregate, 2, 0, 1, 2);

        buttonBox = new QDialogButtonBox(ChartOptionsDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout_4->addWidget(buttonBox, 3, 0, 1, 2);

        QWidget::setTabOrder(cbTemperature, cbIndoorTemperature);
        QWidget::setTabOrder(cbIndoorTemperature, cbApparentTemperature);
        QWidget::setTabOrder(cbApparentTemperature, cbWindChill);
        QWidget::setTabOrder(cbWindChill, cbDewPoint);
        QWidget::setTabOrder(cbDewPoint, cbHighTemperature);
        QWidget::setTabOrder(cbHighTemperature, cbLowTemperature);
        QWidget::setTabOrder(cbLowTemperature, cbHumidity);
        QWidget::setTabOrder(cbHumidity, cbIndoorHumidity);
        QWidget::setTabOrder(cbIndoorHumidity, cbAverageWindSpeed);
        QWidget::setTabOrder(cbAverageWindSpeed, cbGustWindSpeed);
        QWidget::setTabOrder(cbGustWindSpeed, cbWindDirection);
        QWidget::setTabOrder(cbWindDirection, cbGustDirection);
        QWidget::setTabOrder(cbGustDirection, cbUVIndex);
        QWidget::setTabOrder(cbUVIndex, cbSolarRadiation);
        QWidget::setTabOrder(cbSolarRadiation, cbEvapotranspiration);
        QWidget::setTabOrder(cbEvapotranspiration, cbHighSolarRadiation);
        QWidget::setTabOrder(cbHighSolarRadiation, cbHighUVIndex);
        QWidget::setTabOrder(cbHighUVIndex, cbPressure);
        QWidget::setTabOrder(cbPressure, cbRainfall);
        QWidget::setTabOrder(cbRainfall, cbHighRainRate);
        QWidget::setTabOrder(cbHighRainRate, cbWirelessReception);
        QWidget::setTabOrder(cbWirelessReception, timespan);
        QWidget::setTabOrder(timespan, gbAggregate);

        retranslateUi(ChartOptionsDialog);
        QObject::connect(buttonBox, SIGNAL(rejected()), ChartOptionsDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(ChartOptionsDialog);
    } // setupUi

    void retranslateUi(QDialog *ChartOptionsDialog)
    {
        ChartOptionsDialog->setWindowTitle(QApplication::translate("ChartOptionsDialog", "New Chart...", 0));
        groupBox_2->setTitle(QApplication::translate("ChartOptionsDialog", "Graphs", 0));
#ifndef QT_NO_WHATSTHIS
        cbLowTemperature->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Minimum recorded outside temperature over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbLowTemperature->setText(QApplication::translate("ChartOptionsDialog", "Low Temperature", 0));
#ifndef QT_NO_WHATSTHIS
        cbHighRainRate->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Maximum recorded rain rate over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbHighRainRate->setText(QApplication::translate("ChartOptionsDialog", "High Rain Rate", 0));
#ifndef QT_NO_WHATSTHIS
        cbWirelessReception->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average wireless reception quality over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbWirelessReception->setText(QApplication::translate("ChartOptionsDialog", "Wireless Reception", 0));
#ifndef QT_NO_WHATSTHIS
        cbHighTemperature->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Maximum recorded outside temperature over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbHighTemperature->setText(QApplication::translate("ChartOptionsDialog", "High Temperature", 0));
#ifndef QT_NO_WHATSTHIS
        cbPressure->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average barometric pressure over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbPressure->setText(QApplication::translate("ChartOptionsDialog", "Barometric Pressure", 0));
        label_3->setText(QApplication::translate("ChartOptionsDialog", "Humidity:", 0));
#ifndef QT_NO_WHATSTHIS
        cbTemperature->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average outside temperature over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbTemperature->setText(QApplication::translate("ChartOptionsDialog", "Temperature", 0));
#ifndef QT_NO_WHATSTHIS
        cbDewPoint->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average dew point over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbDewPoint->setText(QApplication::translate("ChartOptionsDialog", "Dew Point", 0));
#ifndef QT_NO_WHATSTHIS
        cbIndoorHumidity->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average inside relative humidity over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbIndoorHumidity->setText(QApplication::translate("ChartOptionsDialog", "Inside Humidity", 0));
#ifndef QT_NO_WHATSTHIS
        cbHumidity->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average outside relative humidity over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbHumidity->setText(QApplication::translate("ChartOptionsDialog", "Humidity", 0));
#ifndef QT_NO_WHATSTHIS
        cbWindChill->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average wind chill over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbWindChill->setText(QApplication::translate("ChartOptionsDialog", "Wind Chill", 0));
#ifndef QT_NO_WHATSTHIS
        cbApparentTemperature->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average apparent temperature over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbApparentTemperature->setText(QApplication::translate("ChartOptionsDialog", "Apparent Temperature", 0));
#ifndef QT_NO_WHATSTHIS
        cbIndoorTemperature->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average inside temperature over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbIndoorTemperature->setText(QApplication::translate("ChartOptionsDialog", "Inside Temperature", 0));
        label_4->setText(QApplication::translate("ChartOptionsDialog", "Other:", 0));
        label_2->setText(QApplication::translate("ChartOptionsDialog", "Temperature:", 0));
#ifndef QT_NO_WHATSTHIS
        cbRainfall->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Total rainfall over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbRainfall->setText(QApplication::translate("ChartOptionsDialog", "Rainfall", 0));
        lblSolar->setText(QApplication::translate("ChartOptionsDialog", "Solar:", 0));
#ifndef QT_NO_WHATSTHIS
        cbUVIndex->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average UV Index over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbUVIndex->setText(QApplication::translate("ChartOptionsDialog", "UV Index", 0));
#ifndef QT_NO_WHATSTHIS
        cbSolarRadiation->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average Solar Radiation over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbSolarRadiation->setText(QApplication::translate("ChartOptionsDialog", "Solar Radiation", 0));
#ifndef QT_NO_WHATSTHIS
        cbEvapotranspiration->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Evapotranspiration - present only in the first sample of every hour.", 0));
#endif // QT_NO_WHATSTHIS
        cbEvapotranspiration->setText(QApplication::translate("ChartOptionsDialog", "Evapotranspiration", 0));
        label_5->setText(QApplication::translate("ChartOptionsDialog", "Wind:", 0));
#ifndef QT_NO_WHATSTHIS
        cbAverageWindSpeed->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average wind speed over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbAverageWindSpeed->setText(QApplication::translate("ChartOptionsDialog", "Average", 0));
#ifndef QT_NO_WHATSTHIS
        cbGustWindSpeed->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Maximum recorded wind speed over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbGustWindSpeed->setText(QApplication::translate("ChartOptionsDialog", "Gust", 0));
#ifndef QT_NO_WHATSTHIS
        cbHighSolarRadiation->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Maximum recorded solar radiation over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbHighSolarRadiation->setText(QApplication::translate("ChartOptionsDialog", "High Solar Radiation", 0));
#ifndef QT_NO_WHATSTHIS
        cbWindDirection->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Average wind direction over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbWindDirection->setText(QApplication::translate("ChartOptionsDialog", "Average Direction", 0));
#ifndef QT_NO_WHATSTHIS
        cbHighUVIndex->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Maximum recorded UV Index over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbHighUVIndex->setText(QApplication::translate("ChartOptionsDialog", "High UV Index", 0));
#ifndef QT_NO_WHATSTHIS
        cbGustDirection->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Direction of maximum recorded wind speed over the archive period", 0));
#endif // QT_NO_WHATSTHIS
        cbGustDirection->setText(QApplication::translate("ChartOptionsDialog", "Gust Direction", 0));
        groupBox_3->setTitle(QApplication::translate("ChartOptionsDialog", "Period", 0));
#ifndef QT_NO_WHATSTHIS
        gbAggregate->setWhatsThis(QApplication::translate("ChartOptionsDialog", "Aggregate data by time for computing highs, lows, averages, etc", 0));
#endif // QT_NO_WHATSTHIS
        gbAggregate->setTitle(QApplication::translate("ChartOptionsDialog", "Aggregate", 0));
        label_9->setText(QApplication::translate("ChartOptionsDialog", "This allows you to plot hourly averages, daily rainfall totals, monthly highs, etc.", 0));
    } // retranslateUi

};

namespace Ui {
    class ChartOptionsDialog: public Ui_ChartOptionsDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHARTOPTIONSDIALOG_H
