/********************************************************************************
** Form generated from reading UI file 'aggregateoptionswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AGGREGATEOPTIONSWIDGET_H
#define UI_AGGREGATEOPTIONSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AggregateOptionsWidget
{
public:
    QGridLayout *gridLayout;
    QComboBox *cbMethod;
    QLabel *label_7;
    QLabel *label_8;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout;
    QRadioButton *rbHourly;
    QRadioButton *rbDaily;
    QRadioButton *rbWeekly;
    QRadioButton *rbMonthly;
    QRadioButton *rbYearly;
    QHBoxLayout *horizontalLayout_2;
    QRadioButton *rbCustom;
    QSpinBox *sbCustomMinutes;
    QSpacerItem *horizontalSpacer;

    void setupUi(QWidget *AggregateOptionsWidget)
    {
        if (AggregateOptionsWidget->objectName().isEmpty())
            AggregateOptionsWidget->setObjectName(QStringLiteral("AggregateOptionsWidget"));
        AggregateOptionsWidget->resize(351, 73);
        gridLayout = new QGridLayout(AggregateOptionsWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        cbMethod = new QComboBox(AggregateOptionsWidget);
        cbMethod->setObjectName(QStringLiteral("cbMethod"));

        gridLayout->addWidget(cbMethod, 0, 1, 1, 1);

        label_7 = new QLabel(AggregateOptionsWidget);
        label_7->setObjectName(QStringLiteral("label_7"));

        gridLayout->addWidget(label_7, 0, 0, 1, 1);

        label_8 = new QLabel(AggregateOptionsWidget);
        label_8->setObjectName(QStringLiteral("label_8"));

        gridLayout->addWidget(label_8, 1, 0, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 0, 2, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        rbHourly = new QRadioButton(AggregateOptionsWidget);
        rbHourly->setObjectName(QStringLiteral("rbHourly"));
        rbHourly->setChecked(true);

        horizontalLayout->addWidget(rbHourly);

        rbDaily = new QRadioButton(AggregateOptionsWidget);
        rbDaily->setObjectName(QStringLiteral("rbDaily"));

        horizontalLayout->addWidget(rbDaily);

        rbWeekly = new QRadioButton(AggregateOptionsWidget);
        rbWeekly->setObjectName(QStringLiteral("rbWeekly"));

        horizontalLayout->addWidget(rbWeekly);

        rbMonthly = new QRadioButton(AggregateOptionsWidget);
        rbMonthly->setObjectName(QStringLiteral("rbMonthly"));

        horizontalLayout->addWidget(rbMonthly);

        rbYearly = new QRadioButton(AggregateOptionsWidget);
        rbYearly->setObjectName(QStringLiteral("rbYearly"));

        horizontalLayout->addWidget(rbYearly);


        gridLayout->addLayout(horizontalLayout, 1, 1, 1, 2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        rbCustom = new QRadioButton(AggregateOptionsWidget);
        rbCustom->setObjectName(QStringLiteral("rbCustom"));

        horizontalLayout_2->addWidget(rbCustom);

        sbCustomMinutes = new QSpinBox(AggregateOptionsWidget);
        sbCustomMinutes->setObjectName(QStringLiteral("sbCustomMinutes"));
        sbCustomMinutes->setEnabled(false);
        sbCustomMinutes->setMinimum(0);
        sbCustomMinutes->setMaximum(9999999);
        sbCustomMinutes->setValue(1051898);

        horizontalLayout_2->addWidget(sbCustomMinutes);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);


        gridLayout->addLayout(horizontalLayout_2, 2, 1, 1, 2);


        retranslateUi(AggregateOptionsWidget);
        QObject::connect(rbCustom, SIGNAL(toggled(bool)), sbCustomMinutes, SLOT(setEnabled(bool)));

        QMetaObject::connectSlotsByName(AggregateOptionsWidget);
    } // setupUi

    void retranslateUi(QWidget *AggregateOptionsWidget)
    {
        AggregateOptionsWidget->setWindowTitle(QApplication::translate("AggregateOptionsWidget", "Form", 0));
        cbMethod->clear();
        cbMethod->insertItems(0, QStringList()
         << QApplication::translate("AggregateOptionsWidget", "Average", 0)
         << QApplication::translate("AggregateOptionsWidget", "Minimum", 0)
         << QApplication::translate("AggregateOptionsWidget", "Maximum", 0)
         << QApplication::translate("AggregateOptionsWidget", "Sum", 0)
         << QApplication::translate("AggregateOptionsWidget", "Running Total", 0)
        );
        label_7->setText(QApplication::translate("AggregateOptionsWidget", "Method:", 0));
        label_8->setText(QApplication::translate("AggregateOptionsWidget", "Grouping:", 0));
#ifndef QT_NO_TOOLTIP
        rbHourly->setToolTip(QApplication::translate("AggregateOptionsWidget", "60 minutes", 0));
#endif // QT_NO_TOOLTIP
        rbHourly->setText(QApplication::translate("AggregateOptionsWidget", "Hourly", 0));
#ifndef QT_NO_TOOLTIP
        rbDaily->setToolTip(QApplication::translate("AggregateOptionsWidget", "1440 minutes", 0));
#endif // QT_NO_TOOLTIP
        rbDaily->setText(QApplication::translate("AggregateOptionsWidget", "Daily", 0));
#ifndef QT_NO_TOOLTIP
        rbWeekly->setToolTip(QApplication::translate("AggregateOptionsWidget", "10080 minutes", 0));
#endif // QT_NO_TOOLTIP
        rbWeekly->setText(QApplication::translate("AggregateOptionsWidget", "Weekly", 0));
        rbMonthly->setText(QApplication::translate("AggregateOptionsWidget", "Monthly", 0));
#ifndef QT_NO_TOOLTIP
        rbYearly->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        rbYearly->setText(QApplication::translate("AggregateOptionsWidget", "Yearly", 0));
        rbCustom->setText(QApplication::translate("AggregateOptionsWidget", "Custom:", 0));
        sbCustomMinutes->setSuffix(QApplication::translate("AggregateOptionsWidget", " minutes", 0));
    } // retranslateUi

};

namespace Ui {
    class AggregateOptionsWidget: public Ui_AggregateOptionsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AGGREGATEOPTIONSWIDGET_H
