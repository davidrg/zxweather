/********************************************************************************
** Form generated from reading UI file 'graphstyledialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GRAPHSTYLEDIALOG_H
#define UI_GRAPHSTYLEDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include "qtcolorbutton/qtcolorbutton.h"

QT_BEGIN_NAMESPACE

class Ui_GraphStyleDialog
{
public:
    QGridLayout *gridLayout;
    QFormLayout *formLayout;
    QLabel *label;
    QLabel *lblColumnType;
    QLabel *label_3;
    QLineEdit *leName;
    QLabel *label_4;
    QComboBox *cbLineStyle;
    QLabel *label_5;
    QComboBox *cbPointStyle;
    QLabel *label_6;
    QtColorButton *clrLineColour;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *GraphStyleDialog)
    {
        if (GraphStyleDialog->objectName().isEmpty())
            GraphStyleDialog->setObjectName(QStringLiteral("GraphStyleDialog"));
        GraphStyleDialog->resize(342, 171);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/chart-edit"), QSize(), QIcon::Normal, QIcon::Off);
        GraphStyleDialog->setWindowIcon(icon);
        gridLayout = new QGridLayout(GraphStyleDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        formLayout = new QFormLayout();
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label = new QLabel(GraphStyleDialog);
        label->setObjectName(QStringLiteral("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        lblColumnType = new QLabel(GraphStyleDialog);
        lblColumnType->setObjectName(QStringLiteral("lblColumnType"));

        formLayout->setWidget(0, QFormLayout::FieldRole, lblColumnType);

        label_3 = new QLabel(GraphStyleDialog);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_3);

        leName = new QLineEdit(GraphStyleDialog);
        leName->setObjectName(QStringLiteral("leName"));

        formLayout->setWidget(1, QFormLayout::FieldRole, leName);

        label_4 = new QLabel(GraphStyleDialog);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_4);

        cbLineStyle = new QComboBox(GraphStyleDialog);
        cbLineStyle->setObjectName(QStringLiteral("cbLineStyle"));

        formLayout->setWidget(2, QFormLayout::FieldRole, cbLineStyle);

        label_5 = new QLabel(GraphStyleDialog);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout->setWidget(3, QFormLayout::LabelRole, label_5);

        cbPointStyle = new QComboBox(GraphStyleDialog);
        cbPointStyle->addItem(QString());
        cbPointStyle->addItem(QString());
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/scatter_style/ssCross"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon1, QString());
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/icons/scatter_style/ssPlus"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon2, QString());
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/icons/scatter_style/ssCircle"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon3, QString());
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/icons/scatter_style/ssDisc"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon4, QString());
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/icons/scatter_style/ssSquare"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon5, QString());
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/icons/scatter_style/ssDiamond"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon6, QString());
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/icons/scatter_style/ssStar"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon7, QString());
        QIcon icon8;
        icon8.addFile(QStringLiteral(":/icons/scatter_style/ssTriangle"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon8, QString());
        QIcon icon9;
        icon9.addFile(QStringLiteral(":/icons/scatter_style/ssTriangleInverted"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon9, QString());
        QIcon icon10;
        icon10.addFile(QStringLiteral(":/icons/scatter_style/ssCrossSquare"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon10, QString());
        QIcon icon11;
        icon11.addFile(QStringLiteral(":/icons/scatter_style/ssPlusSquare"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon11, QString());
        QIcon icon12;
        icon12.addFile(QStringLiteral(":/icons/scatter_style/ssCrossCircle"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon12, QString());
        QIcon icon13;
        icon13.addFile(QStringLiteral(":/icons/scatter_style/ssPlusCircle"), QSize(), QIcon::Normal, QIcon::Off);
        cbPointStyle->addItem(icon13, QString());
        cbPointStyle->setObjectName(QStringLiteral("cbPointStyle"));

        formLayout->setWidget(3, QFormLayout::FieldRole, cbPointStyle);

        label_6 = new QLabel(GraphStyleDialog);
        label_6->setObjectName(QStringLiteral("label_6"));

        formLayout->setWidget(4, QFormLayout::LabelRole, label_6);

        clrLineColour = new QtColorButton(GraphStyleDialog);
        clrLineColour->setObjectName(QStringLiteral("clrLineColour"));
        clrLineColour->setMinimumSize(QSize(64, 23));
        clrLineColour->setMaximumSize(QSize(64, 23));

        formLayout->setWidget(4, QFormLayout::FieldRole, clrLineColour);


        gridLayout->addLayout(formLayout, 0, 0, 1, 1);

        buttonBox = new QDialogButtonBox(GraphStyleDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok|QDialogButtonBox::RestoreDefaults);

        gridLayout->addWidget(buttonBox, 1, 0, 1, 1);


        retranslateUi(GraphStyleDialog);
        QObject::connect(buttonBox, SIGNAL(rejected()), GraphStyleDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(GraphStyleDialog);
    } // setupUi

    void retranslateUi(QDialog *GraphStyleDialog)
    {
        GraphStyleDialog->setWindowTitle(QApplication::translate("GraphStyleDialog", "Graph Style", 0));
        label->setText(QApplication::translate("GraphStyleDialog", "Data Type:", 0));
        lblColumnType->setText(QApplication::translate("GraphStyleDialog", "Temperature", 0));
        label_3->setText(QApplication::translate("GraphStyleDialog", "Name:", 0));
        label_4->setText(QApplication::translate("GraphStyleDialog", "Line Style:", 0));
        cbLineStyle->clear();
        cbLineStyle->insertItems(0, QStringList()
         << QApplication::translate("GraphStyleDialog", "None", 0)
         << QApplication::translate("GraphStyleDialog", "Line", 0)
         << QApplication::translate("GraphStyleDialog", "Step Left", 0)
         << QApplication::translate("GraphStyleDialog", "Step Right", 0)
         << QApplication::translate("GraphStyleDialog", "Step Center", 0)
         << QApplication::translate("GraphStyleDialog", "Impulse", 0)
        );
        label_5->setText(QApplication::translate("GraphStyleDialog", "Point Style:", 0));
        cbPointStyle->setItemText(0, QApplication::translate("GraphStyleDialog", "None", 0));
        cbPointStyle->setItemText(1, QApplication::translate("GraphStyleDialog", "Dot", 0));
        cbPointStyle->setItemText(2, QApplication::translate("GraphStyleDialog", "Cross", 0));
        cbPointStyle->setItemText(3, QApplication::translate("GraphStyleDialog", "Plus", 0));
        cbPointStyle->setItemText(4, QApplication::translate("GraphStyleDialog", "Circle", 0));
        cbPointStyle->setItemText(5, QApplication::translate("GraphStyleDialog", "Disc", 0));
        cbPointStyle->setItemText(6, QApplication::translate("GraphStyleDialog", "Square", 0));
        cbPointStyle->setItemText(7, QApplication::translate("GraphStyleDialog", "Diamond", 0));
        cbPointStyle->setItemText(8, QApplication::translate("GraphStyleDialog", "Star", 0));
        cbPointStyle->setItemText(9, QApplication::translate("GraphStyleDialog", "Triangle", 0));
        cbPointStyle->setItemText(10, QApplication::translate("GraphStyleDialog", "Triangle (Inverted)", 0));
        cbPointStyle->setItemText(11, QApplication::translate("GraphStyleDialog", "Cross Square", 0));
        cbPointStyle->setItemText(12, QApplication::translate("GraphStyleDialog", "Plus Square", 0));
        cbPointStyle->setItemText(13, QApplication::translate("GraphStyleDialog", "Cross Circle", 0));
        cbPointStyle->setItemText(14, QApplication::translate("GraphStyleDialog", "Plus Circle", 0));

        label_6->setText(QApplication::translate("GraphStyleDialog", "Line Colour:", 0));
        clrLineColour->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class GraphStyleDialog: public Ui_GraphStyleDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GRAPHSTYLEDIALOG_H
